    #   ---------------------------------------------------------------------------------------
    
    # Copyright 2023 by John B Rundle, University of California, Davis, CA USA
    # 
    # Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
    # documentation files (the     "Software"), to deal in the Software without restriction, including without 
    # limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
    # and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
    # 
    # The above copyright notice and this permission notice shall be included in all copies or suSKLantial portions of the Software.
    # 
    # THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
    # WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
    # COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
    # ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
    #
    # Note that some part of these codes were written by the AI program chatGPT, a product of openAI
    #
    #   ERAS is the "Rescaled Aftershock Method for Stochastic Earthquake Seismicity"
    #
    #
    #   ---------------------------------------------------------------------------------------

import numpy as np
import random
import math
from math import log10

import cartopy
import cartopy.crs as ccrs
import cartopy.feature as cfeature

import cartopy.io.img_tiles as cimgt
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
from cartopy.feature import NaturalEarthFeature, LAND, COASTLINE
from cartopy.io.img_tiles import StadiaMapsTiles

import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import matplotlib.patches as mpatches
from matplotlib import gridspec
from matplotlib.patches import Rectangle

from matplotlib.offsetbox import AnchoredText
from matplotlib.image import imread
import matplotlib.ticker as mticker

import ERASCalcV5
import ERASUtilities
import ERASFileMethods

import Compute_EMA_Timeseries

import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning) 
   
    ###############################################################################################
    
def read_existing_catalog(input_file_name):

    mags                    =   []
    date_events             =   []
    time_events             =   []
    year_events             =   []
    depth_events            =   []
    y_events                =   []
    x_events                =   []
    label_events            =   []

    data_file = open(input_file_name,"r")
    
    for line in data_file:
        items = line.strip().split()
        
        date_events.append(items[0])
        time_events.append(items[1])
        year_events.append(float(items[2]))
        x_events.append(float(items[3]))
        y_events.append(float(items[4]))
        mags.append(float(items[5]))
        depth_events.append(float(items[6]))
        label_events.append(items[7])
        
    data_file.close()  
    
    return date_events, time_events, year_events, x_events, y_events, mags, depth_events, label_events
    
    ###############################################################################################
    
def plot_mag_timeseries_raw(year_events, mags, params, Location, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space\
            = ERASFileMethods.read_parameter_file()

        
    mag_threshold = mu + BathNumber

    mag_list = []
    year_list = []
    
    
    fig, ax = plt.subplots()
    
    for i in range(int(len(year_events))):
        mag_list.append(mags[i])
        year_list.append(year_events[i])

    ax.plot(year_list, mag_list, marker = 'o', color ='blue', markersize = 1, lw = 0.0)
    
    textstr =   ' Minimum Magnitude: ' + str(mu) +\
                '\n Input b-value: ' + str(bval)+\
                '\n Baths Law Number: ' + str(BathNumber)+\
                '\n Time Rescale Factor: ' + str(round(scale_factor,5))+\
                '\n Aftershock Step Lat: ' + str(round(step_lat,5))+ '$^o$'+\
                '\n Aftershock Step Lng: ' + str(round(step_lng,5))+ '$^o$'

 
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    # place a text box at lower left
    if USGS == False:
        ax.text(0.015, 0.02, textstr, transform=ax.transAxes, fontsize=5,\
            verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)
    
    SupTitle_text = 'Magnitude-Time Diagram for ' + str(len(mags)) +  ' Unclustered ' + Location + ' Earthquakes'
    plt.suptitle(SupTitle_text, fontsize=10)
    
    if USGS == False:
        Title_text = 'Hyper-Parameter Values Displayed in Legend'
        plt.title(Title_text, fontsize=8)

    plt.xlabel('Time Index')
    plt.ylabel('ERAS Earthquake Magnitude')
    
    FigureName = './Figures/Mag_Time_Raw.png'
          
    plt.savefig(FigureName, dpi=200)
    
    #plt.show()
    
    plt.close()
    
    return
    
    ###############################################################################################
    
def plot_mag_timeseries_clustered(year_events, mags, params, Location, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space\
            = ERASFileMethods.read_parameter_file()
        
    mag_threshold = mu + BathNumber

    mag_list = []
    year_list = []
    
    fig, ax = plt.subplots()
    
    for i in range(int(len(year_events))):
        mag_list.append(round(mags[i],2))
        year_list.append(year_events[i])
        
    ax.plot(year_list, mag_list, marker = 'o', color ='blue', markersize = 1, lw = 0.0)
    
    textstr =   ' Minimum Magnitude: ' + str(mu) +\
                '\n Input b-value: ' + str(bval)+\
                '\n Baths Law Number: ' + str(BathNumber)+\
                '\n Time Rescale Factor: ' + str(round(scale_factor,5))+\
                '\n Aftershock Step Lat: ' + str(round(step_lat,5))+ '$^o$'+\
                '\n Aftershock Step Lng: ' + str(round(step_lng,5))+ '$^o$'
                
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    # place a text box at lower left
    if USGS == False:
        ax.text(0.015, 0.02, textstr, transform=ax.transAxes, fontsize=5,\
            verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)

    SupTitle_text = 'Magnitude vs. Time'
    Title_text =  'For ' + str(len(mags)) + ' M >' + str(min(mags)) +  ' Clustered ' + Location + ' Earthquakes'
    if Location == 'Los Angeles':
        Title_text =  'For ' + str(len(mags)) + ' M>' + str(mu) + ' ' + Location + ' Earthquakes'
    plt.suptitle(SupTitle_text, fontsize=12)
    plt.title(Title_text, fontsize=10)

    plt.xlabel('Time Index')
    plt.ylabel('ERAS Earthquake Magnitude')
    
    FigureName = './Figures/Mag_Time_Clustered.png'
    plt.savefig(FigureName, dpi=200)
    
    plt.close()
    
    return
    
    ###############################################################################################
    
def plot_number_timeseries_one_mainshock_days(date_events, year_events, time_events, mags, \
        params, Location, begin_index, number_days, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag, bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()
        
    day_fraction_year       = 1./365
        
    mag_threshold = mu + BathNumber
   
    #   Choose bin size and number bins
    
    delta_time_interval            = day_fraction_year
    number_bins = number_days
    
                                        
    year_events_corrected   =   []
    time_interval           =   []
    time_since_mainshock    =   []

    for i in range(len(year_events)):
        if USGS:
            time_of_day = time_events[i].split(':')
            minutes = float(time_of_day[0])*60 + float(time_of_day[1])
            minutes_in_years = minutes*hour_fraction_year/60
            year_events_corrected.append(year_events[i] + minutes_in_years)
        else:
            year_events_corrected.append(year_events[i])
            
    number_bins = (year_events_corrected[-1:][0] - year_events_corrected[0])*365.
    number_bins = int(number_bins)
    
    print('number_bins: ', number_bins)
    
    days_bins = []
    
    for i in range(len(year_events_corrected)):
        day_intervals = (year_events_corrected[i] - year_events_corrected[0])*365.
        days_bins.append(round(day_intervals,3))
        
    number_events,bins = np.histogram(days_bins,bins=number_bins)
    
    #   Compute beginning and final bins to plot
    
    begin_bin = (year_events_corrected[begin_index] - year_events_corrected[0])*365. 
    begin_bin = int(begin_bin)
    final_bin = begin_bin + number_days
    
    number_events_to_plot   =   []
    
    for i in range(begin_bin, final_bin):   
        number_events_to_plot.append(number_events[i])
        
    total_events = sum(number_events_to_plot)
            
    print('Initial Date: ', date_events[begin_index])
    print()
    
    days_since_mainshock = []
    
    for j in range(len(number_events_to_plot)):
        days_since_mainshock.append(j)
        
    fig, ax = plt.subplots()
#     
#     #   -------------------------------------------------------------
#     
    min_number = min(number_events_to_plot)
    
    for i in range(len(days_since_mainshock)):
        x_eq = [days_since_mainshock[i], days_since_mainshock[i]]
        y_eq = [min_number, number_events_to_plot[i]]
        ax.plot(x_eq,y_eq, linestyle='-', lw=1.0, color='c', zorder=1, alpha=0.30)

        ax.plot(days_since_mainshock, number_events_to_plot, marker = 'o', color ='blue', markersize = 1.5, lw = 0.0, zorder = 5)
        
    mag_mainshock = '%.2f'%(mags[begin_index])
    
    SupTitle_text = 'Daily Number of Clustered Earthquakes M > ' + str(mu) + ' vs. Time '
    Title_text =  'For ' + str(total_events) + ' ' + Location \
            + ' Earthquakes After ' + 'M' + str(mag_mainshock) + ' on ' + date_events[begin_index]
    if Location == 'Los Angeles':
        Title_text =  'For ' + str(total_events) + ' M>' + str(mu) + ' ' + Location + ' Earthquakes'
    plt.suptitle(SupTitle_text, fontsize=10)
    plt.title(Title_text, fontsize=8)
    
    x_text_string = 'Days Since M' + str(mag_mainshock) + ' Earthquake on ' + date_events[begin_index] \
            + ' at ' + time_events[begin_index]
    plt.xlabel(x_text_string, fontsize=8)
    plt.ylabel('Daily Number', fontsize=8)
        
    ax.tick_params(axis='both', which='major', labelsize=8)
    ax.tick_params(axis='both', which='minor', labelsize=6)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    ax.set_ylim(bottom=-0.1, top=ymax)
    
    FigureName = './Figures/Number_Time_Clustered_One_Mainshock_Days.png'
          
    plt.savefig(FigureName, dpi=200)
    
    plt.close()
    
    return
    
    ###############################################################################################
    
def plot_mag_timeseries_clustered_one_mainshock_days(date_events, time_events, year_events, mags, \
        params, Location, begin_index, number_days, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space\
            = ERASFileMethods.read_parameter_file()
        
    mag_threshold = mu + BathNumber

    mag_list = []
    year_list = []
    
    hour_fraction_year      = 1./8760.
    day_fraction_year       = 1./365
    month_fraction_year     = 1./13.
    
    delta_time_interval            = day_fraction_year
        
    year_events_corrected   =   []
    time_interval           =   []
    time_since_mainshock    =   []

    for i in range(len(year_events)):
        if USGS:
            time_of_day = time_events[i].split(':')
            minutes = float(time_of_day[0])*60 + float(time_of_day[1])
            minutes_in_years = minutes*hour_fraction_year/60
            year_events_corrected.append(year_events[i] + minutes_in_years)
        else:
            year_events_corrected.append(year_events[i])
            
    end_year = year_events_corrected[begin_index] + number_days * delta_time_interval
    
    fig, ax = plt.subplots()
    
    for i in range(int(len(year_events_corrected))):
        if year_events_corrected[i] >= year_events_corrected[begin_index] and year_events_corrected[i] <= end_year:
            mag_list.append(round(mags[i],2))
            year_list.append(year_events_corrected[i])
            
    i = begin_index
    while i >= begin_index and year_events_corrected[i] <= end_year:
        time_interval.append(year_events_corrected[i])
        i += 1
    i = i - 1
            
    time_since_mainshock    =   []
    for i in range(len(year_list)):
        day_of_event = (year_list[i] - year_list[0])/day_fraction_year
        time_since_mainshock.append(day_of_event)
        
    ax.plot(time_since_mainshock, mag_list, marker = 'o', color ='blue', markersize = 1, lw = 0.0)
        
    textstr =   ' Minimum Magnitude: ' + str(mu) +\
                '\n Input b-value: ' + str(bval)+\
                '\n Baths Law Number: ' + str(BathNumber)+\
                '\n Time Rescale Factor: ' + str(round(scale_factor,5))+\
                '\n Aftershock Step Lat: ' + str(round(step_lat,5))+ '$^o$'+\
                '\n Aftershock Step Lng: ' + str(round(step_lng,5))+ '$^o$'
                
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    # place a text box at lower left
    if USGS == False:
        ax.text(0.98, 0.98, textstr, transform=ax.transAxes, fontsize=5,\
            verticalalignment='top', horizontalalignment = 'right', bbox=props, linespacing = 1.8)
            
    mag_mainshock = '%.2f'%(mags[begin_index])
            
    SupTitle_text = 'Magnitude vs. Time'
    Title_text =  'For ' + str(len(time_since_mainshock)) + ' ' + Location + ' M > ' + str(mu) \
            + ' Earthquakes After ' + 'M' + str(mag_mainshock) + ' on ' + date_events[begin_index] 
            
    if Location == 'Los Angeles':
        Title_text =  'For ' + str(len(year_list)) + ' M>' + str(mu) + ' ' + Location + ' Earthquakes'
        
    plt.suptitle(SupTitle_text, fontsize=10)
    plt.title(Title_text, fontsize=8)
    
#     
    x_text_string = 'Days Since M' + str(mag_mainshock) + ' Earthquake on ' + date_events[begin_index] \
            + ' at ' + time_events[begin_index]
    plt.xlabel(x_text_string, fontsize=8)

    plt.ylabel('Earthquake Magnitude')
    
    FigureName = './Figures/Mag_Time_Clustered_One_Mainshock_Days.png'
    plt.savefig(FigureName, dpi=200)
    
    plt.close()
    
    return
#     
#     ###############################################################################################
    
def plot_mag_timeseries_clustered_one_mainshock_hours(date_events, time_events, year_events, mags, \
        params, Location, begin_index, number_hours, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space\
            = ERASFileMethods.read_parameter_file()
        
    mag_threshold = mu + BathNumber

    mag_list = []
    year_list = []
    
    hour_fraction_year      = 1./8760.
    day_fraction_year       = 1./365
    month_fraction_year     = 1./13.
    
    delta_time_interval            = hour_fraction_year
        
    year_events_corrected   =   []
    time_interval           =   []
    time_since_mainshock    =   []

    for i in range(len(year_events)):
        if USGS:
            time_of_day = time_events[i].split(':')
            minutes = float(time_of_day[0])*60 + float(time_of_day[1])
            minutes_in_years = minutes*hour_fraction_year/60
            year_events_corrected.append(year_events[i] + minutes_in_years)
        else:
            year_events_corrected.append(year_events[i])
            
    end_year = year_events_corrected[begin_index] + number_hours * delta_time_interval
    
    print('year_events_corrected[begin_index], number_hours, end_year: ', year_events_corrected[begin_index], number_hours, end_year)
    
    fig, ax = plt.subplots()
    
    for i in range(begin_index, int(len(year_events_corrected))):
        if year_events_corrected[i] <= end_year:
            mag_list.append(round(mags[i],2))
            year_list.append(year_events_corrected[i])
            
    i = begin_index
    while i >= begin_index and year_events_corrected[i] <= end_year:
        time_interval.append(year_events_corrected[i])
        i += 1
    i = i - 1
            
    time_since_mainshock    =   []
    for i in range(len(year_list)):
        hour_of_event = (year_list[i] - year_list[0])/hour_fraction_year
        time_since_mainshock.append(hour_of_event)
        
    ax.plot(time_since_mainshock, mag_list, marker = 'o', color ='blue', markersize = 1, lw = 0.0)
        
    textstr =   ' Minimum Magnitude: ' + str(mu) +\
                '\n Input b-value: ' + str(bval)+\
                '\n Baths Law Number: ' + str(BathNumber)+\
                '\n Time Rescale Factor: ' + str(round(scale_factor,5))+\
                '\n Aftershock Step Lat: ' + str(round(step_lat,5))+ '$^o$'+\
                '\n Aftershock Step Lng: ' + str(round(step_lng,5))+ '$^o$'
                
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    # place a text box at lower left
    if USGS == False:
        ax.text(0.98, 0.98, textstr, transform=ax.transAxes, fontsize=5,\
            verticalalignment='top', horizontalalignment = 'right', bbox=props, linespacing = 1.8)
            
    mag_mainshock = '%.2f'%(mags[begin_index])
            
    SupTitle_text = 'Magnitude vs. Time'
    Title_text =  'For ' + str(len(time_since_mainshock)) + ' ' + Location + ' M > ' + str(mu) \
            + ' Earthquakes After ' + 'M' + str(mag_mainshock) + ' on ' + date_events[begin_index] 
            
    if Location == 'Los Angeles':
        Title_text =  'For ' + str(len(year_list)) + ' M>' + str(mu) + ' ' + Location + ' Earthquakes'
        
    plt.suptitle(SupTitle_text, fontsize=10)
    plt.title(Title_text, fontsize=8)
    
#     
    x_text_string = 'Hours Since M' + str(mag_mainshock) + ' Earthquake on ' + date_events[begin_index] \
            + ' at ' + time_events[begin_index]
    plt.xlabel(x_text_string, fontsize=8)

#     plt.xlabel('Time Index')
    plt.ylabel('Earthquake Magnitude')
    
    FigureName = './Figures/Mag_Time_Clustered_One_Mainshock_Hours.png'
    plt.savefig(FigureName, dpi=200)
    
    plt.close()
    
    return
    
    ###############################################################################################
    
def plot_number_timeseries(year_events, mags, params, Location, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()
        
    mag_threshold = mu + BathNumber
   
    month_interval          = 0.07692   #   We use a time interval of "months" 
                                        #       where 1 month = 4 weeks = "lunar month", 52 weeks/year
                                        
    year_index = 0
    max_year = max(year_events)
    min_year = min(year_events)
    
    number_year_bins = int( (max(year_events) - min(year_events))/month_interval)
    
    year_list               =   np.zeros(number_year_bins+1)
    monthly_number_list     =   np.zeros(number_year_bins+1)
    
    for i in range(len(year_list)):
        year_list[i] = min_year + float(i)*month_interval
    
    for i in range(len(year_events)):
        
        last_year_index = year_index
        year_index = int((year_events[i]-min_year)/month_interval)
        if year_index == last_year_index:
            monthly_number_list[year_index]+= 1
            
    log_monthly_number_list = [math.log10(1. + monthly_number_list[i]) for i in range(len(monthly_number_list))]

    fig, ax = plt.subplots()
    
    #   Compute monthly numbers
    
    min_monthly_list = min(log_monthly_number_list)
    
    for i in range(number_year_bins):
        x_eq = [year_list[i],year_list[i]]
        y_eq = [min_monthly_list,log_monthly_number_list[i]]
        ax.plot(x_eq,y_eq, linestyle='-', lw=0.5, color='c', zorder=1, alpha=0.30)
    
    ax.plot(year_list, log_monthly_number_list, marker = 'o', color ='blue', markersize = 1, lw = 0.0, zorder = 5)
    
    #   ---------------------------------------------------
    
    lambda_min_mult = -1.   
    lambda_max_mult = 2.e10 
    NSteps = 36
    
    data_start_year = year_list[0]
    year_array = year_list
    
#             
    timeseries_EMA_reduced, time_list_reduced, log_number_reduced, min_rate, max_rate = \
            Compute_EMA_Timeseries.build_EMA_timeseries(monthly_number_list, year_list,  NSteps, \
            data_start_year, lambda_min_mult, lambda_max_mult)
            
    ax.plot(time_list_reduced, log_number_reduced, '--', color ='red', lw = 0.75, zorder = 10, \
            label='EMA, N='+str(NSteps))
            
    title_text = 'EMA Data'
    leg = ax.legend(loc = 'upper right', title=title_text, fontsize=6, fancybox=True, framealpha=0.5)
    leg.set_title(title_text,prop={'size':8})   #   Set the title text font size

    #   ---------------------------------------------------
    
    textstr =   ' Minimum Magnitude: ' + str(mu) +\
                '\n Input b-value: ' + str(bval)+\
                '\n Baths Law Number: ' + str(BathNumber)+\
                '\n Time Rescale Factor: ' + str(round(scale_factor,5))+\
                '\n Aftershock Step Lat: ' + str(round(step_lat,5))+ '$^o$'+\
                '\n Aftershock Step Lng: ' + str(round(step_lng,5))+ '$^o$'
                
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    # place a text box at lower left
    if USGS == False:
        ax.text(0.015, 0.02, textstr, transform=ax.transAxes, fontsize=5,\
            verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)
            
    SupTitle_text = 'Monthly Number vs. Time'
    Title_text =  'For ' + str(len(mags)) + ' M>' + str(mu) + ' Clustered ' + Location + ' Earthquakes'
    if Location == 'Los Angeles':
        Title_text =  'For ' + str(len(mags)) + ' M>' + str(mu) + ' ' + Location + ' Earthquakes'
    plt.suptitle(SupTitle_text, fontsize=12)
    plt.title(Title_text, fontsize=10)
    
    plt.xlabel('Time (Year)')
    plt.ylabel('$Log_{10}$ (1 + Monthly Number)')
    
    FigureName = './Figures/Number_Time_Clustered.png'
          
    plt.savefig(FigureName, dpi=200)
    
    plt.close()
    
    return
    
    ###############################################################################################
    
def plot_number_timeseries_one_mainshock_days(date_events, year_events, time_events, mags, \
        params, Location, begin_index, number_days, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()
        
    hour_fraction_year      = 1./8760.
    day_fraction_year       = 1./365
    month_fraction_year     = 1./13.
        
    mag_threshold = mu + BathNumber
   
    #   Choose bin size and number bins
    
    delta_time_interval            = day_fraction_year
    number_bins = number_days
    
                                        
    year_events_corrected   =   []
    time_interval           =   []
    time_since_mainshock    =   []

    for i in range(len(year_events)):
        if USGS:
            time_of_day = time_events[i].split(':')
            minutes = float(time_of_day[0])*60 + float(time_of_day[1])
            minutes_in_years = minutes*hour_fraction_year/60
            year_events_corrected.append(year_events[i] + minutes_in_years)

        else:
            year_events_corrected.append(year_events[i])
            
    number_bins = (year_events_corrected[-1:][0] - year_events_corrected[0])*365.
    number_bins = int(number_bins)
    
    print('number_bins: ', number_bins)
    
    days_bins = []
    
    for i in range(len(year_events_corrected)):
        day_intervals = (year_events_corrected[i] - year_events_corrected[0])*365.
        days_bins.append(round(day_intervals,3))
        
    number_events,bins = np.histogram(days_bins,bins=number_bins)
    
    #   Compute beginning and final bins to plot
    
    begin_bin = (year_events_corrected[begin_index] - year_events_corrected[0])*365. 
    begin_bin = int(begin_bin)
    final_bin = begin_bin + number_days
    
    number_events_to_plot   =   []
    
    for i in range(begin_bin, final_bin):   
        number_events_to_plot.append(number_events[i])
        
    total_events = sum(number_events_to_plot)
            
    print('Initial Date: ', date_events[begin_index])
    print()
    
    days_since_mainshock = []
    
    for j in range(len(number_events_to_plot)):
        days_since_mainshock.append(j)
        
    fig, ax = plt.subplots()
#     
#     #   -------------------------------------------------------------
#     
    min_number = min(number_events_to_plot)
    
    for i in range(len(days_since_mainshock)):
        x_eq = [days_since_mainshock[i], days_since_mainshock[i]]
        y_eq = [min_number, number_events_to_plot[i]]
        ax.plot(x_eq,y_eq, linestyle='-', lw=1.0, color='c', zorder=1, alpha=0.30)

        ax.plot(days_since_mainshock, number_events_to_plot, marker = 'o', color ='blue', markersize = 1.5, lw = 0.0, zorder = 5)
        
    mag_mainshock = '%.2f'%(mags[begin_index])
    
    SupTitle_text = 'Daily Number of Clustered Earthquakes M > ' + str(mu) + ' vs. Time '
    Title_text =  'For ' + str(total_events) + ' ' + Location \
            + ' Earthquakes After ' + 'M' + str(mag_mainshock) + ' on ' + date_events[begin_index]
    if Location == 'Los Angeles':
        Title_text =  'For ' + str(total_events) + ' M>' + str(mu) + ' ' + Location + ' Earthquakes'
    plt.suptitle(SupTitle_text, fontsize=10)
    plt.title(Title_text, fontsize=8)
    
    x_text_string = 'Days Since M' + str(mag_mainshock) + ' Earthquake on ' + date_events[begin_index] \
            + ' at ' + time_events[begin_index]
    plt.xlabel(x_text_string, fontsize=8)
    plt.ylabel('Daily Number', fontsize=8)
        
    ax.tick_params(axis='both', which='major', labelsize=8)
    ax.tick_params(axis='both', which='minor', labelsize=6)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    ax.set_ylim(bottom=-0.1, top=ymax)
    
    FigureName = './Figures/Number_Time_Clustered_One_Mainshock_Days.png'
          
    plt.savefig(FigureName, dpi=200)
    
    #plt.show()
    
    plt.close()
    
    return
    
    ###############################################################################################
    
def plot_number_timeseries_one_mainshock_hours(date_events, year_events, time_events, mags, \
        params, Location, begin_index, number_hours, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()
        
    hour_fraction_year      = 1./8760.
    day_fraction_year       = 1./365
    month_fraction_year     = 1./13.
        
    mag_threshold = mu + BathNumber
   
    #   Choose bin size and number bins
    
    delta_time_interval            = hour_fraction_year
    number_bins = number_hours
    
                                        
    year_events_corrected   =   []
    time_interval           =   []
    time_since_mainshock    =   []

    for i in range(len(year_events)):
        if USGS:
            time_of_day = time_events[i].split(':')
            minutes = float(time_of_day[0])*60 + float(time_of_day[1])
            minutes_in_years = minutes*hour_fraction_year/60
            year_events_corrected.append(year_events[i] + minutes_in_years)
        else:
            year_events_corrected.append(year_events[i])
            
    end_year = year_events_corrected[begin_index] + number_hours * delta_time_interval
    
    mag_events  =   []
    
    i = begin_index
    while i >= begin_index and year_events_corrected[i] <= end_year:
        hour_time_interval = (year_events_corrected[i] - year_events_corrected[begin_index])
        time_interval.append(hour_time_interval*8760)
        mag_events.append(round(mags[i],2))
        i += 1
        
    i = i - 1
    
    print()
    for j in range(len(mag_events)):
        print('j, time_interval (hours), mag_events[j]',j, time_interval[j], mag_events[j])
    print()
        
    number_events,bins = np.histogram(time_interval,bins=number_bins)
        
    print('Initial Date: ', date_events[begin_index]+';', '    End Date: ', date_events[begin_index + len(mag_events) - 1])
    print()
    print('sum(number_events), Number in Bins', sum(number_events), number_events)
    print()
    
    for j in range(len(number_events)):
        time_since_mainshock.append(j)
            
    log_number_events = [math.log10(1. + number_events[i]) for i in range(len(number_events))]
    # 
    fig, ax = plt.subplots()
#     
    #   -------------------------------------------------------------
#     
    UseLog = False
    
    if UseLog:
        
        min_number = min(log_number_events)
    
        for i in range(len(time_since_mainshock)):
            x_eq = [time_since_mainshock[i], time_since_mainshock[i]]
            y_eq = [min_number, log_number_events[i]]
            ax.plot(x_eq,y_eq, linestyle='-', lw=1.0, color='c', zorder=1, alpha=0.30)

        ax.plot(time_since_mainshock, log_number_events, marker = 'o', color ='blue', markersize = 1.5, lw = 0.0, zorder = 5)
        
    else:
    
        min_number = min(number_events)
    
        for i in range(len(time_since_mainshock)):
            x_eq = [time_since_mainshock[i], time_since_mainshock[i]]
            y_eq = [min_number, number_events[i]]
            ax.plot(x_eq,y_eq, linestyle='-', lw=1.0, color='c', zorder=1, alpha=0.30)

        ax.plot(time_since_mainshock, number_events, marker = 'o', color ='blue', markersize = 1.5, lw = 0.0, zorder = 5)
        
    #   -------------------------------------------------------------
    
    mag_mainshock = '%.2f'%(mags[begin_index])
    
    SupTitle_text = 'Hourly Number of Clustered Earthquakes M > ' + str(mu) + ' vs. Time '
    Title_text =  'For ' + str(len(time_interval)) + ' ' + Location \
            + ' Earthquakes After ' + 'M' + str(mag_mainshock) + ' on ' + date_events[begin_index]
    if Location == 'Los Angeles':
        Title_text =  'For ' + str(len(time_interval)) + ' M>' + str(mu) + ' ' + Location + ' Earthquakes'
    plt.suptitle(SupTitle_text, fontsize=10)
    plt.title(Title_text, fontsize=8)
    
    x_text_string = 'Hours Since M' + str(mag_mainshock) + ' Earthquake on ' + date_events[begin_index] \
            + ' at ' + time_events[begin_index]
    plt.xlabel(x_text_string, fontsize=8)
    
    if UseLog:
        plt.ylabel('$Log_{10}$ (1 + Daily Number)', fontsize=8)
    else:
        plt.ylabel('Daily Number', fontsize=8)
        
    ax.tick_params(axis='both', which='major', labelsize=8)
    ax.tick_params(axis='both', which='minor', labelsize=6)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    ax.set_ylim(bottom=-0.1, top=ymax)
    
    FigureName = './Figures/Number_Time_Clustered_One_Mainshock_Hours.png'
          
    plt.savefig(FigureName, dpi=200)
    
    plt.close()
    
    return
    
    ###############################################################################################

def plot_GR(mags, params, Location, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space\
            = ERASFileMethods.read_parameter_file()

        
    mag_threshold = mu + BathNumber
    
    #   To compute b-value:
    mag_lo = mu                
    mag_hi = max(mags)
        
    mag_bins, freq_mag_bins_pdf, freq_mag_bins_sdf, log_freq_mag_bins = ERASCalcV5.freq_mag(mags, mag_hi)
    
    freq_mag_bins = [10**(log_freq_mag_bins[i]) for i in range(len(log_freq_mag_bins))]
    
    fig, ax = plt.subplots()

    ax.plot(mag_bins, freq_mag_bins, marker = 'o', color ='blue', markersize = 4, lw = 0)
    
    mag_hi = 5.75

    mag_line_data, freq_line_data, slope, slope_error, cept, cept_error = \
            ERASCalcV5.calc_b_value(log_freq_mag_bins, mag_bins, mag_lo, mag_hi)
    
    bfit = - slope

#   Plot the best fitting line
    ax.plot(mag_line_data, freq_line_data, '--', color = 'red', markersize = 0, lw = 1.5)
    
    ax.set_yscale('log')
    
    textstr1 =   ' Minimum Magnitude: ' + str(mu) +\
                '\n Input b-value: ' + str(bval)+\
                '\n Baths Law Number: ' + str(BathNumber)+\
                '\n Time Rescale Factor: ' + str(round(scale_factor,5))+\
                '\n Aftershock Step Lat: ' + str(round(step_lat,5))+ '$^o$'+\
                '\n Aftershock Step Lng: ' + str(round(step_lng,5))+ '$^o$'
                
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    # place a text box at lower left
    ax.text(0.015, 0.02, textstr1, transform=ax.transAxes, fontsize=8,\
            verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)
    
    bfit = round(bfit,2)
    bfit_error = round(slope_error,2)
    
    textstr2 =      ' b-value (from fit): ' + str(bfit) + ' $\pm$ ' + str(bfit_error) 
                    
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)
    ax.text(0.81, 0.975, textstr2, transform=ax.transAxes, fontsize=8,\
        verticalalignment='top', horizontalalignment = 'center', bbox=props, linespacing = 1.8)
 
    SupTitle_text = 'Magnitude-Frequency Diagram'
    Title_text =  'For ' + str(len(mags)) + ' ' + Location + ' Earthquakes'
    plt.suptitle(SupTitle_text, fontsize=12)
    plt.title(Title_text, fontsize=10)

    plt.xlabel('Magnitude of ERAS Earthquakes')
    plt.ylabel('$Log_{10}$(Number)')
    
    FigureName = './Figures/GR_Mag_Freq.png'
    plt.savefig(FigureName, dpi=200)

    #plt.show()
    
    plt.close()
    
    return
    

# #     ###############################################################################################
    
def plot_omori_aftershock_decay_time(aftershock_list, label_cycle_list, year_adjusted, bin_length_time, \
        number_mainshocks, mag_large_omori, mags, scale_factor, params, Location, USGS):
        
    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space\
            = ERASFileMethods.read_parameter_file()

        
    mag_threshold = mu + BathNumber
        
    bin_length = bin_length_time                 #   Days
    time_conversion = bin_length_time/365.
    
    print()
    print('From plot:  pfit_lo, pfit_hi', pfit_lo, pfit_hi)
    print()
    
    time_interval = 200.    #   In units of bin_length_time which is days
    number_bins = int(time_interval/bin_length_time)
    time_bins   = np.arange(bin_length, number_bins, bin_length)
    
    aftershock_number_bins = np.zeros(len(time_bins))
    
    kindex = 0
    
    for i in range(len(aftershock_list)):
    
        aftershock_sum = ERASCalcV5.sum_aftershock_intrvl(aftershock_list[i])
        
        duration = len(aftershock_list[i])
        
        if aftershock_sum > 0.:
        
            for j in range(1,len(aftershock_list[i])):
            
                try:
                    bin_index = int( (aftershock_list[i][j])/time_conversion ) + 1
                except:
                    bin_index = 1
                    
                if bin_index < duration:  # Are there aftershocks?
                    try:
                        aftershock_number_bins[bin_index] += 1
                    except:
                         pass
                         
    time_bins = [(time_bins[k]*bin_length) for k in range(len(time_bins)) ]
    
#     
    time_bins_reduced               =   []
    aftershock_number_bins_reduced  =   []
    
    time_bins_reduced               = time_bins[2:]
    aftershock_number_bins_reduced  = aftershock_number_bins[2:]
    
    #   Remove bins that have no events in them
    
    time_bins_to_plot               =   []
    aftershock_number_bins_to_plot  =   []
    
    for i in range(len(time_bins_reduced)):
        if aftershock_number_bins_reduced[i] > 0.:
            time_bins_to_plot.append(time_bins_reduced[i])
            aftershock_number_bins_to_plot.append(aftershock_number_bins_reduced[i])
            
    fig, ax = plt.subplots()
            
    ax.plot(time_bins_to_plot, aftershock_number_bins_to_plot, marker = 'o', color = 'blue', markersize = 4, lw = 0)
    
    #   Compute p-value
    time_lo = math.log10(pfit_lo)          
    time_hi = math.log10(pfit_hi)        

    number_data = [math.log10(aftershock_number_bins_to_plot[i]) for i in range(len(time_bins_to_plot))]
    time_data   = [math.log10(time_bins_to_plot[i]) for i in range(len(time_bins_to_plot))]

    time_line_data, number_line_data, slope, error = ERASCalcV5.calc_pq_value(number_data, time_data, time_lo, time_hi, 'p')
    
    pfit = - slope

    ax.plot(time_line_data, number_line_data, '--', color = 'red', markersize = 0, lw = 1.5)

#   Plot the best fitting line
    
    ax.set_yscale('log')
    ax.set_xscale('log')
    
    textstr1 =   ' Minimum Magnitude: ' + str(mu) +\
                '\n Input b-value: ' + str(bval)+\
                '\n Baths Law Number: ' + str(BathNumber)+\
                '\n Time Rescale Factor: ' + str(round(scale_factor,5))+\
                '\n Aftershock Step Lat: ' + str(round(step_lat,5))+ '$^o$'+\
                '\n Aftershock Step Lng: ' + str(round(step_lng,5))+ '$^o$'

 
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    # place a text box at lower left
    if USGS == False:
        ax.text(0.015, 0.02, textstr1, transform=ax.transAxes, fontsize=8,\
            verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)
            
    textstr2 =      ' Bin Length: ' + str(bin_length) + ' Day(s)'+\
                    '\n p-value (from fit): ' + str(round(pfit,2)) + ' $\pm$ ' + str(round(error,2))
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)
    ax.text(0.63, 0.975, textstr2, transform=ax.transAxes, fontsize=8,\
        verticalalignment='top', horizontalalignment = 'left', bbox=props, linespacing = 1.8)
 
    SupTitle_text = 'Aftershock Decay in Time'
    Title_text = 'For ' + str(number_mainshocks) +  ' Stacked ' + Location + ' Mainshocks with M > ' + str(mag_large_omori)
    plt.suptitle(SupTitle_text, fontsize=12)
    plt.title(Title_text, fontsize=10)

    plt.xlabel('Time After Mainshock (Days)')
    plt.ylabel('Number of Aftershocks')
    
    FigureName = './Figures/Omori_Aftershock_Decay_Time.png'
    plt.savefig(FigureName, dpi=200)
    
    plt.close()
    
    return
    
    ###############################################################################################
    
def plot_omori_aftershock_decay_space(label_events, x_events, y_events, step_lat, step_lng, space_multiplier,\
        bin_length_space, number_mainshocks, Location, USGS):
        
    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space\
            = ERASFileMethods.read_parameter_file()
            
    input_file_name = './Output_Files/ERAS_Time_Clustered.txt'
    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt' 
    
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)

    local_radius = 100. #   Km
    number_space_bins = int(local_radius/bin_length_space)
    
    space_bins = np.arange(bin_length_space, number_space_bins, bin_length_space)   

    aftershock_number_bins_space = np.ones(len(space_bins))
    
    #   ---------------------------------------------------
    
    x_events_adjusted   =   np.array(x_events)
    y_events_adjusted   =   np.array(y_events)
    
    delta_lat_array = np.zeros(len(y_events))
    delta_lng_array = np.zeros(len(x_events))
    radius_array    = np.zeros(len(x_events))
    
    lat_lng_ratio = step_lat/step_lng
    
    #   ---------------------------------------------------
        
    mainshock_flag = False

    for i in range(len(x_events)):
#     
#     for i in range(200):
    
        if mainshock_flag == False:
            mainshock_lat = y_events[i]
            mainshock_lng = x_events[i]
    
        if label_events[i] == 'b' and mags[i] > mu + BathNumber:
            mainshock_lat = y_events[i]
            mainshock_lng = x_events[i]
            mainshock_flag = True
            
        if label_events[i] == 'a' and mainshock_flag:
        
            delta_lat_array[i] = space_multiplier * lat_lng_ratio *(y_events[i] - mainshock_lat)
            delta_lng_array[i] = space_multiplier * (x_events[i] - mainshock_lng)
            
            y_events_adjusted[i] += delta_lat_array[i]
            x_events_adjusted[i] += delta_lng_array[i]
            
            great_circle_distance = ERASUtilities.compute_great_circle_distance\
                                (mainshock_lat, mainshock_lng, y_events_adjusted[i], x_events_adjusted[i])
            if USGS:
                great_circle_distance = ERASUtilities.compute_great_circle_distance\
                            (mainshock_lat, mainshock_lng, y_events[i], x_events[i])
            
            radius_array[i] = great_circle_distance
        
            try:
                bin_index_space = int(great_circle_distance/bin_length_space) + 1
            except:
                space_bin_index_space = 1
                    
            if bin_index_space < len(space_bins) and label_events[i] == 'a':
                aftershock_number_bins_space[bin_index_space] += 1
           
    #   ---------------------------------------------------

    plot_counter = 0
    for i in range(len(space_bins)):
        j = len(space_bins) - i -1
        if aftershock_number_bins_space[j] > 0.0:     #   With this catalog, we need to stop at about 80 - maybe the minimum time
                                                #       between mag_large events
            plot_counter += 1
#     
    space_bins = [(space_bins[k]*bin_length_space) for k in range(len(space_bins)) ]
    
    space_bins_reduced                      =   []
    aftershock_number_bins_space_reduced    =   []
    
    space_bins_reduced                      = space_bins[3:plot_counter]
    aftershock_number_bins_space_reduced    = aftershock_number_bins_space[3:plot_counter]
    
    #   Remove bins that have no events in them
    
    space_bins_to_plot                      =   []
    aftershock_number_bins_space_to_plot    =   []
    
    for i in range(len(space_bins_reduced)):
        if aftershock_number_bins_space_reduced[i] > 0.001:
            space_bins_to_plot.append(space_bins_reduced[i])
            aftershock_number_bins_space_to_plot.append(aftershock_number_bins_space_reduced[i])
            
    fig, ax = plt.subplots()
    ax.plot(space_bins_to_plot, aftershock_number_bins_space_to_plot, marker = 'o', color = 'blue', markersize = 4, lw = 0)

    #     Compute q-value
    space_lo = math.log10(qfit_lo)          
    space_hi = math.log10(qfit_hi)        

    number_data = [math.log10(aftershock_number_bins_space_to_plot[i]) for i in range(len(space_bins_to_plot))]
    space_data   = [math.log10(space_bins_to_plot[i]) for i in range(len(space_bins_to_plot))]

    space_line_data, number_line_data, slope, qerror = ERASCalcV5.calc_pq_value(number_data, space_data, space_lo, space_hi, 'q')
    
    qfit = - slope
    
    ax.plot(space_line_data, number_line_data, '--', color = 'red', markersize = 0, lw = 1.5)

    radius_mean, radius_std = ERASCalcV5.calc_migration_radius(space_bins_to_plot, aftershock_number_bins_space_to_plot, USGS)

    ax.set_yscale('log')
    ax.set_xscale('log')
#     
    textstr1 =   ' Minimum Magnitude: ' + str(mu) +\
                '\n Input b-value: ' + str(bval)+\
                '\n Baths Law Number: ' + str(BathNumber)+\
                '\n Time Rescale Factor: ' + str(round(scale_factor,5))+\
                '\n Aftershock Step Lat: ' + str(round(step_lat,5))+ '$^o$'+\
                '\n Aftershock Step Lng: ' + str(round(step_lng,5))+ '$^o$'

 
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    #   place a text box at lower left
    if USGS == False:
        ax.text(0.015, 0.02, textstr1, transform=ax.transAxes, fontsize=8,\
            verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)
#             
    textstr2 =      ' Bin Length: ' + str(bin_length_space) + ' (KM)'+\
                    '\n q-value (from fit): ' + str(round(qfit,2)) + ' $\pm$ ' + str(round(qerror,2))
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)
    ax.text(0.63, 0.975, textstr2, transform=ax.transAxes, fontsize=8,\
        verticalalignment='top', horizontalalignment = 'left', bbox=props, linespacing = 1.8)
# #  
    SupTitle_text = 'Aftershock Decay in Space' 
    Title_text = 'For ' + str(number_mainshocks) +  ' Stacked ' + Location + ' Mainshocks with M > ' + str(mag_large_omori)
    plt.suptitle(SupTitle_text, fontsize=12)
    plt.title(Title_text, fontsize=10)

    plt.xlabel('Distance from Mainshock (KM)')
    plt.ylabel('Number of Aftershocks')
    
    FigureName = './Figures/Omori_Aftershock_Decay_Space.png'

    plt.savefig(FigureName, dpi=200)
    
    plt.close()

    return  
    
    ###############################################################################################
    
def map_seismicity(NELat_local, NELng_local, SWLat_local, SWLng_local, plot_start_year, \
        Location, catalog, mag_large, min_map_mag, mu, forecast_intervals, \
        date_array, time_array, year_array, lng_array, lat_array, mag_array, depth_array, params, USGS):
        

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()

        
    mag_threshold = mu + BathNumber

    #   Note:  This uses the new Cartopy interface
    #
    #   -----------------------------------------
    #
    #   Define plot map
    
    dateline_crossing = False
    
    #   Define coordinates
    left_long   = SWLng_local
    right_long  = NELng_local
    top_lat     = SWLat_local
    bottom_lat  = NELat_local
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    longitude_labels = [left_long, right_long]
    longitude_labels_dateline = [left_long, 180, right_long, 360]   #   If the map crosses the dateline
    
    central_long_value = 0
    if dateline_crossing:
        central_long_value = 180
        
    ax = plt.axes(projection=ccrs.PlateCarree(central_longitude=central_long_value))
    ax.set_extent([left_long, right_long, bottom_lat, top_lat])
    
    # Create a feature for States/Admin 1 regions at 1:50m from Natural Earth
    states_provinces = cfeature.NaturalEarthFeature(
        category='cultural',
        name='admin_1_states_provinces_lines',
        scale='50m',
        facecolor='none')

    land_10m = cfeature.NaturalEarthFeature('physical', 'land', '10m',
                                        edgecolor='face',
                                        facecolor='coral')
                                        

                                        
    ocean_10m_3000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_H_3000', '10m',
#                                         edgecolor='black',
                                        facecolor='#0000FF',
                                        alpha = 0.3)
                                        

                                        
    lakes_10m = cfeature.NaturalEarthFeature('physical', 'lakes', '10m',
#                                        edgecolor='black',
                                        facecolor='blue',
                                        alpha = 0.75)
                                        
    rivers_and_lakes = cfeature.NaturalEarthFeature('physical', 'rivers_lakes_centerlines', '10m',
#                                        edgecolor='aqua',
                                        facecolor='blue',
                                        alpha = 0.75)

    ax.add_feature(ocean_10m_3000)

    ax.add_feature(cfeature.BORDERS, linestyle='-', alpha=.5, linewidth=0.5)
    ax.add_feature(cfeature.LAKES, alpha=0.95)
    ax.add_feature(cfeature.RIVERS, linewidth= 0.5)
    ax.add_feature(cfeature.STATES, edgecolor='gray',linewidth= 0.5)
#     ax.add_feature(states_provinces, edgecolor='gray')
    ax.coastlines(resolution='10m', color='black', linewidth=0.5)
    
    # These all work.  Note that the api key is embedded in the img_tiles.py code on this computer
#     style = "stamen_terrain_background"
#     zoom_level = 8
#     apikey = 'Your API Key'
#     stadia_tiles = StadiaMapsTiles(style=style)
#     ax.add_image(stadia_tiles, zoom_level)
    
    if dateline_crossing == False:
        gl = ax.gridlines(crs = ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.25, color='black', alpha=0.5, linestyle='dotted')
                   
    if dateline_crossing == True:
        gl = ax.gridlines(xlocs=longitude_labels_dateline, draw_labels=True,
                   linewidth=1.0, color='white', alpha=0.5, linestyle='--')

    gl.top_labels = False
    gl.right_labels = False
    gl.xlines = True
    gl.ylines = True

    if catalog == 'LosAngeles':
        gl.xlocator = mticker.FixedLocator([-112,-114,-116, -118, -120, -122])
    
    if catalog == 'Tokyo':
        gl.xlocator = mticker.FixedLocator([132,134,136, 138, 140, 142, 144, 146])

    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    
    gl.xlabel_style = {'size': 12, 'color': 'black'}
    gl.ylabel_style = {'size': 12, 'color': 'black'}
    
    #   -----------------------------------------
    #   Put california faults on the map
    
    input_file_name = './California_Faults.txt'
    input_file  =   open(input_file_name, 'r')
    
    for line in input_file:
        items = line.strip().split()
        number_points = int(len(items)/2)
        
        for i in range(number_points-1):
            x = [float(items[2*i]),float(items[2*i+2])]
            y = [float(items[2*i+1]), float(items[2*i+3])]
            ax.plot(x,y,'-', color='darkgreen',lw=0.55, zorder=2)
    
    input_file.close()
    #    
    #   -----------------------------------------
    #
    #   Plot the data
    
    for i in range(len(mag_array)): #   First plot them all as black dots
        if float(mag_array[i]) >= min_map_mag and float(year_array[i]) >= plot_start_year:
            ax.plot(float(lng_array[i]), float(lat_array[i]), '.k', ms=0.5, zorder=1)
        
        if float(mag_array[i]) >= 6.0 and float(mag_array[i]) < 6.89999  and float(year_array[i]) >= plot_start_year:
 #            ax.plot(float(lng_array[i]), float(lat_array[i]), 'g*', ms=11, zorder=2)
            ax.plot(float(lng_array[i]), float(lat_array[i]), 'o', mec='b', mfc='None', mew=1.25, \
                ms=6, zorder=2)
            
        if float(mag_array[i]) >= 6.89999 and float(year_array[i]) >= plot_start_year:
#             ax.plot(float(lng_array[i]), float(lat_array[i]), 'y*', ms=15, zorder=2)
            ax.plot(float(lng_array[i]), float(lat_array[i]), 'o', mec='r', mfc='None', mew=1.25,\
                ms=12, zorder=2)
# 
    lower_mag = min_map_mag

    ax.plot([], [], '.k', ms=0.5, zorder=4, label='$5.9 > M \geq $'+str(lower_mag) )
                    
    ax.plot([], [], 'o', mec='b', mfc='None', mew=1.25, ms=6, zorder=4, label='\n$6.9 > M \geq 6.0$')
                    
    ax.plot([], [], 'o', mec='r', mfc='None', mew=1.25, ms=12, zorder=4, label='\n$M \geq 6.9$')
                    
    title_text = 'Magnitude Key'
    leg = ax.legend(loc = 'lower left', title=title_text, fontsize=6, fancybox=True, framealpha=0.5)
    leg.set_title(title_text,prop={'size':8})   #   Set the title text font size
    
    textstr =   ' Minimum Magnitude: ' + str(mu) +\
                '\n b-value: ' + str(bval)+\
                '\n Baths Law Number: ' + str(BathNumber)+\
                '\n Time Rescale Factor: ' + str(round(scale_factor,5))+\
                '\n Aftershock Step Lat: ' + str(round(step_lat,5))+ '$^o$'+\
                '\n Aftershock Step Lng: ' + str(round(step_lng,5))+ '$^o$'+\
                '\n Aftershock Cluster Factor: ' + str(scale_factor)

 
    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    # place a text box at upper right
    if USGS == False:
        ax.text(0.985, 0.98, textstr, transform=ax.transAxes, fontsize=5,\
            verticalalignment='top', horizontalalignment = 'right', bbox=props, linespacing = 1.8)

    SupTitle_text = ' Seismicity for $M\geq$' + str(min_map_mag)  + ' after ' + str(plot_start_year) 
    plt.suptitle(SupTitle_text, fontsize=14, y=0.98)
#     
    if USGS == False:
#         Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location +\
#             ', Hyper-Parameter Values Displayed in Legend'

        Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location 
        plt.title(Title_text, fontsize=10)
    else:
        Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location 
        plt.title(Title_text, fontsize=8)
    
    
    #   -------------------------------------------------------------

    figure_name = './Figures/Seismicity_Map_' + Location + '_' + str(plot_start_year) + '.png'
    plt.savefig(figure_name,dpi=600)

    plt.close()

    #   -------------------------------------------------------------
    
    return None

    ######################################################################