
    #   ---------------------------------------------------------------------------------------
    
    # Copyright 2023 by John B Rundle, University of California, Davis, CA USA
    # 
    # Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
    # documentation files (the     "Software"), to deal in the Software without restriction, including without 
    # limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
    # and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
    # 
    # The above copyright notice and this permission notice shall be included in all copies or suSKLantial portions of the Software.
    # 
    # THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
    # WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
    # COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRAC TORT OR OTHERWISE, 
    # ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
    #
    # Note that some part of these codes were written by the AI program chatGP a product of openai.com
    #
    # This particular code is based on the version ERAS_ChatGPT_V2.13
    #
    #   ERAS is the "Rescaled Aftershock Method for Stochastic Earthquake Seismicity"
    #
    #   ---------------------------------------------------------------------------------------
    ###############################################################################################
    ###############################################################################################

import os
import sys

import numpy as np
np.set_printoptions(legacy='1.25')
import random
import matplotlib.pyplot as plt
import math
from math import log10

import time

import ERASCalcV5
import ERASCalcMethodsSEISR
import ERASPlotV3
import ERASFileWriter
import ERASFileMethods
import ERASUtilities

import Compute_EMA_Timeseries

from datetime import datetime

    ###############################################################################################
    ###############################################################################################
                                                            #   READ INITIAL VERSION OF INPUT PARAMS

mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
        pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
        = ERASFileMethods.read_parameter_file()


    ###############################################################################################
    ###############################################################################################
                                                                                    #   INPUT FLAGS
                                                                                    
download_USGS_catalog                               = False     #    Set this flag to True before any other run if
                                                                #       if the ERAS_USGS.txt file does not exist

generate_and_write_new_optimal_catalog              = False     #   To generate a new optimal time space clustered catalog
write_time_space_clustered_catalog_from_unclustered = False     #   Generate a new catalog using the parameters.txt file
write_time_space_clustered_catalog_new_unclustered  = False     #   Generate a new catalog using the parameters.txt file

USGS                                                = False     #   To plot values from the data catalog

plot_magnitude_time                                 = False     #   To plot magnitude vs. time for the raw (unclustered) catalog
plot_magnitude_time_clustered                       = False     #   To plot magnitude vs. time for the clustered catalog

plot_magnitude_frequency                            = False     #   To plot magnitude vs. frequency (GRR diagram)

plot_omori_clustered_events                         = False     #   To plot both Omori-type spatial frequency vs. distance 
                                                                #       and temporal frequency vs. time following the mainshock

plot_number_events_vs_time                          = False     #   To plot number of events vs. time

plot_number_vs_time_and_GRR_one_mainshock_days      = False     #   To plot number vs. time and GRR following a mainshock in days
plot_number_vs_time_and_GRR_one_mainshock_hours     = False     #   To plot number vs. time and GRR following a mainshock in hours

plot_LA_seismicity_map                              = False     #   To plot a map of seismicity.  If you want topography on the map
                                                                #       you have to get a map key for Stadia Maps Tiles

plot_EMA_timeseries                                 = False     #   Plot a nowcast curve using the Exponential Moving Average

data_catalog = 'LosAngeles'
ERAS_catalog = 'ERASLosAngeles'

if download_USGS_catalog:
    plot_params = False
    USGS = True
    generate_and_write_new_optimal_catalog          = False     #   Generates a catalog and writes the file
    write_time_space_clustered_catalog              = False     #   Generates a catalog and writes the file

    #   -------------------------------

#   Compute model parameters: rescale factor and lat, lng step sizes
#       Set these flags to True if you want to re-calculate these items
#       Then enter the new values into the parameters.txt file

calculate_random_walk_step_size                     = False     #   Analyzes the USGS catalog to calculate the random walk step size
calculate_optimal_time_scale_factor                 = False     #   Finds the optimal scale factor for temporal Omori plot
calculate_optimal_space_scale_factor                = False     #   Finds the optimal scale factor for spatial Omori plot


    #   -------------------------------
# 
    ###############################################################################################
    ###############################################################################################
    
    #   BEGIN LOCATION INPUTS
    
    ###############################################################################################
    ###############################################################################################
    
    #   Note that the input hyperparameters are in file "location_input_data.csv"
    
input_file = open("location_input_data.csv", "r")   #   At the momen the four location choices are:
                                                        #   Los Angeles, Tokyo, Greece and Chile
    
catalog = ERAS_catalog  #   Specifies the name of the catalog, the current region of interest.  Hyperparameter data is stored
                            #       in the file:   location_input_data.csv
                            
if USGS:               #    The following input is in case the USGS catalog has been previously downloaded
    catalog = data_catalog
    
for line in input_file:
    items = line.strip().split(',')

    if items[0] == catalog:
        Location = items[1]
        plot_start_year = float(items[2])
            
        center_lat = float(items[3])
        center_lng = float(items[4])
            
        delta_lat = float(items[5])     #   For the base catalog
        delta_lng = float(items[6])
            
        NELng = center_lng + delta_lng
        SWLng = center_lng - delta_lng
        NELat = center_lat + delta_lat
        SWLat = center_lat - delta_lat
        
        max_depth = float(items[7])
            
        mu = float(items[8])
        delta_deg = float(items[9]) #   For the regional catalog, which is a subset of base catalog
        
        grid_size = float(items[10])    #   Spatial grid box size in Degrees
            
        delta_deg_lat = delta_deg
        delta_deg_lng = delta_deg
            
        NELng_local = center_lng + delta_deg
        SWLng_local = center_lng - delta_deg
        NELat_local = center_lat + delta_deg
        SWLat_local = center_lat - delta_deg
        
        mag_large = float(items[11])        #   Defines the magnitude used for the ROC and Precision tests
        min_mag = float(items[12])        #   Defines the magnitude of the small earthquakes used
            
        lambda_max_mult = float(items[13])  #   Defines the minimum monthly seismicity rate, improves skill
        lambda_min_mult = float(items[14])  #   Defines a maximum rate to approximately compensate for the existence
                                                #       of a huge earthquake that overwhelms the other events.  It removes
                                                #       some of the small earthquakes and evens out the catalog
        NSteps = float(items[15])
            
        forecast_intervals = [float(items[16])]
            
input_file.close()

    ###############################################################################################
    ###############################################################################################

mag_threshold = mu + BathNumber         #   Only events with mags larger than this can have aftershocks

#   Rewrite input params in case anything has changed

params = [mu, mag_large_omori, mag_large, max_swarm_mag,  bval, \
        BathNumber, step_lat, step_lng, scale_factor, pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, \
        bin_length_time, bin_length_space]
        

ERASFileMethods.write_parameter_file(params)

    ###############################################################################################
    ###############################################################################################

def define_USGS_parameters(catalog):

    #   Note that the input hyperparameters are in file "location_input_data.csv"
    
    input_file = open("location_input_data.csv", "r")   #   At the momen the four location choices are:
                                                        #   Los Angeles, Tokyo, Greece and Chile
    
#     Example: catalog = 'Greece'  #   Specifies the name of the catalog, the current region of interest.  Hyperparameter data is stored
#                             #       in the file:   location_input_data.csv
    
    for line in input_file:
        items = line.strip().split(',')

        if items[0] == catalog:
            Location = items[1]
            plot_start_year = float(items[2])
            
            center_lat = float(items[3])
            center_lng = float(items[4])
            
            delta_lat = float(items[5])     #   For the base catalog
            delta_lng = float(items[6])
            
            NELng = center_lng + delta_lng
            SWLng = center_lng - delta_lng
            NELat = center_lat + delta_lat
            SWLat = center_lat - delta_lat
            
            max_depth = float(items[7])
            completeness_mag = float(items[8])

            
            delta_deg = float(items[9]) #   For the regional catalog, which is a subset of base catalog
            
            delta_deg_lat = delta_deg
            delta_deg_lng = delta_deg
            
            NELng_local = center_lng + delta_deg
            SWLng_local = center_lng - delta_deg
            NELat_local = center_lat + delta_deg
            SWLat_local = center_lat - delta_deg
            
            grid_size = float(items[10])    #   Spatial grid box size in Degrees
            
            mag_large = float(items[11])        #   Defines the magnitude used for the ROC and Precision tests
            min_mag = float(items[12])        #   Defines the magnitude of the small earthquakes used
            
            lambda_max_mult = float(items[13])  #   Defines the minimum monthly seismicity rate, improves skill
            lambda_min_mult = float(items[14])  #   Defines a maximum rate to approximately compensate for the existence
                                                #       of a huge earthquake that overwhelms the other events.  It removes
                                                #       some of the small earthquakes and evens out the catalog
                                                
            forecast_intervals = [float(items[16])]
            
    input_file.close()

    return NELat, NELng, SWLat, SWLng, completeness_mag, start_date, \
            NELat_local, NELng_local, SWLat_local, SWLng_local, min_mag, max_depth
    
    #################################################################
    
    #   Overridden  or Other Variables

min_map_mag = mu
min_mag = mu

 
region_catalog_date_start = plot_start_year      #   Must be the same as start_date, but digital
start_date = str(int(region_catalog_date_start)) + "/01/01"

region_catalog_date_end   = 2030.0


    ###################################################################################################################
    ###################################################################################################################
    #                                                                                                          METHODS
    
def write_output_files(date_file, time_file, year_file, x_events, y_events, z_events, mags, label_events,\
        text_file_name, csv_file_name):

    nowcast_output=open(text_file_name, 'w').close()    #   Remove existing data
    
    nowcast_output=open(text_file_name, 'w')
    
    for i in range(len(year_file)):
        print(date_file[i], '\t', time_file[i], '\t', year_file[i], '\t', round(x_events[i],4),'\t', round(y_events[i],4),'\t', mags[i], \
                '\t', round(z_events[i],4), '\t', label_events[i], file = nowcast_output)

    nowcast_output.close()
    
    input_file = text_file_name

    output_file = csv_file_name
    
    ERASFileWriter.text_to_csv(input_file, output_file)
    
    return

    #################################################################
    
def recluster_times(mu, mag_large, year_events, mags, label_events, scale_factor, input_file_name):

    #   ---------------------------------------------------

    mag_large = max(mags) - BathNumber       #   Largest aftershock possible
    
    mag_increment = 0.1
    
    mag_small = mu + mag_increment
    
    #   Top down seems to give larger p-Values
    mag_small_temp = mag_small          #   Bottom up -- Much better for individual events
    
    year_adjusted = year_events
    duration_flag = True
    
    #   ---------------------------------------------------
    
    number_mag_levels = int((mag_large - mag_small)/mag_increment)
    
    mag_count = 0
    for i in range(len(mags)):
        if mags[i] >= 6.75:
            mag_count += 1

    for i in range(number_mag_levels):
    
        number_mainshocks = 0
        for j in range(len(mags)):
            if(mags[j] >= mag_small_temp):
                number_mainshocks += 1
                
        cycle_list, label_cycle_list = ERASCalcV5.mainshock_cycles(mags, year_adjusted, label_events, mag_small_temp)
        
        year_adjusted, aftershock_list = \
                ERASCalcV5.omori_recluster(cycle_list, label_cycle_list, year_adjusted, mags, scale_factor)
        
#         mag_small_temp -= mag_increment       #   If top down
        mag_small_temp += mag_increment         #   If bottom up
        
        
    date_adjusted                       = []
    time_adjusted                       = []
    
    #   ---------------------------------------------------
    
    # Get today's date
    today = datetime.today()
    
    print('today',today)
    
    date = today
    start_date = datetime(date.year, 1, 1)
    end_date = datetime(date.year + 1, 1, 1)
    year_duration = (end_date - start_date).total_seconds()
    current_duration = (date - start_date).total_seconds()
    todays_decimal_year = date.year + current_duration / year_duration
    
    #   ---------------------------------------------------
    
#     # Calculate decimal years
    
    print()
    print('Today, todays_decimal_year: ', today, todays_decimal_year)
    print()
    print('Reclustering the Data')
    print()
# 
    for i in range(len(year_adjusted)):
        decimal_year = region_catalog_date_start + (todays_decimal_year - region_catalog_date_start)*\
                year_adjusted[i]/(max(year_adjusted))
        date_of_event, time_of_day = ERASCalcV5.decimal_year_to_date(decimal_year)
        date_adjusted.append(date_of_event)
        time_adjusted.append(time_of_day)
        
    number_aftershocks = 0
    for i in range(len(aftershock_list)):
        for j in range(len(aftershock_list[i])):
            number_aftershocks += 1
            
    return date_adjusted, time_adjusted, year_adjusted, aftershock_list
    
    ###############################################################################################

def read_existing_catalog(input_file_name):

    mags                    =   []
    date_events             =   []
    time_events             =   []
    year_events             =   []
    depth_events            =   []
    y_events                =   []
    x_events                =   []
    label_events            =   []

    data_file = open(input_file_name,"r")
    
    for line in data_file:
        items = line.strip().split()
        
        date_events.append(items[0])
        time_events.append(items[1])
        year_events.append(float(items[2]))
        x_events.append(float(items[3]))
        y_events.append(float(items[4]))
        mags.append(float(items[5]))
        depth_events.append(float(items[6]))
        label_events.append(items[7])
        
    data_file.close()  
    
    return date_events, time_events, year_events, x_events, y_events, mags, depth_events, label_events
    
    ###############################################################################################
    
def optimize_time_scale_factor():

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()
    
    plot_params = False
    USGS = True
    generate_and_write_new_catalog  = False
    write_time_space_clustered_catalog = False
    plot_magnitude_time = False     #   Usually plots the ERAS unclustered catalog
    os.system("python USGS_to_ERAS.py")
    
    input_file_name = './Output_Files/ERAS_USGS.txt' 
    
    date_events_USGS, time_events_USGS, year_events_USGS, x_events_USGS, y_events_USGS, mags_USGS, z_events_USGS, label_events_USGS = \
            read_existing_catalog(input_file_name)

    cycle_list_USGS, label_cycle_list_USGS = ERASCalcV5.mainshock_cycles(mags_USGS, year_events_USGS,label_events_USGS, mag_large_omori)
    
    temp_scale_factor = 1.e6  #   We just need the cycle_list for the adjusted catalog to get the aftershock_list
                             #       So set the aftershock multiplier = 1 by setting scale_factor -> infinity
    
    year_adjusted_USGS, aftershock_list_USGS = \
            ERASCalcV5.omori_recluster(cycle_list_USGS, label_cycle_list_USGS, year_events_USGS, mags_USGS, temp_scale_factor)
    
    pvalue_obs, perror_obs = ERASCalcV5.compute_pvalue(pfit_lo, pfit_hi, aftershock_list_USGS, bin_length_time)
    
    
    print()
    print('     -----------------------------------------------')
    print()
    print('OPTIMIZING TIME SCALE FACTOR BY RECLUSTERING DATA...')
    print()
    print('Observed p-Value: ', round(pvalue_obs,3), ' +/- ', round(perror_obs,3))
    print()
    print('USGS? :', USGS)
    print()
    print('     -----------------------------------------------')
    print()
    
    #   -------------------------------------------------------------

    test_scale_max              = 2.5
    test_scale_increment = 0.1
    test_scale_min       = 0.
    
    iteration_max               = int((test_scale_max - test_scale_min)/test_scale_increment)

    USGS = False
    
    test_scale_list_display     =   []
    pvalue_list_display         =   []

    write_files = True
      
    #   -------------------------------------------------------------
    
    #   Commands
    cmd_optimal1 = 'mv ./Output_Files/ERAS_Time_Clustered.txt ./Output_Files/ERAS_Temp.txt'
    cmd_optimal2 = 'mv ./Output_Files/ERAS_Time_Clustered_Aftershocks.txt ./Output_Files/ERAS_Temp_Aftershocks.txt'
    
    cmd_optimal3 = 'mv ./Output_Files/ERAS_Temp.txt ./Output_Files/ERAS_Time_Clustered.txt'
    cmd_optimal4 = 'mv ./Output_Files/ERAS_Temp_Aftershocks.txt ./Output_Files/ERAS_Time_Clustered_Aftershocks.txt'
#     
    input_file_name_unclustered = './Output_Files/ERAS_Unclustered.txt'             #   Baseline
    input_file_name_clustered   = './Output_Files/ERAS_Time_Clustered.txt'          #   Baseline
    
    input_file_name_unclustered = './Output_Files/ERAS_Unclustered_Aftershocks.txt'
    input_file_name_clustered   = './Output_Files/ERAS_Time_Clustered_Aftershocks.txt'
    
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events =\
            read_existing_catalog(input_file_name_unclustered)
    
    bval_fit, bval_error, cept_fit, cept_error = ERASCalcV5.calc_GR(mags, mu, BathNumber, mag_large)
    
    #   -------------------------------------------------------------
    
    pvalue_flag = False
    
    kk = 0
    
    for kk in range(iteration_max):
    
        if pvalue_flag:
            break
    
        test_scale_factor = test_scale_min + (iteration_max - kk)*test_scale_increment  #   Start at the top
        
        aftershock_list, year_adjusted = generate_time_clustered_catalog(write_files, test_scale_factor)
        
        date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events =\
            read_existing_catalog(input_file_name_clustered)
        
        temp_scale_factor = 1.e6  #   We just need the cycle_list for the adjusted catalog to get the aftershock_list
                             #       So set the aftershock multiplier = 1 by setting scale_factor -> infinity
            
        cycle_list, label_cycle_list = ERASCalcV5.mainshock_cycles(mags, year_events,label_events, mag_large_omori)
        
        year_adjusted, aftershock_list = \
            ERASCalcV5.omori_recluster(cycle_list, label_cycle_list, year_events, mags, temp_scale_factor)
    
        pvalue, perror = ERASCalcV5.compute_pvalue(pfit_lo, pfit_hi, aftershock_list, bin_length_time)
        
        if round(abs(pvalue-pvalue_obs),3) < 2.*perror_obs:

            pvalue_flag = True  #   Found an optimal value
            pvalue_diff = round(abs(pvalue-pvalue_obs),3)
            pvalue_optimal = pvalue
            perror_optimal = perror
            scale_factor_optimal = test_scale_factor
            os.system(cmd_optimal1)                     # Save this file to a temp file
            os.system(cmd_optimal2)
        
        #   >> Make the check for optimal p-value here, and save the clustered file if p is best so far 
        #       using a os.system(cp clutered_file to some other file, then save to scale invariant file at the end)
        
        print()
        print('     -----------------------------------------------')
        print()
        print('OPTIMIZING TIME SCALE FACTOR BY RECLUSTERING DATA...')
        print()
        print('b-Value of Simulated Catalog: ', round(bval_fit,3), ' +/- ', round(bval_error, 3))
        print()
        print('Iteration: ', kk+1, 'of', iteration_max)
        print()
        print('Observed p-Value: ', round(pvalue_obs,3), ' +/- ', round(perror_obs,3))
        print()
        print('Scale Factor: ', round(test_scale_factor,5), 'Simulated p-Value: ', round(pvalue, 3), ' +/- ', round(perror,3))
        print()
        print('USGS? :', USGS)
        print()
        print('     -----------------------------------------------')
        
        test_scale_list_display.append(round(test_scale_factor,2))
        pvalue_list_display.append(round(pvalue,3))
        
        print()
        print('test_scale_list: ', test_scale_list_display)
        print('    pvalue_list: ',pvalue_list_display)
        print()
        
        
    os.system(cmd_optimal3) #   Move the saved temp file back to the scale invariant file
    os.system(cmd_optimal4)
    
    pvalue_optimal = pvalue
    scale_factor_optimal = round(test_scale_factor,6)
    
    scale_factor = scale_factor_optimal
    
    print()
    print('Observed p-Value: ', round(pvalue_obs,3), ' +/- ', round(perror_obs,3))   
    print()
    print('Optimal Scale Factor = ', round(scale_factor_optimal,6), ' for Best p-Value = ', round(pvalue_optimal,3))
    print()
    print('USGS? :', USGS)
    print()
    print('     -----------------------------------------------')
    
    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
        pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
        = ERASFileMethods.read_parameter_file()
        
    params = [mu, mag_large_omori, mag_large, max_swarm_mag,  bval, \
        BathNumber, step_lat, step_lng, scale_factor_optimal, pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, \
        bin_length_time, bin_length_space]
        
    ERASFileMethods.write_parameter_file(params)
    
    return scale_factor_optimal, pvalue_optimal, perror_optimal, pvalue_obs, perror_obs

    ###############################################################################################
    
def optimize_space_scale():

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()

    plot_params = False
    USGS = True
    generate_and_write_new_catalog  = False
    write_time_space_clustered_catalog = False
    plot_magnitude_time = False     #   Usually plots the ERAS unclustered catalog
    Location = 'Los Angeles'
    os.system("python USGS_to_ERAS.py")
    
    input_file_name = './Output_Files/ERAS_USGS.txt' 
    
    date_events_USGS, time_events_USGS, year_events_USGS, x_events_USGS, y_events_USGS, mags_USGS, z_events_USGS, label_events_USGS = \
            read_existing_catalog(input_file_name)

    temp_space_multiplier = 0.
    
    qvalue_obs, qerror_obs, x_events_USGS, y_events_USGS, radius_mean_obs, radius_std_obs, OBS_space_bins, OBS_number_values = \
            ERASCalcV5.compute_rescaled_aftershock_locations\
            (temp_space_multiplier,USGS)
    
    #   Not used at the moment
    space_norm = sum(OBS_number_values)
    space_prob = [OBS_number_values[i]/space_norm for i in range(len(OBS_number_values))]
    
    #   -------------------------------
    print()
    print('************************************************')
    print()
    print('  USGS Mean Migration Distance: ', round(radius_mean_obs,3), ' +/- ', round(radius_std_obs,3), ' KM' )
    print()
    print('USGS? :', USGS)
    print()
    print('************************************************')
    print()
    #   -------------------------------
            
    #   ---------------------------------------------------
            
    test_space_multiplier_range = 0.5
    test_space_multiplier_base  = 0.0
    
    space_scale_list        =   []
    q_value_list            =   []
    
    input_file_name_unclustered = './Output_Files/ERAS_Unclustered.txt'
    input_file_name_clustered   = './Output_Files/ERAS_Time_Clustered.txt'
    
    output_text_file_name = './Output_Files/ERAS_Time_Space_Clustered.txt'
    output_csv_file_name  = './Output_Files/ERAS_Time_Space_Clustered.csv'
    
    date_events_cl, time_events_cl, year_events_cl, x_events, y_events, mags, z_events, label_events =\
            read_existing_catalog(input_file_name_clustered)
    
    i = 0
    qvalue = 100.   #   Dummy values to begin
    qerror = 0.     #   Dummy values to begin
    
    radius_mean = 1000. #   Dummy values to begin
    radius_std  = 0.    #   Dummy values to begin
    
    iteration_max = 1000
    
    USGS = False
    
    while round(abs(qvalue-qvalue_obs),5) > 2.0*qerror_obs and i < iteration_max:

        test_space_multiplier = test_space_multiplier_base + np.random.uniform(-2.,2.)*test_space_multiplier_range
        
        qvalue, qerror, x_events_temp, y_events_temp, radius_mean, radius_std, ERAS_space_bins, ERAS_number_values = \
                ERASCalcV5.compute_rescaled_aftershock_locations\
                (test_space_multiplier, USGS)
                
        space_scale_list.append(round(test_space_multiplier,4))
        q_value_list.append(round(qvalue,3))
        
        i += 1
        
    #   
    if i == iteration_max:      #   Couldn't find an optimal value, take the next best
        test_array   =  []
        for j in range(len(q_value_list)):
            test_argument = abs(q_value_list[j] - qvalue_obs)
            test_array.append(test_argument)
        min_index = np.argmin(test_array)
        
        qvalue_optimal = round(q_value_list[min_index],3)
        space_multiplier_optimal = round(space_scale_list[min_index],6)
        
    #   -------------------------------
    print()
    print('************************************************')
    print()
    print('  Optimal Mean Migration Distance: ', round(radius_mean,3), ' +/- ', round(radius_std,3), ' KM' )
    print()
    print('USGS? :', USGS)
    print()
    print('************************************************')
    print()
    #   -------------------------------
        
    print()
    print('q_value_list',q_value_list)
        
    qvalue_optimal = qvalue
    space_multiplier_optimal = round(test_space_multiplier,6)
    
    space_multiplier = round(space_multiplier_optimal,6)
    
    print()
    print('Observed q-Value: ', round(qvalue_obs,3), ' +/- ', round(qerror_obs,3))   
    print()
    print('Optimal Space Multiplier = ', round(space_multiplier_optimal,6), ' for Best q-Value = ', round(qvalue_optimal,3))
    print()
    print('USGS? :', USGS)
    if i >= iteration_max:
        print()
        print('     ##############################################################################')
        print()
        print('Could not find a q-value for this simulation catalog that satisifies the observed q-value')
        print('....try running the code again...')
        print()
        print('     ##############################################################################')
    print()
    print('     -----------------------------------------------')
    print()
    
    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
        pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
        = ERASFileMethods.read_parameter_file()

    params = [mu, mag_large_omori, mag_large, max_swarm_mag,  bval, \
        BathNumber, step_lat, step_lng, scale_factor, pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier_optimal, \
        bin_length_time, bin_length_space]
        
    ERASFileMethods.write_parameter_file(params)
    
    output_text_file_name = './Output_Files/ERAS_Time_Space_Clustered.txt'
    output_csv_file_name  = './Output_Files/ERAS_Time_Space_Clustered.csv'
    
    write_output_files(date_events_cl, time_events_cl, year_events_cl, x_events_temp, y_events_temp, z_events, mags, label_events,\
        output_text_file_name, output_csv_file_name)
    
    return space_multiplier_optimal, qvalue_optimal
    
    ###############################################################################################
    
def analyze_observed_catalog_random_walk():

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()

    plot_params = False
    USGS = True
    generate_and_write_new_catalog  = False
    write_time_space_clustered_catalog = False
    plot_magnitude_time = False     #   Usually plots the ERAS unclustered catalog
    Location = 'Los Angeles'
    os.system("python USGS_to_ERAS.py")
    
    input_file_name = './Output_Files/ERAS_USGS.txt'
    
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)

    cycle_list, label_cycle_list = ERASCalcV5.mainshock_cycles(mags, year_events,label_events, mag_large_omori)
    
    temp_scale_factor = 1.e6  #   We just need the cycle_list for the adjusted catalog to get the aftershock_list
                             #       So set the aftershock multiplier = 1 by setting scale_factor -> infinity
    
    year_adjusted, aftershock_list = \
            ERASCalcV5.omori_recluster(cycle_list, label_cycle_list, year_events, mags, temp_scale_factor)
    
    step_lat_mean_optimal, step_lat_std, step_lng_mean_optimal, step_lng_std = \
            ERASCalcV5.random_walk_step_size(aftershock_list, label_events, x_events, y_events, date_events,\
            mag_large_omori, mags, USGS)
            
    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
        pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
        = ERASFileMethods.read_parameter_file()
        
    params = [mu, mag_large_omori, mag_large, max_swarm_mag,  bval, \
        BathNumber, step_lat_mean_optimal, step_lng_mean_optimal, scale_factor, pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, \
        bin_length_time, bin_length_space]
        
    ERASFileMethods.write_parameter_file(params)

    return step_lat_mean_optimal, step_lat_std, step_lng_mean_optimal, step_lng_std
    
    ############################################################################################### 
    
def generate_new_catalog():

    input_file_name = './Output_Files/ERAS_USGS.txt'
    
    date_events_USGS, time_events_USGS, year_events_USGS, x_events_USGS, y_events_USGS, mags_USGS, z_events_USGS, label_events_USGS = \
            read_existing_catalog(input_file_name)
            
    ntmax = len(mags_USGS) + 499

    mags, year_events, x_events, y_events, z_events, label_events, fraction_aftershocks = ERASCalcV5.generate_catalog(ntmax)
    
    nowcast_output_catalog          = []
    date_file                       = []
    year_file                       = []
    time_file                       = []
    
    #   ---------------------------------------------------
    
    # Get today's date
    today = datetime.today()

    # Calculate decimal years
    todays_decimal_year = ERASUtilities.decimal_year(today)
    
    print()
    print('Today, todays_decimal_year: ', today, todays_decimal_year)
    print()
# 
    for i in range(len(year_events)):
        decimal_year = region_catalog_date_start + \
            (todays_decimal_year - region_catalog_date_start)*year_events[i]/(max(year_events))
        year_file.append(round(decimal_year,12))
        date_of_event, time_of_day = ERASCalcV5.decimal_year_to_date(decimal_year)
        date_file.append(date_of_event)
        time_file.append(time_of_day)
        
    #   ---------------------------------------------------
    
    text_file_name = './Output_Files/ERAS_Unclustered.txt'
    csv_file_name  = './Output_Files/ERAS_Unclustered.csv'
    
    write_output_files(date_file, time_file, year_file, x_events, y_events, z_events, mags, label_events,\
            text_file_name, csv_file_name)
            
    #   ---------------------------------------------------
    #   Now filter the events and write a file that is solely an unclustered aftershock file
    
    mu = min(mags)
    min_mag_aftershocks = mu + BathNumber
    
    date_events_a               = []
    time_events_a               = []
    year_events_a               = []
    x_events_a                  = []
    y_events_a                  = []
    z_events_a                  = []
    mags_a                      = []
    label_events_a              = []
    
    for i in range(len(year_events)):
    
        if mags[i] >= min_mag_aftershocks or label_events[i] == 'a':
            
            date_events_a.append(date_file[i])
            time_events_a.append(time_file[i])
            year_events_a.append(year_file[i])      #   These are the clustered times
            x_events_a.append(x_events[i])
            y_events_a.append(y_events[i])
            z_events_a.append(z_events[i])
            mags_a.append(mags[i])
            label_events_a.append(label_events[i])
            
    text_file_name = './Output_Files/ERAS_Unclustered_Aftershocks.txt'
    csv_file_name  = './Output_Files/ERAS_Unclustered_Aftershocks.csv'
            
    write_output_files(date_events_a, time_events_a, year_events_a, \
            x_events_a, y_events_a, z_events_a, mags_a, label_events_a, \
            text_file_name, csv_file_name)
    
    return fraction_aftershocks
    
    ############################################################################################### 
    
def generate_time_clustered_catalog(write_files,variable_scale_factor):

    input_file_name = './Output_Files/ERAS_Unclustered.txt'
    
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)
            
    #   ---------------------------------------------------
    #   Define some parameters
            
    mu = min(mags)
    min_mag_aftershocks = mu + BathNumber
    
    aval = 0.

    delta_mag = max_swarm_mag - mu
    probm = ERASCalcV5.mag_freq(np.arange(0, delta_mag, 0.01), mu, bval, aval)\
            /np.sum(ERASCalcV5.mag_freq(np.arange(0, delta_mag, 0.01), mu, bval, aval))
            
    #   ---------------------------------------------------
    
    #   Recluster the labeled aftershock events
    
    date_adjusted, time_adjusted, year_adjusted, aftershock_list = \
            recluster_times(mu, mag_large, year_events, mags, label_events, variable_scale_factor, input_file_name)
            
    #   ---------------------------------------------------
    
    #   Write 2 sets of files.  One for the aftershocks and their mainshocks, and one for the small
    #       magnitude background seismicity
    
    date_events_a               = []
    time_events_a               = []
    year_events_a               = []
    x_events_a                  = []
    y_events_a                  = []
    z_events_a                  = []
    mags_a                      = []
    label_events_a              = []
    
    year_events_b               = []
    x_events_b                  = []
    y_events_b                  = []
    z_events_b                  = []
    mags_b                      = []
    label_events_b              = []
    
    #   ---------------------------------------------------
    
    #   These will be the unclustered background times
    random_year_background      = []
    
    for i in range(len(year_events)):
    
        swarm_mag = mu + np.random.choice(np.arange(0, delta_mag, 0.01), p = probm)

        if mags[i] < min_mag_aftershocks and label_events[i] == 'b':
            random_year_background.append(year_events[i])
            x_events_b.append(x_events[i])
            y_events_b.append(y_events[i])
            z_events_b.append(z_events[i])
            mags_b.append(swarm_mag)
            label_events_b.append(label_events[i])
            
        else:
            date_events_a.append(date_adjusted[i])
            time_events_a.append(time_adjusted[i])
            year_events_a.append(year_adjusted[i])      #   These are the clustered times
            x_events_a.append(x_events[i])
            y_events_a.append(y_events[i])
            z_events_a.append(z_events[i])
            mags_a.append(mags[i])
            label_events_a.append(label_events[i])
        
    #   ---------------------------------------------------
            
    for i in range(len(random_year_background)):
        random_year = np.random.choice(year_events, replace=True)  
        year_events_b.append(random_year)
        
    #   ---------------------------------------------------

    #   Append the year_events_b list to the year_adjusted list.  Then sort the combined list and 
    #       recover the sort indices of that combined list.
    
    year_events_all     = year_events_a.copy()
    x_events_all        = x_events_a.copy()
    y_events_all        = y_events_a.copy()
    z_events_all        = z_events_a.copy()
    mags_all            = mags_a.copy()
    label_events_all    = label_events_a.copy()
    
    #   Then recombine the aftershock and background lists by appending background to aftershock
    
    for i in range(len(year_events_b)):
        year_events_all.append(year_events_b[i])
        x_events_all.append(x_events_b[i])
        y_events_all.append(y_events_b[i])
        z_events_all.append(z_events_b[i])
        mags_all.append(mags_b[i])
        label_events_all.append(label_events_b[i])
        
    #   ---------------------------------------------------
        
    #   Then sort the combined catalog in ascending order ( descending order would be written (-x).argsort()  )
    
    year_index_array = np.array(year_events_all)
    indices_combined = year_index_array.argsort()
    
    #   Now rewrite the combined catalog of data lists in ascending order
    
    date_events_combined     = []
    time_events_combined     = []
    
    year_events_combined     = []
    x_events_combined        = []
    y_events_combined        = []
    z_events_combined        = []
    mags_combined            = []
    label_events_combined    = []
    
    for i in range(len(year_events_all)):
        
        year_events_combined.append(year_events_all[indices_combined[i]])
        x_events_combined.append(x_events_all[indices_combined[i]])
        y_events_combined.append(y_events_all[indices_combined[i]])
        z_events_combined.append(z_events_all[indices_combined[i]])
        mags_combined.append(mags_all[indices_combined[i]])
        label_events_combined.append(label_events_all[indices_combined[i]])
        
    #   Now, from the year_events_combined file, define the dates and times

    for i in range(len(year_events_combined)):
        decimal_year = year_events_combined[i]
        date_combined, time_combined = ERASCalcV5.decimal_year_to_date(decimal_year)
        date_events_combined.append(date_combined)
        time_events_combined.append(time_combined)
        
    
    mag_large_events    =   []
    year_large_events   =   []
    date_large_events   =   []
    time_large_events   =   []
    lat_large_events    =   []
    lng_large_events    =   []
    index_large_events  =   []        

    for i in range(len(year_events_all)):
        
        if mags_combined[i] >= mag_large:
            mag_large_events.append(mags_combined[i])
            year_large_events.append(year_events_combined[i])
            date_large_events.append(date_events_combined[i])
            time_large_events.append(time_events_combined[i])
            lat_large_events.append(y_events_combined[i])
            lng_large_events.append(x_events_combined[i])
            index_large_events.append(i)
        
    for i in range(len(year_large_events)):
        print('For Large Events: ', \
                    ' Date: ', date_large_events[i],'\t'\
                    ' Time: ', time_large_events[i], '\t'\
                    ' Magnitude: ', round(mag_large_events[i], 4))
    print()
                    
    #   ---------------------------------------------------


    #   Names of the clustered data files come next
    
    if write_files:
        txt_file_name   = './Output_Files/ERAS_Time_Clustered.txt'
        csv_file_name   = './Output_Files/ERAS_Time_Clustered.csv'
        
    #   Write the clustered output files
    
        write_output_files(date_events_combined, time_events_combined, year_events_combined, \
                x_events_combined, y_events_combined, z_events_combined, mags_combined, label_events_combined, \
                txt_file_name, csv_file_name)
                
            
    #   ---------------------------------------------------
            
    #   Write the aftershock file
    
    if write_files:
        txt_file_name   = './Output_Files/ERAS_Time_Clustered_Aftershocks.txt'
        csv_file_name   = './Output_Files/ERAS_Time_Clustered_Aftershocks.csv'

        date_events_adjusted_a  =   []
        time_events_adjusted_a  =   []

        for i in range(len(year_events_a)):
            decimal_year = year_events_a[i]
            date_events_adjusted, time_events_adjusted = ERASCalcV5.decimal_year_to_date(decimal_year)
            date_events_adjusted_a.append(date_events_adjusted)
            time_events_adjusted_a.append(time_events_adjusted)

        write_output_files(date_events_adjusted_a, time_events_adjusted_a, year_events_a, \
             x_events_a, y_events_a, z_events_a, mags_a, label_events_a, \
             txt_file_name, csv_file_name)
            
        print()
        fraction_aftershocks = 100.0*float(len(year_events_a))/float(len(year_events_combined))
        fraction_aftershocks = round(fraction_aftershocks, 2)
        print('Fraction Aftershocks in Model: ', str(fraction_aftershocks) + '%' )
        print()
        
    return aftershock_list, year_adjusted
    
    ############################################################################################### 

def  generate_space_clustered_catalog(write_files, space_multiplier, step_lat, step_lng):

    USGS = False

    input_file_name = './Output_Files/ERAS_Time_Clustered.txt'
    
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)
        
    qfit, qerror, x_events_adjusted, y_events_adjusted, radius_mean, radius_std = \
        ERASCalcV5.compute_rescaled_aftershock_locations(space_multiplier, USGS)
        
    if write_files:
        txt_file_name   = './Output_Files/ERAS_Time_Space_Clustered.txt'
        csv_file_name   = './Output_Files/ERAS_Time_Space_Clustered.csv'
        
    #   Write the clustered output files
    
        write_output_files(date_events,  time_events,  year_events, \
                x_events_adjusted, y_events_adjusted,  z_events,  mags, label_events, \
                txt_file_name, csv_file_name)
    return
    
    ###################################################################################################################
    ###################################################################################################################
    #                                                                                                             PLOTS
def omori_time_plot():

    input_file_name = './Output_Files/ERAS_Time_Clustered.txt'
    input_file_name = './Output_Files/ERAS_Time_Clustered_Aftershocks.txt'
#    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'


    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events =\
        read_existing_catalog(input_file_name)
            
    number_aftershocks = 0
    
    for i in range(len(label_events)):
        if label_events[i] == 'a':
            number_aftershocks += 1

    print()
    
    year_events = [float(year_events[i]) for i in range(len(year_events))]
    mags        = [float(mags[i]) for i in range(len(mags))]
    
#   ----------------------------------------------------------------
    
    print()
    print('Magnitude for Re-clustering: ', mag_large_omori)
    print()
    
    number_mainshocks = 0
    for i in range(len(mags)):
        if mags[i] >= mag_large_omori:
            number_mainshocks += 1
            
    print('Number of Mainshocks for p,q Calculations: ', number_mainshocks)
    
#   ----------------------------------------------------------------

    temp_scale_factor = 1.e6
        
    cycle_list, label_cycle_list = ERASCalcV5.mainshock_cycles(mags, year_events,label_events, mag_large_omori)
     
    year_adjusted, aftershock_list = \
            ERASCalcV5.omori_recluster(cycle_list, label_cycle_list, year_events, mags, temp_scale_factor)

    ERASPlotV3.plot_omori_aftershock_decay_time(aftershock_list, label_cycle_list, year_adjusted, bin_length_time, \
            number_mainshocks, mag_large_omori, mags, scale_factor, params, Location, USGS)
#     
#             
    return
    
    ###############################################################################################
    
def omori_space_plot():

    input_file_name = './Output_Files/ERAS_Time_Clustered.txt'

    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'

    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events =\
        read_existing_catalog(input_file_name)
        
    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()
        
    number_aftershocks = 0
    
    for i in range(len(label_events)):
        if label_events[i] == 'a':
            number_aftershocks += 1

    print()
    fraction_aftershocks = round( 100.0*float(number_aftershocks)/float(len(label_events)), 2)
    print('Fraction Aftershocks: ', str(fraction_aftershocks) + '%' )
    print()
    
    mags = [float(mags[i]) for i in range(len(mags))]
    
#   ----------------------------------------------------------------
    
    print()
    print('Magnitude for Re-clustering: ', mag_large_omori)
    print()
    
    number_mainshocks = 0
    for i in range(len(mags)):
        if mags[i] >= mag_large_omori:
            number_mainshocks += 1
            
    print('Number of Mainshocks for p,q Calculations: ', number_mainshocks)
    
#   ----------------------------------------------------------------

    temp_scale_factor = 1.e6  #   We just need the cycle_list for the adjusted catalog to get the aftershock_list
                             #       So set the aftershock multiplier = 1 by setting scale_factor -> infinity
    
        
    ERASPlotV3.plot_omori_aftershock_decay_space(label_events, x_events, y_events, \
            step_lat, step_lng, space_multiplier, bin_length_space, number_mainshocks, Location, USGS)
           
    return
    
    ###############################################################################################
    
def seismicity_plots():

    input_file_name   = './Output_Files/ERAS_Time_Clustered.txt'
    if USGS:
        input_file_name   = './Output_Files/ERAS_USGS.txt'    #   Fake LA positions

    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = read_existing_catalog(input_file_name)
    
    x_events = [float(x_events[i]) for i in range(len(x_events))]
    y_events = [float(y_events[i]) for i in range(len(y_events))]
    mags        = [float(mags[i]) for i in range(len(mags))]
    
    mu = min(mags)
    
    print()
    print('Number of events on the map', len(year_events))
    print()
   
    ERASPlotV3.map_seismicity(NELat_local, NELng_local, SWLat_local, SWLng_local, plot_start_year, \
        Location, catalog, mag_large, min_map_mag, mu, forecast_intervals, \
        date_events, time_events, year_events, x_events, y_events, mags, z_events, params, USGS) 

    return
    
    ###############################################################################################   
    
def simple_data_plot(time_list_reduced, log_number_reduced):

    input_file_name =  './Output_Files/ERAS_Time_Space_Clustered.txt'

    date_events, time_events, year_events, x_events, y_events, mags, depth_events, label_events = \
            read_existing_catalog(input_file_name)
            
    plot_data_start_year = 1970.
    
    max_value = max(log_number_reduced)
    
    index_1970 = 0
    while time_list_reduced[index_1970] < plot_data_start_year:
        index_1970 += 1
    
    log_number_reduced_reversed = [max_value - log_number_reduced[i] for i in range(len(log_number_reduced))]
    
    fig, ax = plt.subplots()
         
    ax.plot(time_list_reduced[index_1970:], log_number_reduced_reversed[index_1970:], '-', lw=0.75, \
            color='blue', zorder=4, label='EMA Timeseries')
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    min_plot_line = [ymin for i in range(len(time_list_reduced[index_1970:]))]
    
    ax.fill_between(time_list_reduced[index_1970:] , min_plot_line, log_number_reduced_reversed[index_1970:], \
            color='c', alpha=0.1, zorder=0)
            
    for i in range(len(year_events)):

        if float(mags[i]) >= 6.0 and float(mags[i]) < 7.0  and float(year_events[i]) >= plot_data_start_year:
            x_eq = [year_events[i], year_events[i]]
            y_eq = [ymin,ymax]
            
            ax.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.75, zorder=2)
            
    ax.plot([],[], linestyle='dotted', color='k', lw=0.7, zorder=2, label = r'7.0 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_events)):

        if float(mags[i]) >= 7.0 and float(year_events[i]) >= plot_data_start_year:
            x_eq = [year_events[i], year_events[i]]
            y_eq = [ymin,ymax]
            
            ax.plot(x_eq, y_eq, linestyle='--', color='r', lw=0.75, zorder=2)
            
    ax.plot([],[], linestyle='--', color='r', lw=0.7, zorder=2, label=r'M $\geq$ 7.0')
    
    max_plot_line = [ymax for i in range(len(time_list_reduced[index_1970:]))]
    
    ax.fill_between(time_list_reduced[index_1970:] , log_number_reduced_reversed[index_1970:], max_plot_line, \
            color='white', alpha=1.0, zorder=3)
            
    title_text = 'Data Set'
    leg = ax.legend(loc = 'upper right', title=title_text, fontsize=8)
    leg.set_title(title_text,prop={'size':10})   #   Set the title text font size
    
    SupTitle_text = r'ERAS Earthquake Potential State $\Theta(t)$ vs. Time: ' 

    plt.suptitle(SupTitle_text, fontsize=12)
    
    Title_text = 'Within ' + str(round(delta_deg_lat,2)) + r'$^o$ Latitude and ' + \
            str(round(delta_deg_lng,2)) + r'$^o$ Longitude of Los Angeles'
            
    plt.title(Title_text, fontsize=9)
    
    plt.ylabel(r'Large Earthquake Potential State $\Theta(t)$', fontsize = 11)
    plt.xlabel('Time (Year)', fontsize = 11)
    
    data_string_title = 'EMA' + '_NSTP' + str(NSteps) + '_MM' + str(min_mag) + '_CF' + str(lambda_min_mult) 

    figure_name = './Figures/ERAS_' + data_string_title + '_' + str(plot_data_start_year) + '.png'
    plt.savefig(figure_name,dpi=300)
    
    plt.show()
    
    plt.close('all')

    return
    
    ###################################################################################################################
    ###################################################################################################################
    #                                                                                                     IF STATEMENTS
    
if download_USGS_catalog:

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
        pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
        = ERASFileMethods.read_parameter_file()
        
    month_interval          = 0.07692   #   We use a time interval of "months" where 1 month = 4 weeks = "lunar month", 52 weeks/year
    
    plot_start_year = plot_start_year- 2.*month_interval    #   To align the month times correctly
    
    NELat, NELng, SWLat, SWLng, completeness_mag, start_date, \
            NELat_local, NELng_local, SWLat_local, SWLng_local, min_mag, max_depth = define_USGS_parameters(catalog)

    print('')
    print('Downloading the base catalog...')
    print('')
    ERASFileMethods.get_base_catalog(NELat, NELng, SWLat, SWLng, completeness_mag, start_date)

    #   Build the regional catalog from the World Wide catalog
    
    ERASFileMethods.get_regional_catalog(NELat_local, NELng_local, SWLat_local, SWLng_local, min_mag, max_depth,\
            region_catalog_date_start, region_catalog_date_end)
            
    os.system("rm USGS_Base.catalog")
    
    os.system("python USGS_to_ERAS.py")
    
    input_file_name = './Output_Files/ERAS_USGS.txt'
            
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
        read_existing_catalog(input_file_name)
    
    mu = min(mags)
    
    bval_data, bval_data_error, cept_data, cept_data_error = ERASCalcV5.calc_GR(mags, mu, BathNumber, mag_large)
    
    print()
    print('b-value for the region: ', round(bval_data,3), ' +/- ', round(bval_data_error, 3))
    print()
        
    params = [mu, mag_large_omori, mag_large, max_swarm_mag,  round(bval_data,3), \
            BathNumber, step_lat, step_lng, scale_factor, pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, \
            bin_length_time, bin_length_space]
            
    ERASFileMethods.write_parameter_file(params)
    
    ################################################################# 
    
if generate_and_write_new_optimal_catalog:

    #   First find the b-value of the real catalog
    
    input_file_name = './Output_Files/ERAS_USGS.txt'
    
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
        read_existing_catalog(input_file_name)
        
    fraction_aftershocks_USGS = 0.
    for i in range(len(label_events)):
        if label_events[i] == 'a':
            fraction_aftershocks_USGS += 1.
            
    fraction_aftershocks_USGS = 100.*fraction_aftershocks_USGS/float(len(label_events))
        
    bval_data, bval_data_error, cept_data, cept_data_error = ERASCalcV5.calc_GR(mags, mu, BathNumber, mag_large)
    
    bval_model          = 100.   #   Dummy value
    bval_model_error    = 0.
    
    fraction_aftershocks = 100.0
    
    input_file_name = './Output_Files/ERAS_Unclustered.txt'
    
    bval_bias = 0.00    #    Maybe set this equal to 0.05 if you enforce Baths Law in ERASCalcV5
    
    while abs(bval_model - bval_data) > 0.015:
#     
        fraction_aftershocks = generate_new_catalog()      #   Do this recursively
        
        print()
        print('Aftershock Fraction (ERAS): ', round(fraction_aftershocks,2))
        print('Aftershock Fraction (USGS): ', round(fraction_aftershocks_USGS,2))
        print()
        
        date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
                read_existing_catalog(input_file_name)
                
        bval_model, bval_model_error, cept_data, cept_data_error = ERASCalcV5.calc_GR(mags, mu, BathNumber, mag_large)
        
        print(' -----------------------------------------------------')
        print()
        print('b-Value for this Simulation: ', round(bval_model,3), ' +/- ', round(bval_model_error,3))
        print()
        print('b-Value for the Data: ', round(bval_data,3), ' +/- ', round(bval_data_error,3))
        print()
        print('abs(bval_model - bval_data)', round(abs(bval_model - bval_data),3), '; 1.5*bval_data_error', round(1.5*bval_data_error,3))
        print()
        print(' -----------------------------------------------------')
                
    #   Now do a grid search to find the optimal rescaling factor
    
    scale_factor_optimal, pvalue_pred, pvalue_err, pvalue_obs, perror_obs = optimize_time_scale_factor()
    
    space_multiplier_optimal, qvalue_optimal = optimize_space_scale()
    
    params = [mu, mag_large_omori, mag_large, max_swarm_mag,  bval, \
            BathNumber, step_lat, step_lng, scale_factor_optimal, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier_optimal, \
            bin_length_time, bin_length_space]
        
    ERASFileMethods.write_parameter_file(params)
#     
    #################################################################
    
if write_time_space_clustered_catalog_from_unclustered:

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()
            
    #   These functions generate catalogs with parameters from parameters.txt file
            
    write_files = True

    generate_time_clustered_catalog(write_files,scale_factor)
    
    #################################################################
    
if write_time_space_clustered_catalog_new_unclustered:

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()
            
    #   These functions generate catalogs with parameters from parameters.txt file
            
    generate_new_catalog()      # If you want to start over

    write_files = True

    generate_time_clustered_catalog(write_files,scale_factor)
    
    generate_space_clustered_catalog(write_files, space_multiplier, step_lat, step_lng)   #   If you want to spatially cluster

    #################################################################
    
    
if calculate_optimal_time_scale_factor:

    optimized_time_scale, pvalue_pred, pvalue_err, pvalue_obs, perror_obs = optimize_time_scale_factor()
#     
    #################################################################
    
if calculate_random_walk_step_size:

    step_lat_mean, step_lat_std, step_lng_mean, step_lng_std = analyze_observed_catalog_random_walk()
#         
    #################################################################

if calculate_optimal_space_scale_factor:

    optimize_space_scale()
    
    #################################################################
    
if plot_magnitude_time:

    input_file_name = './Output_Files/ERAS_Unclustered.txt'
    if plot_USGS_data:
        plot_params = False
        input_file_name = './Output_Files/ERAS_USGS.txt'
        
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)

    ERASPlotV3.plot_mag_timeseries_raw(year_events, mags, params, Location, USGS)
    
    #################################################################
    
if plot_magnitude_time_clustered:

    input_file_name = './Output_Files/ERAS_Time_Clustered.txt'
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'
        
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)
            
    ERASPlotV3.plot_mag_timeseries_clustered(year_events, mags, params, Location, USGS)
    
    #################################################################
    
if plot_number_events_vs_time:

    input_file_name = './Output_Files/ERAS_Time_Clustered.txt'
#     input_file_name = './Output_Files/ERAS_Time_Clustered_Aftershocks.txt'
    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'


    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)
            
    ERASPlotV3.plot_number_timeseries(year_events, mags, params, Location, USGS)

    #################################################################
    
if plot_number_vs_time_and_GRR_one_mainshock_days:

    input_file_name = './Output_Files/ERAS_Time_Space_Clustered.txt'
    input_file_name = './Output_Files/ERAS_Time_Clustered_Aftershocks.txt'
    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'


    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)
            
    for i in range(len(mags)):
        if mags[i] >= 5.5:
            if i < 1000:
                separator = '\t\t'
            else:
                separator = '\t'
            print('index, date_event, label, magnitude:      ', i, separator, date_events[i], '\t', \
                label_events[i], '\t', '%.2f'%(mags[i]))
                
    print()
    print('Enter Data on Which Event to Plot')
    print()
    begin_index = input('Enter index from above list for event to plot:  ')
    begin_index = int(begin_index)
    print()
    number_days = input('Enter number of days post - event for aftershock plot:  ')
    number_days = int(number_days)
                
    print()
    print('Magnitude of Mainshock', mags[begin_index])
    print()
    
    print()
    print('date_events[begin_index]: ', date_events[begin_index])
    print()
            
    ERASPlotV3.plot_number_timeseries_one_mainshock_days(date_events, year_events, time_events, mags, params, \
            Location, begin_index, number_days, USGS)
            
    ERASPlotV3.plot_mag_timeseries_clustered_one_mainshock_days(date_events, time_events, year_events, mags, params, \
            Location, begin_index, number_days, USGS)

    #################################################################
    
if plot_number_vs_time_and_GRR_one_mainshock_hours:

    input_file_name = './Output_Files/ERAS_Time_Space_Clustered.txt'
    input_file_name = './Output_Files/ERAS_Time_Clustered_Aftershocks.txt'
    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'


    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)
            
    for i in range(len(mags)):
        if mags[i] >= 5.5:
            if i < 1000:
                separator = '\t\t'
            else:
                separator = '\t'
            print('index, date_event, label, magnitude:      ', i, separator, date_events[i], '\t', \
                label_events[i], '\t', '%.2f'%(mags[i]))
                
    print()
    print('Enter Data on Which Event to Plot')
    print()
    begin_index = input('Enter index from above list for event to plot:  ')
    begin_index = int(begin_index)
    print()
    number_hours = input('Enter number of hours post - event for aftershock plot:  ')
    number_hours = int(number_hours)
                
    print()
    print('Magnitude of Mainshock', mags[begin_index])
    print()
            
    ERASPlotV3.plot_number_timeseries_one_mainshock_hours(date_events, year_events, time_events, mags, params, \
            Location, begin_index, number_hours, USGS)
            
    ERASPlotV3.plot_mag_timeseries_clustered_one_mainshock_hours(date_events, time_events, year_events, mags, params, \
            Location, begin_index, number_hours, USGS)

    #################################################################
    
if plot_magnitude_frequency:

    input_file_name = './Output_Files/ERAS_Time_Space_Clustered.txt'
    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'

    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)

    ERASPlotV3.plot_GR(mags, params, Location, USGS)
    
       #################################################################
       
if plot_omori_clustered_events:

    omori_time_plot()
    
    omori_space_plot()

    #################################################################

if plot_LA_seismicity_map:

    seismicity_plots()
        
    #################################################################
    
if plot_EMA_timeseries:

    input_file_name = './Output_Files/ERAS_Time_Space_Clustered.txt'
    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'

    delta_time = 0.07692    #   1 month

    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)

    timeseries, time_bins, date_bins = ERASCalcMethodsSEISR.coarse_grain_seismic_timeseries(\
            NELat_local, NELng_local, SWLat_local, SWLng_local, \
            min_mag, max_depth, grid_size, delta_time,\
            date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events)
            
    timeseries_EMA, times_window, values_window, eqs_list, time_list_reduced, log_number_reduced, \
            eqs_list_reduced, NN, min_rate, max_rate = \
            ERASCalcMethodsSEISR.build_EMA_timeseries(catalog, timeseries, time_bins, forecast_intervals, NSteps,\
            plot_start_year, mag_large, min_mag, delta_time, lambda_min_mult, lambda_max_mult, USGS)

    simple_data_plot(time_list_reduced, log_number_reduced)
    
    #################################################################

