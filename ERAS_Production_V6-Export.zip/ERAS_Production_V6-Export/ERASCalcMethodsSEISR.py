#!/opt/local/bin python

    #   SEISRCalcMethods.py   Contains plot routines for the EMA code
    #
    #
    #   This code was written on a Mac using Macports python, but Anaconda python should work as well.
    
    #   ---------------------------------------------------------------------------------------
    
    # Copyright 2022 by John B Rundle, University of California, Davis, CA USA
    # 
    # Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
    # documentation files (the     "Software"), to deal in the Software without restriction, including without 
    # limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
    # and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
    # 
    # The above copyright notice and this permission notice shall be included in all copies or suSKLantial portions of the Software.
    # 
    # THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
    # WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
    # COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
    # ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

    #   ---------------------------------------------------------------------------------------
    
import sys
import os
import numpy as np
from array import array

import datetime
import dateutil.parser

import time
from time import sleep  #   Added a pause of 30 seconds between downloads

import math

from tabulate import tabulate

#  Now we import the sklearn methods
import pandas as pd
import numpy as np
import scipy

from numpy import asarray
from pandas import read_csv
from pandas import DataFrame
from pandas import concat
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import matplotlib.patches as mpatches

from scipy.integrate import simpson
from numpy import trapz

from shapely.geometry import Point
from shapely.geometry.polygon import Polygon

import itertools

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn import preprocessing
from sklearn.metrics import mean_absolute_error
from sklearn.ensemble import RandomForestRegressor

import random
    
from PIL import Image

import ERASFileMethods

    ######################################################################
    
def read_input_data(input_file_name, min_mag):

    input_file = open(input_file_name,'r')
    
        
    values_window       =   []
    stddev_window       =   []
    times_window        =   []
    eqs_window          =   []
        
    number_lines = 0
    for line in input_file:
        items = line.strip().split(',')
        number_lines += 1
        
        if number_lines > 2 and '.' in items[0]:
            items = line.strip().split(',')
            values_window.append(float(items[3]))
            stddev_window.append(float(items[4]))
            times_window.append(float(items[1]))
            eqs_window.append(float(items[5]))
        
        if number_lines > 2 and 'Data:' in items[0]:
            items = line.strip().split(',')
            NELng_local = float(items[1])
            SWLng_local = float(items[2])
            NELat_local = float(items[3])
            SWLat_local = float(items[4])
            Grid        = float(items[5])
            Location = items[6]
            
    input_file.close()

    return values_window, stddev_window, times_window, eqs_window, NELng_local, SWLng_local, \
            NELat_local, SWLat_local, Grid, Location
            
    ######################################################################
    
def read_input_earthquake_data(delta_time, min_mag, lambda_min_mult):

    #   Get catalog location and grid box data.  Then get list of small earthquakes.
    #
    #   Next, discretize the earthquake list into time intervals of length delta_time.  
    #
    #   This discretized earthquake list is then the number of small earthquakes in time intervals
    #       of length delta_time.  
    #
    #   This method returns the list of discrete times (time_list) and the number of small earthquakes in each
    #       discrete time interval (eqs_list)
    
    mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = SEISRFileMethods.read_regional_catalog(min_mag)
    
    last_index  = int(len(year_array))-1
    first_index = 0
    
    year_diff = float(year_array[last_index]) - float(year_array[0])
    
    number_time_deltas = int (year_diff/delta_time)
    
    time_list   =   []
    eqs_list    =   []  
    
    jlast = number_time_deltas - 1
    last_time = jlast * delta_time
    number_eqs = 0
    initial_year = float(year_array[0])
    
    for i in range(len(time_array)):

        index = len(time_array) - i - 1
        
        j = int ( (float(year_array[index])- float(year_array[0]))  /delta_time)     #   j will be a monotone decreasing index
        
        if j == jlast:
            number_eqs += 1
        else:
            time_list.append((jlast-1) * delta_time + initial_year)
            
            if number_eqs == 0 and lambda_min_mult > 0.0001:
#             if number_eqs == 0:
                number_eqs = 1
            eqs_list.append(number_eqs)
            number_eqs = 0
            jlast = j
        
    time_list.reverse()
    eqs_list.reverse()
    
    time_list = time_list[:-1]  #   Removing the extra last index that is introduced by the above code
    eqs_list  = eqs_list[:-1]

    return time_list,eqs_list
            
    ######################################################################
    
def read_input_local_earthquake_data(delta_time, min_mag, lambda_mult, reference_lat, reference_lng, local_radius):

    #   Get catalog location and grid box data.  Then get list of small earthquakes.
    #
    #   Next, discretize the earthquake list into time intervals of length delta_time.  
    #
    #   This discretized earthquake list is then the number of small earthquakes in time intervals
    #       of length delta_time.  
    #
    #   This method returns the list of discrete times (time_list) and the number of small earthquakes in each
    #       discrete time interval (eqs_list)
    
    mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = SEISRFileMethods.read_regional_catalog(min_mag)
    
    last_index  = int(len(year_array))-1
    first_index = 0
    
    year_diff = float(year_array[last_index]) - float(year_array[0])
    
    number_time_deltas = int (year_diff/delta_time)
    
    time_list_local   =   []
    eqs_list_local    =   []  
    
    jlast = number_time_deltas - 1
    last_time = jlast * delta_time
    number_eqs = 0
    initial_year = float(year_array[0])
    
    for i in range(len(time_array)):
    
    #   Compute the timeseries here and then timeseries[index_timeseries] = the timeseries you computed
    
        point = Point((float(lat_array[i]),float(lng_array[i])))
        
        lat_1 = reference_lat
        lat_2 = lat_array[i]
        
        lng_1 = reference_lng
        lng_2 = lng_array[i]
        
        dist_point = SEISRUtilities.compute_great_circle_distance(lat_1, lng_1, lat_2, lng_2)
        
        index = len(time_array) - i - 1
        
        j = int ( (float(year_array[index])- float(year_array[0]))  /delta_time)     #   j will be a monotone decreasing index
        
        #   If same index as last time and point is in the local circle
        if j == jlast:
        
            if dist_point <= local_radius:
                number_eqs += 1
        else:
            time_list_local.append((jlast-1) * delta_time + initial_year)
            
            if number_eqs == 0 and lambda_mult > 0.0001:
                number_eqs = 1
                
            eqs_list_local.append(number_eqs)
            number_eqs = 0
            jlast = j
        
    time_list_local.reverse()
    eqs_list_local.reverse()
    
    time_list_local = time_list_local[:-1]  #   Removing the extra last index that is introduced by the above code
    eqs_list_local  = eqs_list_local[:-1]

    return time_list_local, eqs_list_local
            
    ######################################################################
    
def get_large_earthquakes(mag_large, min_mag, USGS):

    input_file_name = './Output_Files/ERAS_Time_Space_Clustered.txt'
    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'

    date_array, time_array, year_array, lng_array, lat_array, mag_array, depth_array = \
            ERASFileMethods.read_existing_catalog(input_file_name)
            
    #   Find dates of large earthquakes
    
    mag_large_eq    =   []
    year_large_eq   =   []
    index_large_eq  =   []
    lat_large_eq    =   []
    lng_large_eq    =   []
        
    for i in range(len(year_array)):
        if float(mag_array[i]) >= mag_large:
            mag_large_eq.append(float(mag_array[i]))
            year_large_eq.append(float(year_array[i]))
            index_large_eq.append(i)
            lat_large_eq.append(float(lat_array[i]))
            lng_large_eq.append(float(lng_array[i]))

    return year_large_eq, mag_large_eq, index_large_eq, lat_large_eq, lng_large_eq
    
    ######################################################################
    
def get_large_earthquake_source(mag_large, min_mag, USGS):

    input_file_name = './Output_Files/ERAS_Time_Space_Clustered.txt'
    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt'

    delta_time = 0.07692    #   1 month

    date_array, time_array, year_array, lng_array, lat_array, mag_array, depth_array, label_array = \
            read_existing_catalog(input_file_name)

    #   Find dates of large earthquakes
    
    mag_large_eq    =   []
    year_large_eq   =   []
    index_large_eq  =   []
    lat_large_eq    =   []
    lng_large_eq    =   []
        
    for i in range(len(year_array)):
        if float(mag_array[i]) >= mag_large:
            mag_large_eq.append(float(mag_array[i]))
            year_large_eq.append(float(year_array[i]))
            index_large_eq.append(i)
            lat_large_eq.append(float(lat_array[i]))
            lng_large_eq.append(float(lng_array[i]))

    return year_large_eq, mag_large_eq, index_large_eq, lat_large_eq, lng_large_eq
    
    ######################################################################
    
def adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, lat_large_eq, lng_large_eq, time_list, plot_start_year):

    mag_large_eq_adj = mag_large_eq
    
    year_large_eq_adj   = []
    index_large_eq_adj  = []
    mag_large_eq_adj    = []
    lat_large_eq_adj    = []
    lng_large_eq_adj    = []
    
    for i in range(len(year_large_eq)):
    
        for j in range(len(time_list)-1):
        
            if year_large_eq[i] >= time_list[j] and year_large_eq[i] < time_list[j+1] and time_list[j] >= plot_start_year:
        
                year_large_eq_adj.append(time_list[j])
                index_large_eq_adj.append(j)
                mag_large_eq_adj.append(mag_large_eq[i])
                lat_large_eq_adj.append(lat_large_eq[i])
                lng_large_eq_adj.append(lng_large_eq[i])
                
    return year_large_eq_adj, mag_large_eq_adj, index_large_eq_adj, lat_large_eq_adj, lng_large_eq_adj
    
    ######################################################################
    
    
def calc_eqs_unfiltered(time_list, eqs_list, plot_start_year):
        
#
#   ------------------------------------------------------------
#
    if plot_start_year <= time_list[0]:
        plot_start_year = time_list[0]
        
    number_points_to_plot = 0
    
    for k in range(len(time_list)):
        if time_list[k] >= plot_start_year:
            number_points_to_plot += 1
            
    
    time_list_unfiltered_reduced           = time_list[- number_points_to_plot:]
    eqs_list_unfiltered_reduced            = eqs_list[- number_points_to_plot:]
    
    return time_list_unfiltered_reduced, eqs_list_unfiltered_reduced
    
    ######################################################################

    
def calc_seisr_timeseries(time_list, eqs_list, plot_start_year, mag_large,min_mag, delta_time, USGS):
        
        
#   This function creates a list of events after plot_start_year
#
#   ------------------------------------------------------------
#

    year_large_eq, mag_large_eq, index_large_eq, lat_large_eq, lng_large_eq = get_large_earthquakes(mag_large,min_mag, USGS)
    
    if plot_start_year <= time_list[0]:
        plot_start_year = time_list[0]
        
    number_points_to_plot = 0
    
    for k in range(len(time_list)):
        if time_list[k] >= plot_start_year:
            number_points_to_plot += 1
            
    for i in range(len(time_list)):
        time_list[i] += 2.*delta_time        #    Adjust times to properly align the EMA times with the large EQ times
        
    last_index = len(time_list)-1
    time_list[last_index] += 2.*delta_time   #   adjustment to ensure correct last event time sequence
    
    log_number = [math.log(1.0+eqs_list[i],10) for i in range(len(eqs_list))]
    
    
    log_number_reduced          = log_number[- number_points_to_plot:]
    time_list_reduced           = time_list[- number_points_to_plot:]
    eqs_list_reduced            = eqs_list[- number_points_to_plot:]
   
#
#   ------------------------------------------------------------
#
    return time_list_reduced, log_number_reduced, eqs_list_reduced
    
    ######################################################################

def random_statistics(true_positive, false_positive, true_negative, false_negative, \
                    threshold_value, forecast_interval, exclude_ROC_time, mag_large, \
                    data_string_title, number_thresholds, NELng_local, SWLng_local, NELat_local, SWLat_local, \
                    Grid, Location):
                    
# 
#   ------------------------------------------------------------
#
#   Plot ROC and random ROCs

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                compute_ROC_rates(true_positive, false_positive, true_negative, false_negative)   
                
    accuracy    =   []
    precision   =   []
    hit_rate    =   []
    
    for k in range(len(true_positive)):
        numer = true_positive[k] + true_negative[k]
        denom = true_positive[k] + false_positive[k] + true_negative [k] + false_negative[k]
        
        accuracy.append(numer/denom)
        hit_rate.append(true_positive[k]/(true_positive[k] + false_negative[k]))
        precision.append(true_positive[k]/(true_positive[k] + false_positive[k]))
        

    number_random_timeseries = 500

    random_true_positive_list       = []
    random_false_positive_list      = []
    random_false_negative_list      = []
    random_true_negative_list       = []
    
    random_accuracy_list    = []
    random_hit_rate_list    = []
    random_precision_list   = []
    random_specificity_list = []

    for i in range(number_random_timeseries):
    
        random_values = random_timeseries(values_window, times_window)
        
        true_positive_random, false_positive_random, true_negative_random, false_negative_random, threshold_value_random = \
                    compute_ROC(times_window, random_values, forecast_interval, exclude_ROC_time, mag_large, \
                    min_mag, number_thresholds, number_random_timeseries, i+1)
                    
        denom = []
        for k in range(len(true_positive_random)):
            denom.append(true_positive_random[k] + false_positive_random[k] + true_negative_random[k] + false_negative_random[k])
            
        true_positive_random    = [ true_positive_random[m]/denom[m] for m in range(len(true_positive_random))]
        false_positive_random   = [false_positive_random[m]/denom[m] for m in range(len(false_positive_random))]
        false_negative_random   = [false_negative_random[m]/denom[m] for m in range(len(false_negative_random))]
        true_negative_random    = [ true_negative_random[m]/denom[m] for m in range(len(true_negative_random))]

        random_true_positive_list.append(true_positive_random)
        random_false_positive_list.append(false_positive_random)
        random_false_negative_list.append(false_negative_random)
        random_true_negative_list.append(true_negative_random)
        
        accuracy_random     =   []
        hit_rate_random     =   []
        precision_random    =   []
        specificity_random  =   []
        
        for k in range(len(true_positive_random)):  #======>  thi sshould be number of timeseries, not number of thresholds
            numer = true_positive_random[k] + true_negative_random[k]
            denom = true_positive_random[k] + false_positive_random[k] + true_negative_random[k] + false_negative_random[k]
            
            try:
                accuracy_random.append(numer/denom)
            except:
                pass
            
            try:
                hit_rate_random.append(true_positive_random[k]/(true_positive_random[k] + false_negative_random[k]))
            except:
                pass
            
            try:
                precision_random.append(true_positive_random[k]/(true_positive_random[k] + false_positive_random[k]))
            except:
                pass
                
            try:
                specificity_random.append(true_negative_random[k]/(true_negative_random[k] + false_positive_random[k]))
            except:
                pass
            
        random_accuracy_list.append(accuracy_random)
            
        random_hit_rate_list.append(hit_rate_random)
            
        random_precision_list.append(precision_random)
        
        random_specificity_list.append(specificity_random)
            
#     
#   ------------------------------------------------------------
#
    value_list   =   []
    for i in range(len(random_true_positive_list)):
        value_list.append(random_true_positive_list[i][optimal_index])
    mean_tp = np.mean(value_list)
    stddev_tp = np.std(value_list)
    
    value_list   =   []
    for i in range(len(random_false_positive_list)):
        value_list.append(random_false_positive_list[i][optimal_index])
    mean_fp = np.mean(value_list)
    stddev_fp = np.std(value_list)
        
    value_list   =   []
    for i in range(len(random_false_negative_list)):
        value_list.append(random_false_negative_list[i][optimal_index])
    mean_fn = np.mean(value_list)
    stddev_fn = np.std(value_list)

    value_list   =   []
    for i in range(len(random_true_negative_list)):
        value_list.append(random_true_negative_list[i][optimal_index])
    mean_tn = np.mean(value_list)
    stddev_tn = np.std(value_list)

    value_list   =   []
    for i in range(len(random_hit_rate_list)):
        value_list.append(random_hit_rate_list[i][optimal_index])
    mean_hr = np.mean(value_list)
    stddev_hr = np.std(value_list)
    
    value_list   =   []
    for i in range(len(random_specificity_list)):
        value_list.append(random_specificity_list[i][optimal_index])
    mean_spec = np.mean(value_list)
    stddev_spec = np.std(value_list)

    value_list   =   []
    for i in range(len(random_precision_list)):
        value_list.append(random_precision_list[i][optimal_index])
    mean_pre = np.mean(value_list)
    stddev_pre = np.std(value_list)

    value_list   =   []
    for i in range(len(random_accuracy_list)):
        value_list.append(random_accuracy_list[i][optimal_index])
    mean_acc = np.mean(value_list)
    stddev_acc = np.std(value_list)

# 
#   ------------------------------------------------------------
#

    print()
    print('--------------------------------------')
    print('')
    print('Forecast Interval: ', str(forecast_interval) + ' Years')
    print('')
    print('Threshold Value: ', str(round(float(threshold_value[optimal_index]),3)) )
    print('')
    print('Mean TP: ', str(round(mean_tp,3)) + ' +/- ' + str(round(stddev_tp,3)))
    print('')
    print('Mean FP: ', str(round(mean_fp,3)) + ' +/- ' + str(round(stddev_fp,3)))
    print('')
    print('Mean FN: ', str(round(mean_fn,3)) + ' +/- ' + str(round(stddev_fn,3)))
    print('')
    print('Mean TN: ', str(round(mean_tn,3)) + ' +/- ' + str(round(stddev_tn,3)))
    print('')
    print('Mean Random Hit Rate: ', str(round(mean_hr,3)) + ' +/- ' + str(round(stddev_hr,3)))
    print('')
    print('Mean Random Specificity: ', str(round(mean_spec,3)) + ' +/- ' + str(round(stddev_spec,3)))
    print('')
    print('Mean Random Precision: ', str(round(mean_pre,3)) + ' +/- ' + str(round(stddev_pre,3)))
    print('')
    print('Mean Random Accuracy: ', str(round(mean_acc,3)) + ' +/- ' + str(round(stddev_acc,3)))
    print('')
    print('--------------------------------------')
    print('')
        
    return

    ##############################################r########################
    
def timeseries_to_EMA(timeseries_orig, N_Steps):

    #   timeseries_orig is a list input.  Output is a list that is an Exponential Moving Average

    timeseries_EMA = []
        
    for i in range(1,len(timeseries_orig)+1):
        timeseries_raw = []
         
        for j in range(i):
            timeseries_raw.append(timeseries_orig[j])
             
        datapoint_EMA = EMA_weighted_time_series(timeseries_raw, N_Steps)
         
        timeseries_EMA.append(datapoint_EMA)
                  
    return timeseries_EMA
    
    ######################################################################
    
def EMA_weighted_time_series(time_series, NSteps):

    #   This method computes the Exponential Weighted Average of a list.  Last
    #       in the list elements are exponentially weighted the most

    N_events = len(time_series)
    
    weights = EMA_weights(N_events, NSteps)
    
    weights_reversed = list(reversed(weights))

    EMA_weighted_ts = []
    partial_weight_sum = 0.
    
    for i in range(N_events):
        partial_weight_sum += weights[i]
        weighted_ts = round(float(time_series[i])*weights_reversed[i],4)
        
        EMA_weighted_ts.append(weighted_ts)
        
    partial_weight_sum = round(partial_weight_sum,4)
    sum_value = sum(EMA_weighted_ts)
    
    if (float(partial_weight_sum)) <= 0.0:
        sum_value = 0.0001
        partial_weight_sum = 1.
    
    try:
        weighted_sum = float(sum_value)/float(partial_weight_sum)
    except:
        weighted_sum = 0.0
    
    return weighted_sum
    
    ######################################################################
    
def EMA_weights(N_events, N_Steps):

    #   This method computes the weights for the Exponential Weighted Average (EMA)

    alpha = 2./float((N_Steps+1))

    #   time_series_list is the time series of floating point values
    #       arranged in order of first element in list being earliest

    assert 0 < alpha <= 1
    
    weights = []
    
    #   Define the weights
    
    for i in range(0,N_events):
        weight_i = (1.0-alpha)**i
        weights.append(weight_i)
        
    sum_weights = sum(weights)
    weights =  [i/sum_weights for i in weights]
     
    return weights
    
    ######################################################################
    
def compute_ROC(times_window, values_window, forecast_interval, exclude_ROC_time, mag_large, min_mag, \
        number_thresholds, number_random_timeseries, time_number):

    #   First we find the min value, then progressively lower (actually raise) the threshold and determine the
    #       hit rate and false alarm rate
    
    true_positive_rate              =   []
    false_positive_rate             =   []
    true_negative_rate              =   []
    false_negative_rate             =   []
    
    true_positive               =   []
    false_positive              =   []
    true_negative               =   []
    false_negative              =   []
    
    acc_rate                        =   []
    threshold_value                 =   []
    
    year_large_eq, mag_large_eq, index_large_eq, lat_large_eq, lng_large_eq  = get_large_earthquakes(mag_large, min_mag)
    
    values_window = [float(values_window[i]) for i in range(len(values_window))]
    
    min_value = min(values_window)
    max_value = max(values_window)
    delta_threshold = (max_value - min_value) / number_thresholds
    
    if time_number > 0:
        print('Calculating Random Time Series: '+ str(time_number) + ' out of ' + str(number_random_timeseries), end="\r", flush=True)
    
    threshold = min_value - delta_threshold
    
    print('')
    
    excluded_time = int(forecast_interval * 13) + exclude_ROC_time
    
    for i in range(number_thresholds):
        threshold = threshold + delta_threshold
        fp = 0.
        tp = 0.
        tn = 0.
        fn = 0.
        
        for j in range(len(times_window) - excluded_time):  #   We exclude the last time that has incomplete data
        
            test_flag = True
        
            for k in range(len(year_large_eq)):
            
                delta_time = year_large_eq[k] - times_window[j]

                #   if value less than or equal to threshold and at least 1 eq occurs within forecast interval, tp
                if delta_time <= forecast_interval and delta_time >= 0 and float(values_window[j]) <= threshold and test_flag:
                    tp += 1.0
                    test_flag = False
                        
                #   if value less than or equal to threshold, so predicted to occur within forecast interval,
                #       and eq does not occur within forecast interval, fp        
                if delta_time > forecast_interval and delta_time >= 0 and float(values_window[j]) <= threshold and test_flag:
                    fp += 1.0
                    test_flag = False

                #   if value greater than threshold, so predicted not to occur within forecast interval, 
                #       and eq does occur within forecast interval, fn      
                if delta_time <= forecast_interval and delta_time >= 0 and float(values_window[j]) > threshold and test_flag:
                    fn += 1.0
                    test_flag = False

                #   if value greater than threshold and eq does not occur within forecast interval, tn      
                if delta_time > forecast_interval and delta_time >= 0 and float(values_window[j]) > threshold and test_flag:
                    tn += 1.0
                    test_flag = False
                        
        true_positive.append(tp)
        false_positive.append(fp)
        true_negative.append(tn)
        false_negative.append(fn)
        
        threshold_value.append(threshold)
        
    return  true_positive, false_positive, true_negative, false_negative, threshold_value
    
    ######################################################################
    
def compute_spatial_ROC_rates(true_positive, false_positive, true_negative, false_negative):

    true_positive_rate      =   [0.]
    false_positive_rate     =   [0.]
    true_negative_rate      =   [1.]
    false_negative_rate     =   [1.]

    for i in range(len(true_positive)):
    
        tp = true_positive[i]
        fp = false_positive[i]
        tn = true_negative[i]
        fn = false_negative[i]
    
        tpr = 0.
        try:
            tpr = tp/(tp + fn)
        except:
            pass
            
        fpr = 0.
        try:
            fpr = fp/(fp + tn)
        except:
            pass
        
        fnr = 0.
        try:
            fnr = fn/(fn + tp)
        except:
            pass
            
        tnr = 0.
        try:
            tnr = tn/(tn + fp)
        except:
            pass
    
        tpr = round(tpr,4)
        fpr = round(fpr,4)
        fnr = round(fnr,4)
        tnr = round(tnr,4)
        
        #   For each value of i
        true_positive_rate.append(tpr)
        false_positive_rate.append(fpr)
        true_negative_rate.append(tnr)
        false_negative_rate.append(fnr)

    return true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate
    
    ####################################################################
    
def compute_ROC_rates(true_positive, false_positive, true_negative, false_negative):

    true_positive_rate      =   []
    false_positive_rate     =   []
    true_negative_rate      =   []
    false_negative_rate     =   []
    
    for i in range(len(true_positive)):
    
        tp = true_positive[i]
        fp = false_positive[i]
        tn = true_negative[i]
        fn = false_negative[i]
    
        tpr = 0.
        try:
            tpr = tp/(tp + fn)
        except:
            pass
            
        fpr = 0.
        try:
            fpr = fp/(fp + tn)
        except:
            pass
        
        fnr = 0.
        try:
            fnr = fn/(fn + tp)
        except:
            pass
            
        tnr = 0.
        try:
            tnr = tn/(tn + fp)
        except:
            pass
    
        tpr = round(tpr,4)
        fpr = round(fpr,4)
        fnr = round(fnr,4)
        tnr = round(tnr,4)
        
        #   For each value of i
        true_positive_rate.append(tpr)
        false_positive_rate.append(fpr)
        true_negative_rate.append(tnr)
        false_negative_rate.append(fnr)


    return true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate
    
    ######################################################################
    
def calc_ROC_skill(values_window, times_window, true_positive, false_positive, true_negative, false_negative, \
                    threshold_value, forecast_interval, mag_large, min_mag, plot_start_year,\
                    data_string_title, number_thresholds, NELng_local, SWLng_local, NELat_local, SWLat_local, \
                    Grid, Location, NSteps, delta_time_interval, lambda_mult, min_rate):
                    
# 
#   ------------------------------------------------------------
#
#   Plot ROC and random ROCs

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                SEISRCalcMethods.compute_ROC_rates(true_positive, false_positive, true_negative, false_negative)   


    skill_score =   trapz(true_positive_rate, false_positive_rate)  #   Use the trapezoidal integration rule

        
    return skill_score

    ##############################################r########################
    
def random_timeseries(values_window, times_window):

    random_values = []
    
    for i in range(len(values_window)):
        random_values.append(np.random.choice(values_window, replace=True))
        
    return random_values
    
    ######################################################################
    
def calc_precision_threshold(true_positive, false_positive, true_negative, false_negative):
# 
#   ------------------------------------------------------------
#
#   This method computes the precision list from the thresholds

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                compute_ROC_rates(true_positive, false_positive, true_negative, false_negative)   
                
    precision_list = []
    for i in range(len(true_positive)):
        numer = true_positive[i]
        denom = false_positive[i] + true_positive[i]
        
        try:
            precision_value = (numer/denom)
        except:
            precision_value = 0.
            
        precision_list.append(precision_value)
        
    return precision_list

    ######################################################################
    
def compute_precision_timeseries(times_window, values_window, threshold_value, precision_list):

    #   This method converts the isr timeseries into a precision timeseries
    
    precision_timeseries = []
    
    for i in range(len(times_window)):
    
        precision = 0.
    
        for j in range(len(threshold_value)):
        
            if values_window[i] >= threshold_value[j]:
                 precision = precision_list[j]
                 
        precision_timeseries.append(round(100.0*precision,3))
        
    return precision_timeseries
    
    ######################################################################
    
def calc_temporal_ROC_skill(times_window, values_window, forecast_interval, exclude_ROC_time, mag_large, min_mag, number_thresholds):
                    
# 
#   ------------------------------------------------------------
#
#   Plot ROC and random ROCs

    true_positive, false_positive, true_negative, false_negative, threshold_value\
                     = compute_ROC(times_window, values_window, forecast_interval, exclude_ROC_time,\
                     mag_large, min_mag, number_thresholds, 0, 0)

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                compute_ROC_rates(true_positive, false_positive, true_negative, false_negative)   
                
    equi_fpr, equi_tpr = SEISRUtilities.interpolate_to_equidistant(false_positive_rate, true_positive_rate)
    
    skill_score_seisr =   trapz(equi_tpr, equi_fpr)  #   Use the trapezoidal integration rule
                
    return skill_score_seisr

    ##############################################r########################
    
def calc_ROC_skill(times_window, values_window, forecast_interval, exclude_ROC_time, mag_large, min_mag, number_thresholds):
# 
#   ------------------------------------------------------------
#
#   Calculate ROC and random ROCs

    true_positive, false_positive, true_negative, false_negative, threshold_value\
                     = compute_ROC(times_window, values_window, forecast_interval, exclude_ROC_time,\
                     mag_large, min_mag, number_thresholds, 0, 0)

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                compute_ROC_rates(true_positive, false_positive, true_negative, false_negative)   
                
    equi_fpr, equi_tpr = SEISRUtilities.interpolate_to_equidistant(false_positive_rate, true_positive_rate)
    
    skill_score_seisr =   trapz(equi_tpr, equi_fpr)  #   Use the trapezoidal integration rule
# # 
#   ------------------------------------------------------------
#        
 
    
    #   Redefine the hit rate and false alarm rate arrays
    number_intervals = 100
    
    fpr_bins = list(range(0,number_intervals))
    fpr_bins = [float(fpr_bins[i])/float(number_intervals) for i in range(number_intervals)]
    delta_bins = 1./float(number_intervals)
    
    tpr_bins        =   []
    
    for i in range(number_intervals):
        hit_value = 0.0
        counter   = 0
        for j in range(len(false_positive_rate)):
            if false_positive_rate[j] >= i*delta_bins and false_positive_rate[j] < (i+1)*delta_bins:  
                hit_value += true_positive_rate[j]
                counter += 1
        try:
            tpr_bins.append(hit_value/float(counter))
        except:
            tpr_bins.append(hit_value)
        
        fpr_bins_array = np.array(fpr_bins)
        tpr_bins_array = np.array(tpr_bins)
        
    # Compute the area using the composite trapezoidal rule.
    area_trapz = trapz(tpr_bins_array, dx=delta_bins)

    # Compute the area using the composite Simpson's rule.
    skill_score_trapz = round(area_trapz,3)
    
# 
#   ------------------------------------------------------------
#

    skill_score = skill_score_trapz
        
    return skill_score

    ######################################################################
    
def compute_seisr_time_list(delta_time, lambda_min_mult, lambda_max_mult, NSteps, plot_start_year, mag_large, min_mag):


    time_list, eqs_list = read_input_earthquake_data(delta_time, min_mag, lambda_min_mult)
    mean_eqs    = round(np.mean(eqs_list),3)
                
    eqs_list_unfiltered  = eqs_list
            
    for i in range(len(time_list)):
        if int(eqs_list[i]) <= lambda_min_mult*mean_eqs:
            eqs_list[i] = lambda_min_mult*mean_eqs
    
    #   Apply Exponential Moving Average to eqs_list
    eqs_list_EMA = timeseries_to_EMA(eqs_list, NSteps)
    
    #   Generate the SEISR times and filter the timeseries data to occur only after the plot_start_year
    
    time_list_reduced, log_number_reduced, eqs_list_reduced = \
            calc_seisr_timeseries(time_list, eqs_list_EMA, plot_start_year, mag_large,min_mag, delta_time)
                
    return time_list_reduced, log_number_reduced, eqs_list_reduced
    
    ######################################################################
    
def compute_seisr_local_time_list(delta_time, lambda_mult, NSteps, plot_start_year, mag_large, min_mag, \
        reference_lat, reference_lng, local_radius):

    time_list_local, eqs_list_local = read_input_local_earthquake_data\
            (delta_time, min_mag, lambda_mult, reference_lat, reference_lng, local_radius)
            
    mean_eqs    = round(np.mean(eqs_list_local),3)
                
    for i in range(len(time_list_local)):
        if int(eqs_list_local[i]) <= lambda_mult*mean_eqs:
            eqs_list_local[i] = lambda_mult*mean_eqs
    
    #   Apply Exponential Moving Average to eqs_list
    eqs_list_EMA_local = timeseries_to_EMA(eqs_list_local, NSteps)
    
    #   Generate the SEISR times and filter the timeseries data to occur only after the plot_start_year
    
    time_list_local_reduced, log_number_local_reduced, eqs_list_local_reduced = \
            calc_seisr_timeseries(time_list_local, eqs_list_EMA_local, plot_start_year, mag_large,min_mag, delta_time)
                
    return time_list_local_reduced, log_number_local_reduced, eqs_list_local_reduced
    
    ######################################################################
    
def calc_forecast_hits_threshold(times_window, values_window, forecast_interval, year_large_eq, threshold_value, index_threshold):

    windows_number    =   0      #   Same number of elements as times window.  1 if qualifying window, 0 otherwise
    hits_number       =   0      #   Likewise.  For each element, 1 if eq occurs in the window, 0 otherwise
    
    freq_hits = 0
    
    for i in range(len(times_window)):      #   Hits for a given threshold

        if values_window[i] >= threshold_value[index_threshold]: #   Will be counted among qualifying time intervals
        
            windows_number += 1   #   Add to the number of qualifying time windows
            end_time = times_window[i] + forecast_interval
            hits_value = 0
            
            for j in range(len(year_large_eq)):
                if year_large_eq[j] >= times_window[i] and year_large_eq[j] < end_time:
                    hits_value = 1          #   Can only be counted once
                    
            hits_number += hits_value
    
    if windows_number > 0:
        freq_hits = float(hits_number)/float(windows_number)

    return freq_hits
    
    ######################################################################
    
def calc_observed_frequency(times_window, values_window, forecast_interval, year_large_eq, threshold_value):

    observed_stats_list = []

    for index_threshold in range(len(threshold_value)):
        
        freq_hits = calc_forecast_hits_threshold(times_window, values_window, \
                forecast_interval, year_large_eq, threshold_value, index_threshold)
        
        observed_stats_list.append(freq_hits)

    return observed_stats_list
    
    ######################################################################
    
def coarse_grain_seismic_timeseries(NELat_local, NELng_local, SWLat_local, SWLng_local, \
            min_mag, max_depth, grid_size, delta_time_interval,
            date_array, time_array, year_array, lng_array, lat_array, mag_array, depth_array, label_events):
    
    #   This method builds the local timeseries in small grid boxes. 

    #   Use only events after plot_start_year
    
    
    num_lat_boxes = int( (NELat_local - SWLat_local)/grid_size )
    num_lng_boxes = int( (NELng_local - SWLng_local)/grid_size)
    
    num_total_boxes = num_lat_boxes * num_lng_boxes
    
    number_timeseries_found = 0
    total_counter = 0
    
    grid_box_locations  =   []
    grid_box_indices    =   []
    
    timeseries  =   []
    
#   ------------------------------------------------------------
#
#   The cutoff factor determines the minimum number of small earthquakes that are needed for each grid box
#
    total_time_interval = float(year_array[len(year_array)-1]) - float(year_array[0]) 
    
    last_event_year = float(year_array[len(year_array) - 1])
        
    number_year_bins = int((last_event_year - float(year_array[0]))/delta_time_interval) +1
    
#   ------------------------------------------------------------
    
    #   Define times of bins
    
    time_bins   =   []
    date_bins   =   []
    
    for i in range(number_year_bins):
        time_bins.append(float(year_array[0]) + float(i)*delta_time_interval)
    
    print('')
    print('Length of time_bins: ', len(time_bins))
    print('')
            
#   ------------------------------------------------------------
#   
    #   Define the grid boxes: Filter the regional data into (num_total_boxes) time series
    
    number_polygon_vertices = 4

    #   Construct the string of polygon vertices.  Note that the order is lat, long pairs
    
    for i in range(num_lat_boxes):
        for j in range(num_lng_boxes):
        
            ll = i+j
        
            vertex_lat = []
            vertex_lng = []
            
            mag_file   = []
            year_file  = []
            
    #   Order of vertices of large rectangular region:  SW, SE, NE, NW
    
            W_box_lng = SWLng_local + j*grid_size           #   West side of small box
            E_box_lng = SWLng_local + (j+1)*grid_size       #   East side of small box
            
            S_box_lat = SWLat_local + i*grid_size           #   North side of small box
            N_box_lat = SWLat_local + (i+1)*grid_size       #   South side of small box
            
            vertex_lat.append(S_box_lat)
            vertex_lat.append(S_box_lat)
            vertex_lat.append(N_box_lat)
            vertex_lat.append(N_box_lat)
    
            vertex_lng.append(W_box_lng)
            vertex_lng.append(E_box_lng)
            vertex_lng.append(E_box_lng)
            vertex_lng.append(W_box_lng)

            point_list = []
            
            for k in range(number_polygon_vertices):
                point_list.append((float(vertex_lat[k]),float(vertex_lng[k])))
    
            polygon = Polygon(point_list)
            
            index_timeseries = int(i + j*(num_lat_boxes))
        
#   ------------------------------------------------------------

    #   Compute the timeseries here and then timeseries[index_timeseries] = the timeseries you computed
    
            for kk in range(len(year_array)):

                point = Point((float(lat_array[kk]),float(lng_array[kk])))
        
                if (float(depth_array[kk]) <= float(max_depth) and float(mag_array[kk]) >= float(min_mag) \
                        and polygon.contains(point) == True):
                        
                    mag_file.append(float(mag_array[kk]))
                    year_file.append(float(year_array[kk]))
                
#   ------------------------------------------------------------

    #   Fill the working_file with the events over the time period.  Each week in working_file will
    #       record the number of events that occurred that week.
    
            last_event_year = float(year_array[len(year_array) - 1])

            working_file = [0.0 for i in range(int(number_year_bins))]
            
            for k in range(len(year_file)):
                index_working = int((float(year_file[k]) - float(year_array[0]))/delta_time_interval )
                working_file[index_working] += 1.0       #  This is a number timeseries
#
#           For the activity time series, number_years is the minimum number of active time bins required
#
            total_counter += 1
            
            lat_center = 0.5*(N_box_lat + S_box_lat)
            lng_center = 0.5*(W_box_lng + E_box_lng)
            grid_box_locations.append((lng_center,lat_center))
            grid_box_indices.append((j,i))

            timeseries.append(working_file)
            
            number_timeseries_found += 1
            
            print('')
            print('***************************************************')
            print('Found Timeseries Number ', number_timeseries_found, ' of ', num_total_boxes)
            print('Total number of events: ', sum(working_file))
            print('Grid Box Center @ Lat, Long: ', round(lat_center,3), round(lng_center,3))
            print('With indices @ Lat Index, Long Index: ', i,j)
            print('For minimum magnitude events >= ', min_mag)
            print('***************************************************')
            print('')

    for i in range(len(time_bins)):
        k = 0
        while float(year_array[k]) <= float(time_bins[i]) and k < len(year_array):
            date_value = date_array[k+1]
            k += 1
            
        date_bins.append(date_value)
                
    print('')
    print('Total Grid Boxes: ', num_total_boxes)
    print('')
    
    lat_print = []
    lng_print = []
    
    output_file = open('gridboxes.txt','w')
    for i in range(len(grid_box_locations)):
        lat_print = grid_box_locations[i][1]
        lng_print = grid_box_locations[i][0]
        lat_index = grid_box_indices[i][1]
        lng_index = grid_box_indices[i][0]
        
        print(round(float(lat_print),4), round(float(lng_print),4), lat_index, lng_index, file=output_file) 
    output_file.close()                                                     #      with space between
    
    output_file = open('timeseries.txt','w')
    print(' '.join(map(str,time_bins)), file=output_file)
    for i in range(len(timeseries)):
        timeseries_print = timeseries[i]                
        print(' '.join(map(str,timeseries_print)), file=output_file) #   Map converts list to string, joins elements
    output_file.close()                                                     #      with space between

#   Note: Refer to the elements of each timeseries as, e.g., timeseries[0][0] for the first list
#     return timeseries, grid_box_locations   

    return timeseries, time_bins, date_bins
    
    ######################################################################
    
def  define_EMA_timeseries(NSteps, min_mag):

    time_bins, timeseries = SEISRFileMethods.get_timeseries_data(min_mag)

    timeseries_N = []
    
    for i in range(len(timeseries)):
            working_list = timeseries[i]
            working_list_EMA = timeseries_to_EMA(working_list, NSteps)
            working_list_EMA = [round(working_list_EMA[j], 3) for j in range(len(working_list_EMA))]
            timeseries_N.append(working_list_EMA)
            
    output_file = open('timeseries_EMA' + '.txt','w')
    print(' '.join(map(str,time_bins)), file=output_file)
    for i in range(len(timeseries_N)):
        timeseries_print = timeseries_N[i]                
        print(' '.join(map(str,timeseries_print)), file=output_file) #   Map converts list to string, joins elements
    output_file.close()        

    return
    
    ######################################################################
    
def classify_large_earthquakes_grid_boxes(NELat_local, NELng_local, SWLat_local, SWLng_local, \
                        grid_size, index_ROC, time_list_reduced, forecast_interval,\
                        mag_array_large, year_array_large, depth_array_large, lat_array_large, lng_array_large):
                        
                        
    #   This code classifies the large earthquakes (M>4.95) between time_bins[i] and time_bins[i] + forecast_interval
    #       into the appropriate grid boxes.  Result is a list whose elements are the number of large earthquakes in 
    #       those grid boxes

    num_lat_boxes = int( (NELat_local - SWLat_local)/grid_size )
    num_lng_boxes = int( (NELng_local - SWLng_local)/grid_size)
    
    num_total_boxes = num_lat_boxes * num_lng_boxes
    
    ROC_event_list    =   [0 for i in range(num_total_boxes)]
#    
#   ------------------------------------------------------------
#   
    #   >>>>>>>>>  Define the grid boxes: Classify the large earthquakes into the appropriate grid boxes  <<<<<<<<<<
    
    number_polygon_vertices = 4

    #   Construct the string of polygon vertices.  Note that the order is lat, long pairs
    
    total_events = 0
    
    for i in range(num_lat_boxes):
        for j in range(num_lng_boxes):
        
#             ll = i+j    #   The grid box number
        
            vertex_lat = []
            vertex_lng = []
            
            
    #   Order of vertices of large rectangular region:  SW, SE, NE, NW
    
            W_box_lng = SWLng_local + j*grid_size           #   West side of small box
            E_box_lng = SWLng_local + (j+1)*grid_size       #   East side of small box
            
            S_box_lat = SWLat_local + i*grid_size           #   North side of small box
            N_box_lat = SWLat_local + (i+1)*grid_size       #   South side of small box
            
            vertex_lat.append(S_box_lat)
            vertex_lat.append(S_box_lat)
            vertex_lat.append(N_box_lat)
            vertex_lat.append(N_box_lat)
    
            vertex_lng.append(W_box_lng)
            vertex_lng.append(E_box_lng)
            vertex_lng.append(E_box_lng)
            vertex_lng.append(W_box_lng)

            point_list = []
            
            for k in range(number_polygon_vertices):
                point_list.append((float(vertex_lat[k]),float(vertex_lng[k])))
    
            polygon = Polygon(point_list)
            
            index_grid_box = int(i + j*(num_lat_boxes))
        
#   ------------------------------------------------------------

    #   Compute the timeseries here and then timeseries[index_timeseries] = the timeseries you computed
    
            for kk in range(len(year_array_large)):

                point = Point((float(lat_array_large[kk]),float(lng_array_large[kk])))
                
                current_time = float(time_list_reduced[index_ROC])
                later_time   = current_time + forecast_interval
        
                if (float(year_array_large[kk]) >= current_time and float(year_array_large[kk]) < later_time  \
                        and polygon.contains(point) == True):
                        
                    ROC_event_list[index_grid_box] += 1
                    
                    total_events += 1
                
    return ROC_event_list   # Number of events by grid box
    
    ######################################################################
    
def sort_list_EQ_RTI_order(ROC_event_list,  NELat_local, NELng_local, SWLat_local, SWLng_local, min_mag, index_time, \
        timeseries_EMA, NSteps, lambda_mult):
                        
    #   This method ingests the ROC_event_list and places that and the linked list into a list of descending order
    #       so that it can be used to plot the ROC curve
                        
#   ------------------------------------------------------------
#
#   Compute Relative Total Intensity list
    
    ROC_gridbox_threshold_list = []
    
    for i in range(len(timeseries_EMA)):    #   Number of gridboxes
    
#       Partial_ROC_list = timeseries_EMA[i][:index_time]

        ROC_list = timeseries_EMA[i][:]
        mean_ROC_list    = np.mean(ROC_list)    #    Not used now.  We just plot the EMA timeseries on the maps, we don't assume
                                                #       a minimum number of earthquakes
        
        ROC_test = timeseries_EMA[i][index_time]

        ROC_gridbox_threshold_list.append(ROC_test)
        
    sum_norm = 100.0/sum(ROC_gridbox_threshold_list)  #   Normalize all the spatial probability to 100%
#     
    ROC_gridbox_threshold_list = [ROC_gridbox_threshold_list[i]*sum_norm for i in range(len(ROC_gridbox_threshold_list))]
    
    ROC_gridbox_threshold_list = [math.log(1.0 + ROC_gridbox_threshold_list[i], 10) for i in range(len(ROC_gridbox_threshold_list))]
    
    ROC_gridbox_threshold_list = [round(ROC_gridbox_threshold_list[i],3) for i in range(len(ROC_gridbox_threshold_list))]
#  
#   ------------------------------------------------------------
#
    return ROC_gridbox_threshold_list
#  
    ######################################################################

def compute_spatial_ROC(ROC_gridbox_events_list, ROC_gridbox_threshold_list):
                    

    #   First we find the min value, then progressively lower the threshold and determine the
    #       hit rate and false alarm rate
    #
    #   Point here is to determine how many boxes above the threshold have at least 1 event in them = tp
    #       No events = fp.  Etc.
    
    true_positive               =   []
    false_positive              =   []
    true_negative               =   []
    false_negative              =   []
    threshold_value             =   []
    
    number_thresholds = 500     #   for the spatial ROC
    number_grid_boxes = len(ROC_gridbox_threshold_list)
    
    min_value = 0
    max_value = max(ROC_gridbox_threshold_list)      # In %
    
    delta_threshold = (max_value) / number_thresholds
    
    #   Classify the grid boxes to compute the ROC
    
    for i in range(number_thresholds):
        current_threshold = max_value - float(1+i)*delta_threshold
        
        
        tp = 0
        fp = 0
        fn = 0
        tn = 0
        
        for j in range(number_grid_boxes):
        
            
        
            # Current threshold less than grid box value, and SOME events occurred: tp
            if ROC_gridbox_threshold_list[j] >= current_threshold and ROC_gridbox_events_list[j] > 0:  
                tp += 1
            
            # Current threshold less than grid box value, and NO events occurred: fp
            if ROC_gridbox_threshold_list[j] >= current_threshold and ROC_gridbox_events_list[j] == 0:  
                fp += 1
                
            # Current threshold greater than grid box value, and SOME events occurred: fn
            if ROC_gridbox_threshold_list[j] < current_threshold and ROC_gridbox_events_list[j] > 0:  
                fn += 1
                
            # Current threshold greater than grid box value, and NO events occurred: tn
            if ROC_gridbox_threshold_list[j] < current_threshold and ROC_gridbox_events_list[j] == 0:  
                tn += 1
                
        true_positive.append(tp)
        false_positive.append(fp)
        true_negative.append(tn)
        false_negative.append(fn)
        
        threshold_value.append(current_threshold)

    return true_positive, false_positive, true_negative, false_negative, threshold_value
    
    ######################################################################


def compute_spatial_ROC_rates(true_positive, false_positive, true_negative, false_negative):

    true_positive_rate      =   [0.]
    false_positive_rate     =   [0.]
    true_negative_rate      =   [1.]
    false_negative_rate     =   [1.]

    for i in range(len(true_positive)):
    
        tp = true_positive[i]
        fp = false_positive[i]
        tn = true_negative[i]
        fn = false_negative[i]
    
        tpr = 0.
        try:
            tpr = tp/(tp + fn)
        except:
            pass
            
        fpr = 0.
        try:
            fpr = fp/(fp + tn)
        except:
            pass
        
        fnr = 0.
        try:
            fnr = fn/(fn + tp)
        except:
            pass
            
        tnr = 0.
        try:
            tnr = tn/(tn + fp)
        except:
            pass
    
        tpr = round(tpr,4)
        fpr = round(fpr,4)
        fnr = round(fnr,4)
        tnr = round(tnr,4)
        
        #   For each value of i
        true_positive_rate.append(tpr)
        false_positive_rate.append(fpr)
        true_negative_rate.append(tnr)
        false_negative_rate.append(fnr)

    return true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate
    
    ####################################################################
    
def combine_images(input_file1, folder1, input_file2, folder2, quicktime_frame_rate_divisor, last_frames_only):

    # get images    
    
    input_list1 = []
    input_list2 = []
    
    input_file_images1 = open(input_file1, 'r')
    
    for line in input_file_images1:
        items1 = line.strip().split('/')
        input_list1.append(folder1 + items1[-1])
        
    input_file_images1.close()
    
    #   Compute the first index for the combined images
    
    if last_frames_only:
    
        leading_chars = "./Data_for_Movies/DataMoviesPPV/Timeseries_Precision_000"
        trailing_chars = ".png"
    
        remaining_chars = input_list1[0].strip(leading_chars)
        remaining_chars = remaining_chars.strip(trailing_chars)
    
        first_index = quicktime_frame_rate_divisor * int(float(remaining_chars))   #   First index of combined images
    
    input_file_images2 = open(input_file2, 'r')
    
    for line in input_file_images2:
        items2 = line.strip().split('/')
        input_list2.append(folder2 + items2[-1])
        
    input_file_images2.close()
    
    for i in range(len(input_list1)):

    
        image1 = input_list1[i]
        image2 = input_list2[i]
    
        img1 = Image.open(image1)
        img2 = Image.open(image2)
        
    # get width and height
        w1, h1 = img1.size
        w2, h2 = img2.size
        
    #   -----------------------------------------
    #
    #   Crop the images
        
        # Setting the points for cropped img1
        left = 10
        top = 0
        right = w1-50
        bottom = h1
 
        # Cropped image of above dimension
        # (It will not change original image)
        img1 = img1.crop((left, top, right, bottom))
        
        w1, h1 = img1.size
        
        # Setting the points for cropped img2
        left = 175
        top = 0
        right = w2
        bottom = h2
 
        # Cropped image of above dimension
        # (It will not change original image)
        img2 = img2.crop((left, top, right, bottom))
        
        w2, h2 = img2.size
    
    #
    #   -----------------------------------------
        
        # to calculate size of new image 
        w = max(w1, w2)
        h = max(h1, h2)
        
#         
        img1 = img1.resize((int(w*1.2),h2)) #   Use if timeseries is plotted with spatial pdf
        
        w = max(w1, w2)
        h = max(h1, h2)
        
        # create big empty image with place for images
        combined_image = Image.new('RGB', (int(w*2.225), h*1))

        # put images on new_image
        combined_image.paste(img1, (0, 0))
        combined_image.paste(img2, (int(w*1.15), 0)  )  #   To move images a bit farther apart
        
        # save it
        for jframe in range(quicktime_frame_rate_divisor):
            frame_index = quicktime_frame_rate_divisor * i + jframe
            if last_frames_only:
                frame_index = quicktime_frame_rate_divisor * i + jframe + first_index
            combined_image.save('./Data_for_Movies/DataMoviesCombined/PPV_LogRTI_combined_image_000' + str(frame_index) + '.png')
            
            print()
            print('Creating Combined Image: ', '000' + str(frame_index) + ' of ' + str(len(input_list1)* quicktime_frame_rate_divisor-1))
        
    return
    
    ####################################################################
    
def calc_ROC_information_entropy(threshold_value, true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate):

    info_tp  =   0.
    info_fp  =   0.
    info_roc =   0.
    
    mean_tpr = 0.
    mean_fpr = 0.
    
    roc_density = []
    
    number_thresholds = len(threshold_value)
    
    for i in range(1,number_thresholds):
        diff_tp = true_positive_rate[i] - true_positive_rate[i-1]   #   supposed to be the pdf
        diff_fp = false_positive_rate[i] - false_positive_rate[i-1]
        

        mean_tpr += (threshold_value[i]- threshold_value[0]) * diff_tp
        mean_fpr += (threshold_value[i]- threshold_value[0]) * diff_fp
        
#         print('i, true_positive_rate[i], diff: ', i, true_positive_rate[i], diff)
        
        tp_term = 0.
        fp_term = 0.
        roc_term = 0.
        
    #   -------------------------------------------------------------
        
        try:
            tp_term = diff_tp * math.log2(diff_tp)
            fp_term = diff_fp * math.log2(diff_fp)
            
        except:
            pass
            
        info_tp -= tp_term
        info_fp -= fp_term
        
    #   -------------------------------------------------------------
    
        roc_density_value = 0.
        try:
            roc_density_value = diff_tp/diff_fp
        except:
            pass
            
        roc_density.append(roc_density_value)
        
    #   -------------------------------------------------------------
    
    roc_sum = sum(roc_density)
    if roc_sum == 0:
        roc_sum = np.mean(roc_density)
    roc_density = [roc_density[i]/roc_sum for i in range(len(roc_density))]
    
    for i in range(len(roc_density)):
        roc_term = 0.
        try:
            roc_term = roc_density[i] * math.log2(roc_density[i])
        except:
            pass
        
        info_roc -= roc_term
        
    #   -------------------------------------------------------------
        
    info_random = math.log2(float(number_thresholds)-1.)  

    return info_tp, info_fp, info_random, info_roc, mean_tpr, mean_fpr
    
    ######################################################################
    
def jensen_shannon_divergence_ROC(true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate):
            
    random_flag = False
    
    number_thresholds = len(true_positive_rate)
    
    uniprob = 1./float(number_thresholds)
    
    tp_prob         =   []
    random_prob     =   [] 
    
    for i in range(1,number_thresholds):
        diff = true_positive_rate[i] - true_positive_rate[i-1]
        
        tp_term = 0.
        try:
            tp_term = diff
        except:
            pass
            
        tp_prob.append(tp_term)
        random_prob.append(uniprob)
        
    m_prob = [0.5*(tp_prob[i] + random_prob[i]) for i in range(len(tp_prob))]
    
    kl_divergence_tp        = kullback_leibler_ROC(tp_prob, m_prob)
    kl_divergence_random    = kullback_leibler_ROC(random_prob, m_prob)
    
    kl_divergence      = kullback_leibler_ROC(tp_prob, random_prob)
    
    js_divergence = 0.5*(kl_divergence_tp + kl_divergence_random)
        
    return  js_divergence, kl_divergence
    
    ######################################################################
    
def kullback_leibler_ROC(prob1, prob2):

    kl_divergence = 0.
    for i in range(len(prob1)):
        sum_arg = 0.
        try:
            sum_arg = prob1[i] * math.log2(prob1[i]/prob2[i])
        except:
            pass
        kl_divergence += sum_arg

    return kl_divergence
    
    ######################################################################
    
def calc_precision_threshold(true_positive, false_positive, false_negative, true_negative, threshold_value):

    threshold_reduced   =   []
    precision           =   []
    precision_info      =   []
    
    precision_value = 1.0
    for i in range(1,len(true_positive)):
        numer = true_positive[i]
        denom = false_positive[i] + true_positive[i]
        threshold_reduced.append(threshold_value[i])
        
        precision_value = 1.0
        
        try:
            precision_value = numer/denom
        except:
            pass

        precision.append(precision_value)
        
        if precision_value == 0.0:
            precision_value = 1.0       #   So that the Log_2 does not blow up
        
        precision_info_value = -math.log2(precision_value)
        precision_info.append(precision_info_value)
        
    return precision, precision_info, threshold_reduced
    
    ######################################################################
    
def calc_random_precision_threshold(precision, values_window, times_window, forecast_interval, exclude_ROC_time,  mag_large, min_mag,\
                number_thresholds, number_random_timeseries):
        
#   -------------------------------------------------

#   Computes the random precision curves and the associated random self information

    random_ppv_list    =   []  #   This will be a list of random lists
    
    for i in range(number_random_timeseries):
    
        random_values = random_timeseries(values_window, times_window)
        
        true_positive_random, false_positive_random, true_negative_random, false_negative_random, threshold_value_random = \
                compute_ROC(times_window, random_values, forecast_interval, exclude_ROC_time, mag_large, min_mag,\
                number_thresholds, number_random_timeseries, i+1)
                
        ppv_random          =   []
        
        for k in range(1,len(true_positive_random)):
            numer = true_positive_random[k]
            denom = false_positive_random[k] + true_positive_random[k]
            
            trial_arg = 1.0
            
            try:
                trial_arg = numer/denom
            except:
                pass
                
            ppv_random.append(trial_arg)
            
            
        random_ppv_list.append(ppv_random)
        
    #   -------------------------------------------------------------

    stddev_curve    =   []
    mean_curve      =   []
    
    for i in range(len(random_ppv_list[0])):
        working_list = []
        for j in range(number_random_timeseries):
            working_list.append(random_ppv_list[j][i])
            
        stddev_curve.append(np.std(working_list))
        mean_curve.append(np.mean(working_list))
        
    random_upper = []
    random_lower = []
    
    for i in range(len(mean_curve)):
        trial_plus = mean_curve[i] + stddev_curve[i]
        if trial_plus > max(precision):
            trial_plus = max(precision)
        random_upper.append(trial_plus)
        
        trial_minus = mean_curve[i] - stddev_curve[i]
        if trial_minus < 0.01:
            trial_minus = 0.01
        random_lower.append(trial_minus)
        
    return random_ppv_list, mean_curve, random_upper, random_lower
    
    ######################################################################
    
def build_EMA_timeseries(catalog, timeseries, time_bins, forecast_intervals, NSteps,\
            plot_start_year, mag_large,min_mag, delta_time, lambda_min_mult, lambda_max_mult, USGS):
            
            
    #   Define the fundamental list eqs_list from the timeseries
    
    time_list = time_bins.copy()
    
    eqs_list            =   []
    
    #   Compute the list of earthquakes for all spatial bins
    for i in range(len(timeseries[0])):         #   This sums over all times
        eqs_sum = 0.
        
        for j in range(len(timeseries)):        #   This j index sums over all spatial grid boxes for a given time index i
            eqs_sum += timeseries[j][i]
        
        if eqs_sum < 1:                         #   If no earthquakes that month
            eqs_sum = 1.0
            
        eqs_list.append(eqs_sum)
        
    #   -------------------------------------------------------------
    #
    #   Define the weights of the of the timeseries for each grid box for the Exponential Moving Average
        
    timeseries_weights  =   []
    
    for i in range(len(timeseries[0])): 
        weight_working_list = []
        
        for j in range(len(timeseries)):        #   This j index sums over all spatial grid boxes for a given time index i
            weight_working_list.append(timeseries[j][i]/eqs_list[j])
            
        timeseries_weights.append(weight_working_list)   #  First index is grid box number, second index will be time index

    #   -------------------------------------------------------------
    
    #   Adjust earthquake time series to have a minimum and maximum monthly value            
    
    excluded_months = int(forecast_intervals[0] * 13)
    eqs_list_excluded = eqs_list[:-excluded_months]
    
    mean_eqs_excluded   = round(np.mean(eqs_list_excluded),3)
    stdev_eqs_excluded  = round(np.std(eqs_list_excluded),3)
    
    min_rate = lambda_min_mult * mean_eqs_excluded
    max_rate = lambda_max_mult * stdev_eqs_excluded + min_rate   #   1.0 works best so far
    
    #   Default is above max_rate
    #   However, for special cases set a new max rate by hand
    
    if catalog == 'Athens':
        max_rate = 50.

    
#     mean_eqs    = round(np.mean(eqs_list),3)
    
    for i in range(len(time_list)):
        if int(eqs_list[i]) <= min_rate:
            eqs_list[i] = min_rate
        if int(eqs_list[i]) >= max_rate:
            eqs_list[i] = max_rate
    
    #   Apply Exponential Moving Average to eqs_list
    eqs_list = timeseries_to_EMA(eqs_list, NSteps)

    
    eqs_list_rounded = [round(eqs_list[i],0) for i in range(len(eqs_list))]

    #   Generate the monthly seismicity timeseries and require the timeseries data to occur only after the plot_start_year
    
    time_list_reduced, log_number_reduced, eqs_list_reduced = \
                calc_seisr_timeseries(time_list, eqs_list, plot_start_year, mag_large,min_mag, delta_time, USGS)
                
    times_window = time_list_reduced
    values_window = log_number_reduced
    
    #   -------------------------------------------------------------
        
    number_points_to_plot = 0
    
    for k in range(len(time_list)):
        if time_list[k] >= plot_start_year:
            number_points_to_plot += 1
            
    NN = number_points_to_plot
    
    timeseries_EMA = build_weighted_EMA_timeseries(timeseries, NSteps)
    
    return timeseries_EMA, times_window, values_window, eqs_list, time_list_reduced, log_number_reduced, \
            eqs_list_reduced, NN, min_rate, max_rate
    
    ######################################################################
    
def build_weighted_EMA_timeseries(timeseries, NSteps):

    #   Define the EMA timeseries
    
    timeseries_EMA = []
    
    for i in range(len(timeseries)):             #   Index i runs over all grid boxes
        EMA_working = []
        for j in range(len(timeseries[0])):      #   Index j runs over all time indices
            EMA_working.append(timeseries[i][j])

        EMA_out_list = timeseries_to_EMA(EMA_working, NSteps) # EMA average over timeseries in the ith grid box
        
        timeseries_EMA.append(EMA_out_list) #   These are the timeseries in the grid boxes converted to EMA timeseries
        
    return timeseries_EMA
    
    ######################################################################
    
def build_local_timeseries(reference_lat, reference_lng, local_radius, min_mag, max_depth, delta_time_interval):

    #   This method builds the local timeseries in a local circular region 
    #   Read the regional catalog
    
    mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = \
            SEISRFileMethods.read_regional_catalog(min_mag)
            
    timeseries  =   []
    
#   ------------------------------------------------------------
#
#   The cutoff factor determines the minimum number of small earthquakes that are needed for each grid box
#
    total_time_interval = float(year_array[len(year_array)-1]) - float(year_array[0]) 
    
    last_event_year = float(year_array[len(year_array) - 1])
        
    number_year_bins = int((last_event_year - float(year_array[0]))/delta_time_interval) +1
    

#   ------------------------------------------------------------
    
    #   Define times of bins
    
    time_bins   =   []
    date_bins   =   []
    
    year_file = []
    mag_file  = []
    
    last_event_year = float(year_array[len(year_array) - 1])
    
    for i in range(number_year_bins):
        time_bins.append(float(year_array[0]) + float(i)*delta_time_interval)
    
    print('')
    print('Length of time_bins: ', len(time_bins))
    print('')
            
#   ------------------------------------------------------------
#   
    #   Define the grid boxes: Filter the regional data into the circular region
    
    working_file = [0.0 for i in range(int(number_year_bins))]

    
    for i in range(len(year_array)):
    
        lat_1 = reference_lat
        lng_1 = reference_lng
                
        lat_2 = lat_array[i]
        lng_2 = lng_array[i]
    
        great_circle_distance = SEISRUtilities.compute_great_circle_distance(lat_1, lng_1, lat_2, lng_2)
    
        if (float(depth_array[i]) <= float(max_depth) and float(mag_array[i]) >= float(min_mag) \
                        and great_circle_distance >= local_radius):
                        
            mag_file.append(float(mag_array[i]))
            year_file.append(float(year_array[i]))
                
#   ------------------------------------------------------------

    #   Fill the working_file with the events over the time period.  Each week in working_file will
    #       record the number of events that occurred that week.
    
    for k in range(len(year_file)):
        index_working = int((float(year_file[k]) - float(year_array[0]))/delta_time_interval )
        working_file[index_working] += 1.0       #  This is a number timeseries
#
    timeseries.append(working_file)
        
    date_bins.append(date_array[0])

    for i in range(len(time_bins)):
        k = 0
        while float(year_array[k]) <= float(time_bins[i]) and k < len(year_array):
            date_value = date_array[k+1]
            k += 1
            
        date_bins.append(date_value)
                
    output_file = open('timeseries.txt','w')
    print(' '.join(map(str,time_bins)), file=output_file)
    timeseries_print = timeseries[0]                
    print(' '.join(map(str,timeseries_print)), file=output_file) #   Map converts list to string, joins elements
    output_file.close()                                           #      with space between

#   Note: Refer to the elements of each timeseries as, e.g., timeseries[0][0] for the first list
#     return timeseries, time_bins, date_bins   

    return timeseries, time_bins, date_bins
    
    ######################################################################
    
def calc_temporal_ROC(catalog, timeseries, time_bins, forecast_intervals, NSteps, exclude_ROC_time,\
                plot_start_year, mag_large, min_mag, number_thresholds, lambda_min_mult, lambda_max_mult, delta_time):
                    
# 
#   ------------------------------------------------------------
#
#   Plot ROC and random ROCs

    forecast_interval = forecast_intervals[0]

    timeseries_EMA, times_window, values_window, eqs_list, time_list_reduced, log_number_reduced, \
                eqs_list_reduced, NN, min_rate, max_rate = build_EMA_timeseries\
                (catalog, timeseries, time_bins, forecast_intervals, NSteps,\
                plot_start_year, mag_large, min_mag, delta_time, lambda_min_mult, lambda_max_mult)
                
    true_positive, false_positive, true_negative, false_negative, threshold_value = compute_ROC\
                (times_window, values_window, forecast_interval, exclude_ROC_time,\
                mag_large, min_mag, number_thresholds, 0, 0)

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = compute_ROC_rates\
                (true_positive, false_positive, true_negative, false_negative)   
                

#   ------------------------------------------------------------
#
    skill_score =   trapz(true_positive_rate, false_positive_rate)  #   Use the trapezoidal integration rule
    

    
    print()
    print('--------------------------------------')
    print()
    print('Skill Score: ', round(skill_score,3))
    print()
    print('--------------------------------------')
    print()
#
    return skill_score

    ######################################################################
    
    
