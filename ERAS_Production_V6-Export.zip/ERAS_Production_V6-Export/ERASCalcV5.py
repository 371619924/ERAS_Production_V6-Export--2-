    #   ---------------------------------------------------------------------------------------
    
    # Copyright 2023 by John B Rundle, University of California, Davis, CA USA
    # 
    # Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
    # documentation files (the     "Software"), to deal in the Software without restriction, including without 
    # limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
    # and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
    # 
    # The above copyright notice and this permission notice shall be included in all copies or suSKLantial portions of the Software.
    # 
    # THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
    # WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
    # COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACTORT OR OTHERWISE, 
    # ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
    #
    # Note that some part of these codes were written by the AI program chatGPa product of openAI
    #
    #   ERAS is the "Rescaled Aftershock Method for Stochastic Earthquake Seismicity"
    #
    #
    #   ---------------------------------------------------------------------------------------
    
    #   Stochastic Earthquake Rescaled Cluster Model

import numpy as np
import random
import matplotlib.pyplot as plt
import math
from math import log10
import datetime
import time

import ERASUtilities
import ERASPlotV3
import ERASFileMethods

import Compute_EMA_Timeseries


    ###############################################################################################
    
#   Define ERAS functions

# ...................................................................

def mag_freq(m, mu,bval, aval):

    return 10.0**(-bval*(m-mu) + aval)

# ...................................................................
    
def generate_catalog(ntmax):

#   Define arrays and lists
    
    catalog         = np.empty((0, 4))
    catalog_mu      = np.empty((0, 4))

    mags                    = []
    time_events             = []
    x_events                = []
    y_events                = []
    z_events                = []

    working_list            = []
    aftershock_list         = []

    Sum_m   =   []
    Sum_mu  =   []
    nt_list =   []
    
    mu, mag_large_omori, mag_large, max_swarm_mag, bval, BathNumber, step_lat, step_lng, scale_factor, \
        pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
        = ERASFileMethods.read_parameter_file()
    
    ###############################################################################################
    ###############################################################################################
    
    #   Main program

    #   Initialize variables

    x=0.
    y=0.
    z=10.

    zmin = 0.
    zmax = 20.

    nt = 0
    
    m = mu
    mag_threshold = mu + BathNumber 
    
    step_factor = 1.0
    
    mag_mainshock = 7.0
    event_label = 'b'

#   ----------------------------------------------------------------

    #   Read in USGS file for background events
    
    LA_lat = 34.0522
    LA_lng = -188.2437

    USGS_input_file = './USGS_regional.catalog'
    input_file = open(USGS_input_file, 'r')
    
    lat_events  =   []
    lng_events  =   []
    mag_events  =   []
    
    lat_lng_all             =   []
    lat_lng_big             =   []
    lat_lng_mid             =   []
    lat_lng_all_Bath        =   []
    
    number_background  = 0
    number_aftershocks = 0
    
    for line in input_file:
        items = line.strip().split()
        mag        = float(items[5])
        mag_events.append(mag)
        
        if mag >= mu + BathNumber:
            eq_lat = float(items[4])
            eq_lng = float(items[3])
            lat_lng_all_Bath.append((eq_lat,eq_lng))
            
        if mag >= mu:
            eq_lat = float(items[4])
            eq_lng = float(items[3])
            lat_lng_all.append((eq_lat,eq_lng))
            
        if mag >= 5.25 and mag < 6.25:  #   Was 5.5 and 6.5
            eq_lat = float(items[4])
            eq_lng = float(items[3])
            lat_lng_mid.append((eq_lat,eq_lng))
            
        if mag >= 6.25:                 #   Was 6.5
            eq_lat = float(items[4])
            eq_lng = float(items[3])
            lat_lng_big.append((eq_lat,eq_lng))
            
    lat_lng_all_Bath = lat_lng_all       
#   ----------------------------------------------------------------

    counter = 1
    
    label_events  =   []
    
    epicenter = random.choice(lat_lng_all)           #   Just pick an epicenter from the existing catalog of California sites
    last_lat = epicenter[0]
    last_lng = epicenter[1]
    
    kk = 0

    t = 0.
    
    last_mainshock_mag = mu
    
    aval = 0.
    max_mag = 8.0     #   Used this on 5/11/2024
    delta_mag = max_mag - mu
    probm = mag_freq(np.arange(0, delta_mag, 0.01), mu, bval, aval)\
            /np.sum(mag_freq(np.arange(0, delta_mag, 0.01), mu, bval, aval))
            
    mag_list_random = np.random.choice(mag_events, size=len(mag_events), replace=False)
    
    mag_index = 0
    
    number_running_aftershocks = 0
    
    while nt < ntmax:
    
        nt+= 1
        
        dt = - 1. * math.log(1 - np.random.random()) # Creates random times between events
        
    #   -------------------------------------------------------------
        
        t += dt
        
        m = mu + np.random.choice(np.arange(0, delta_mag, 0.01), p = probm)
        
        last_counter = counter
            
#   ----------------------------------------------------------------
        
        lat_event, lng_event, counter, event_label, mag_mainshock =  \
                lat_lng_all_california(lat_lng_all, lat_lng_all_Bath, lat_lng_mid, lat_lng_big,\
                counter, last_counter, nt, last_lat, last_lng, m, mu, bval,\
                mag_threshold, step_lat, step_lng, BathNumber)
                
        if m >= 5.0:
            print('nt, dx, y, m, last_counter, counter: ', \
                    nt, round(t,4), round(dt,4), round(x,4), round(y,4), round(m,2), last_counter, counter, event_label)
            print()
                
        if event_label == 'b':
            number_background += 1
            mag_mainshock = m           #   Implementing Bath's law

        elif event_label == 'a':
            number_aftershocks += 1
        
        last_lat = lat_event
        last_lng = lng_event
        
        #   Convert lng-lat to x,y coordinates relative to LA
        
        x = compute_great_circle_distance(LA_lat, lng_event, LA_lat, LA_lng)
        x = abs(x)
        if lng_event < LA_lng:
            x = -x
        y = compute_great_circle_distance(lat_event, LA_lng, LA_lat, LA_lng)
        y = abs(y)
        if lat_event < LA_lat:
            y = -y

        zrandom = np.random.uniform(-1,1)
        z = z + step_factor*zrandom 

        if z < zmin:
            z = zmin
        elif z > zmax:
            z = zmax
        
#   ----------------------------------------------------------------

        if nt<500:
            t0 = t
    
        if nt >= 500:           #   Neglect any transients
#
            mags.append(m)
            time_events.append(t-t0)
            nt_list.append(nt-500)
    
            x_events.append(lng_event)
            y_events.append(lat_event)
            z_events.append(z)
            
            label_events.append(event_label)
            
        if m>= 5.:
            print('m, last_lat, last_lng, last_counter, counter, event_label: ', \
                    m, round(last_lat,5), round(last_lng,5), last_counter, counter, event_label)
    
        if m >= mag_large:    #   Write some stuff and accumulate aftershocks for plotting
            
            kk+= 1
            print('******* Event number: ' + str(nt) + ' of ' + str(ntmax) + ' Events at time '+  str(round(t,3)) +\
                ', for event ' + str(kk) + ' that had magnitude M' + str(round(m,3)) + ', which is >= M' + str(mag_large),  \
                ', and last_counter = ', last_counter, ', and counter = ', counter, ' and event_label = ', event_label)
                
            print()
            time.sleep(5) # Sleep for 2 seconds
            
    print()
    fraction_aftershocks = round( 100.0*float(number_aftershocks)/float(number_aftershocks + number_background), 2)
    print('Fraction Aftershocks: ', str(fraction_aftershocks) + '%' )
    
    bval_model, bval_model_error, cept_model, cept_model_error = calc_GR(mags, mu, BathNumber, mag_large)
    
    bval_data, bval_data_error, cept_data, cept_data_error = calc_GR(mag_events, min(mag_events), BathNumber, max(mag_events))
    
    print()
    print('b-Value for this Simulation: ', round(bval_model,3), ' +/- ', round(bval_model_error,3))
    print()
    print('b-Value for the Data: ', round(bval_data,3), ' +/- ', round(bval_data_error,3))
    print()
    
    
    return mags, time_events, x_events, y_events, z_events, label_events, fraction_aftershocks
    
   ###############################################################################################

def mainshock_cycles(mags, events, label_events, mag_large):

    working_list        =   []     #   Save the first event
    
    mags[0] = mag_large #   Just to be sure!
    
    #   First count the number of large events in the time series
    
    number_mag_large = 0
    
    for i in range(len(events)):
        if mags[i] >= mag_large:
            number_mag_large += 1
        
    cycle_list          = [[] for i in range(number_mag_large)]
    label_cycle_list    = [[] for i in range(number_mag_large)]
    
    kk = -1
    for i in range(len(events)):
        if mags[i] >= mag_large:
            kk += 1    
            
        cycle_list[kk].append(events[i])
        label_cycle_list[kk].append(label_events[i])
        
    return cycle_list, label_cycle_list
    
    ###############################################################################################

def omori_recluster(cycle_list, label_cycle_list, events, mags, scale_factor):

    aftershock_list     =   []
    events_adjusted     =   []
    
    
    #   Set the initial version of aftershock_list = cycle_list
    #       (aftershock_list should be a list of lists where the first 
    #       entry in each list is the time of the mainshock)
    
    aftershock_list = cycle_list
    
    #   Pick a random scale factor centered on the input scale factor for each of the individual cycles
    
    #   Now alter aftershock list so that the intial entry into a list is the time of mainshock,
    #   and the remainder are difference times from the mainshock
    
    for i in range(len(aftershock_list)):
        for j in range(1,len(aftershock_list[i])):      #  First entry is time of mainshock
            aftershock_list[i][j] = aftershock_list[i][j] - aftershock_list[i][0] #   Other entries are difference times

    for i in range(len(aftershock_list)):
#
        num_exps = 0
        for k in range(1,len(label_cycle_list[i])-1):   # -2 because we don't apply to mainshock time or last time
            num_exps += 1                             #   This produces TOO MUCH clustering

        num_exps_running = num_exps
        for j in range(1,num_exps):   #   Skip the first entry which is the mainshock time
        
            scale_factor_random = scale_factor   
            
            mult_factor = 0.99**(num_exps_running)    #   num_exps**0.95 helped improve the clustering
            
            mult_factor = (scale_factor + mult_factor)/(1.+scale_factor)
            
            delta_events = aftershock_list[i][j]
            delta_events = delta_events *(mult_factor)         #   Also, using, e.g.,  (mult_factor**eta), eta<1, clusters more
            num_exps_running -= 1
            
            aftershock_list[i][j] = delta_events
            
    for i in range(len(aftershock_list)):
#     
        for j in range(len(aftershock_list[i])):
            if j == 0:
                time_event = aftershock_list[i][j]
            else:
                time_event = aftershock_list[i][j] + aftershock_list[i][0]
            events_adjusted.append(time_event)
            
    return events_adjusted, aftershock_list
    
    ###############################################################################################
    
def analyze_omori_clustering(cycle_lislabel_cycle_list):

    aftershock_list     =   []
    
    #   Set the initial version of aftershock_list = cycle_list
    #       (aftershock_list should be a list of lists where the first 
    #       entry in each list is the time of the mainshock)
    
    aftershock_list = cycle_list
    
    #   Alter aftershock list so that the intial entry into a list is the time of mainshock,
    #       and the remainder are difference times from the mainshock
    
    for i in range(len(aftershock_list)):
        for j in range(1,len(aftershock_list[i])):      #  First entry is time of mainshock
            aftershock_list[i][j] = aftershock_list[i][j] - aftershock_list[i][0] #   Other entries are difference times

    time_scale_list = []

    for i in range(len(aftershock_list)):

        time_flag = True
    
        for j in range(1,len(aftershock_list[i])):
        
            if aftershock_list[i][j] > 0.001 and time_flag:
                time_scale = aftershock_list[i][j]
                time_flag = False

        time_scale_list.append(time_scale)
        
    time_scale = np.mean(time_scale_list)
    
    return time_scale
    
    ###############################################################################################
    
#   Generate data for frequency magnitude

def freq_mag(mags, mag_large):

    bin_diff= 0.1
    number_mag_bins = (float(mag_large) - float(min(mags)) + 1) * 10

    number_mag_bins     =   int(number_mag_bins)
    range_mag_bins      =   int(number_mag_bins)

    freq_mag_bins_pdf       =   np.zeros(number_mag_bins)
    freq_mag_bins_sdf       =   np.zeros(number_mag_bins)
    freq_mag_pdf_working    =   np.zeros(number_mag_bins)
#     mag_array               =   zeros(number_mag_bins)  
    for i in range(len(mags)):
        if mags[i] <= mag_large:
            bin_number      = int(round(((float(mags[i])-float(min(mags)))/float(bin_diff)),1))
            freq_mag_bins_pdf[bin_number]    +=  1

    for i in range(0,range_mag_bins):
        for j in range(i,range_mag_bins):                           # Loop over all bins to compute the GR cumulative SDF
            freq_mag_bins_sdf[i] += freq_mag_bins_pdf[j]

    number_nonzero_bins=0
    for i in range(0,range_mag_bins):                               # Find the number of nonzero bins
        if freq_mag_bins_sdf[i] > 0:
            number_nonzero_bins+=1

    range_bins = int(number_nonzero_bins)                         # Find number of nonzero bins

    log_freq_mag_bins   =   np.zeros(number_nonzero_bins)              # Define the log freq-mag array

    for i in range(0,range_bins):
        if freq_mag_bins_sdf[i] > 0.0:
            log_freq_mag_bins[i] = -100.0                               # To get rid of it.
            log_freq_mag_bins[i] = math.log10(freq_mag_bins_sdf[i])     # Take the log-base-10 of the survivor function

    mag_bins  =   np.zeros(number_nonzero_bins)
    for i in range(0,range_bins):
      mag_bins[i]=min(mags) + float(i)*bin_diff

    #.................................................................
    
    print_data = False

    if print_data:
        print()
        print(mag_bins)
        print()
        print(freq_mag_bins_pdf)
        print()
        print(freq_mag_bins_sdf)
        print()
        print(log_freq_mag_bins)
        print()
        
    return mag_bins, freq_mag_bins_pdf, freq_mag_bins_sdf, log_freq_mag_bins
    
    ###############################################################################################

def decimal_year_to_date(decimal_year):

#     print('decimal_year', decimal_year)

    year = int(decimal_year)
    days_in_year = (datetime.date(year+1, 1, 1) - datetime.date(year, 1, 1)).days
    day_of_year = int((decimal_year - year) * days_in_year)
    date = datetime.datetime.fromordinal(datetime.date(year, 1, 1).toordinal() + day_of_year - 1)
    time_of_day = datetime.timedelta(seconds=int((decimal_year % 1) * 24 * 60 * 60))
    time_of_day = str(time_of_day) +  '.00'

    return date.strftime('%Y/%m/%d'), time_of_day
    
    ###############################################################################################
    
def sum_aftershock_intrvl(event_list):

    working_list = []
    
    for i in range(1, len(event_list)):
        working_list.append(event_list[i])
        
    aftershock_sum = np.sum(working_list)
    
    return aftershock_sum


    ###############################################################################################
    
def lat_lng_all_california(lat_lng_all, lat_lng_all_Bath, lat_lng_mid, lat_lng_big, counter, last_counter, nt, last_lat, last_lng, \
            m, mu, bval, mag_threshold, step_lat, step_lng, BathNumber):
            
    mag_mainshock = m

    event_occurred = False
        
    if nt == 0:  #   The first event is always larger than the threshold
        counter = int(10** (bval*(m - mu - BathNumber))) +  1
        epicenter = random.choice(lat_lng_all)           #   Just pick an epicenter from the existing catalog of California sites
        lat_event = epicenter[0]
        lng_event = epicenter[1]
        choice = 0
        event_occurred = True
        
    if m < mag_threshold and counter <= 0 and nt > 0 and event_occurred == False:
        epicenter = random.choice(lat_lng_all)          #   Just pick an epicenter at random from the existing 
                                                        #   catalog of past California sites.  These are background events
        if m >= 5.25 and m < 6.25:
            epicenter = random.choice(lat_lng_mid)
        if m >= 6.25:
            epicenter = random.choice(lat_lng_big)
        lat_event = epicenter[0]
        lng_event = epicenter[1]
        choice = 1
        event_occurred = True
                    
    elif m < mag_threshold and counter > 0 and nt > 0 and event_occurred == False:  
                                                        #   Do the random walk, because this small event is still 
                                                        #   an aftershock within the group following the last large event
                                                        #   This is an aftershock
        #  choose a new site from the random walk
        lat_aftershock, lng_aftershock = random_walk_aftershocks(last_lng, last_lat, step_lat, step_lng)
        lat_event = lat_aftershock
        lng_event = lng_aftershock
        choice = 2
        event_occurred = True
        
    elif m >= mag_threshold and counter <= 0 and nt > 0 and event_occurred == False:    
                                                            #   A large event just occurred that can have aftershocks, we 
                                                            #   so we reset the aftershock counter and pick a 
                                                            #   epicenter at random from the list of possible locations
                                                            #   This is a background event
        counter = int(10** (bval*(m - mu - BathNumber))) + 1
        
        if m >= mu+BathNumber:
            epicenter = random.choice(lat_lng_all_Bath)     
        if m >= 5.25 and m < 6.25:
            epicenter = random.choice(lat_lng_mid)
        if m >= 6.25:
            epicenter = random.choice(lat_lng_big)
            
        lat_event = epicenter[0]
        lng_event = epicenter[1]
        choice = 3
        event_occurred = True
        
    elif m >= mag_threshold and counter > 0 and nt > 0 and event_occurred == False:     
                                                            #   We are in the aftershock train from a large earthquake,
                                                            #   and we just had an aftershocks that can itself have aftershocks
                                                            #   so we we might extend the counter if the aftershock magnitude
                                                            #   was large enough.  This is an aftershock
        new_counter = int(10** (bval*(m - mu - BathNumber))) + 1
        if new_counter > counter:
            counter = new_counter
            
        #  choose a new site from the random walk
        lat_aftershock, lng_aftershock = random_walk_aftershocks(last_lng, last_lat, step_lat, step_lng)
        lat_event = lat_aftershock
        lng_event = lng_aftershock
        choice = 4
        event_occurred = True
        
    last_lng = lng_event
    last_lat = lat_event
    counter -= 1
    
    #   Set event labels
    
    if last_counter <= 0 and counter <= 0:
        event_label = 'b'
        mag_mainshock = m
        
    elif last_counter <= 0 and counter > 0:
        event_label = 'b'
        mag_mainshock = m
        
    elif last_counter > 0 and counter <= 0:     #   Only makes sense if counter = 0
        event_label = 'b'
        
    elif last_counter > 0 and counter > 0:
        event_label = 'a'
    
    return lat_event, lng_event, counter, event_label, mag_mainshock
    
    ###############################################################################################
    
def random_walk_aftershocks(last_lng, last_lat, step_lat, step_lng):

    lng_random = np.random.choice([-1,1])
    lat_random = np.random.choice([-1,1])

    lng_aftershock = last_lng + step_lng * lng_random
    lat_aftershock = last_lat + step_lat * lat_random      

    return  lat_aftershock, lng_aftershock
    
    ###############################################################################################
    
def compute_great_circle_distance(lat_1, lng_1, lat_2, lng_2):

    # Build an array of x-y values in degrees defining a circle of the required radius

    pic = 3.1415926535/180.0
    Radius = 6371.0

    lat_1 = float(lat_1) * pic
    lng_1 = float(lng_1) * pic
    lat_2 = float(lat_2) * pic
    lng_2 = float(lng_2) * pic
    
    delta_lng = lng_1 - lng_2
    
    delta_radians = math.sin(lat_1)*math.sin(lat_2) + math.cos(lat_1)*math.cos(lat_2)*math.cos(delta_lng)
    if delta_radians > 1.0:
        delta_radians = 1.0
    delta_radians = math.acos(delta_radians)
    
    great_circle_distance = delta_radians * Radius

    return great_circle_distance

    ##################################################################
    
def calc_pq_value(number_data, bin_data, bin_lo, bin_hi, scale_exponent):
    
    #   Here us where we count the number of data to fithen define xr[:] and yr[:]
    #   All done in linear corrdinates
    
    print_data = True
    
    xr    =   []
    yr    =   []

    k = -1
    
    for i in range(len(bin_data)):
        if (bin_data[i] >= bin_lo) and (bin_data[i] <= bin_hi):
            k = k + 1
            xr.append(bin_data[i])
            yr.append(number_data[i])

    kmax = k+1
  
    if kmax > 1:
        slope, cept, errs, errc, s2 = ERASUtilities.linfit(xr,yr, kmax)
        if print_data:
#             print(' ')
            
            if scale_exponent == 'p':
                print()
                print('  >> p-value for the region: ', -1*round(slope,3),' +/- ',round(errs,3))
            
    xline = []
    yline = []
    
    for i in range(len(xr)):
        xterm = slope * ( xr[i] - xr[0] ) 
        xline.append(xr[i])  #   slope is negative
        yline.append(yr[0] +  xterm)
        
    #   Now minimize the bias of the line relative to the actual data, i.e., compute a constant
    #       correction to the y-values
    
    error   =   []
    for i in range(len(xr)):
        err_val = (yline[i] - yr[i])
        error.append(err_val)
    mean_error = np.mean(error)
    
#     
#     
    yline   =   [10**(yline[i]- mean_error) for i in range(len(yline))]     
    xline   = [10**(xline[i]) for i in range(len(xline))]

    return xline, yline, slope, errs
            
    ##################################################################
    
def calc_b_value(log_freq_data, mag_data, mag_lo, mag_hi):
    
    #   Here us where we count the number of data to fithen define xr[:] and yr[:]
    
    print_data = True
    
    xr    =   []
    yr    =   []

    k = -1
    
    for i in range(len(mag_data)):
        if (mag_data[i] >= mag_lo) and (mag_data[i] <= mag_hi):
            k = k + 1
            xr.append(mag_data[i])
            yr.append(log_freq_data[i])

    kmax = k+1
    
  
    if kmax > 1:
        slope, cept, errs, errc, s2 = ERASUtilities.linfit(xr,yr, kmax)
    
    xline = []
    yline = []
    
    for i in range(len(xr)):
        xterm = slope * ( xr[i] - xr[0] ) 
        xline.append(xr[i])  #   slope is negative
        yline.append(yr[0] + xterm)
        
    #   Now minimize the bias of the line relative to the actual data, i.e., compute a constant
    #       correction to the y-values, and return the yline value to its expontiated form
    
    error   =   []
    for i in range(len(xr)):
        error.append(yline[i]-yr[i])
    mean_error = np.mean(error)
    
    yline   =   [10**(yline[i]-mean_error) for i in range(len(yline))]        
        
    return xline, yline, slope, errs, cept, errc
            
    ##################################################################
    
def compute_pvalue(pfit_lo, pfit_hi, aftershock_list, bin_length_time):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space\
            = ERASFileMethods.read_parameter_file()

    bin_length = bin_length_time                 #   Days
    time_conversion = bin_length_time/365.
    
    time_interval = 200.    #   Days
    number_bins = int(time_interval/bin_length_time)
    time_bins   = np.arange(bin_length, number_bins, bin_length)
        
    aftershock_number_bins = np.zeros(len(time_bins))
    
    for i in range(len(aftershock_list)):
    
        aftershock_sum = sum_aftershock_intrvl(aftershock_list[i])
        
        duration = len(aftershock_list[i])
        
        if aftershock_sum > 0.:
        
            for j in range(1,len(aftershock_list[i])):
            
                try:
                    bin_index = int( (aftershock_list[i][j])/time_conversion ) + 1
                except:
                    bin_index = 1
                    
                if bin_index < duration:  # Are there aftershocks?
                    try:
                        aftershock_number_bins[bin_index] += 1
                    except:
                        pass
                        
#     
    time_bins = [(time_bins[k]*bin_length) for k in range(len(time_bins)) ]
#     
    time_bins_reduced               =   []
    aftershock_number_bins_reduced  =   []
    
    time_bins_reduced               = time_bins[2:]
    aftershock_number_bins_reduced  = aftershock_number_bins[2:]
    
    #   Remove bins that have no events in them
    
    time_bins_to_plot               =   []
    aftershock_number_bins_to_plot  =   []
    
    for i in range(len(time_bins_reduced)):
        if aftershock_number_bins_reduced[i] > 0.:
            time_bins_to_plot.append(time_bins_reduced[i])
            aftershock_number_bins_to_plot.append(aftershock_number_bins_reduced[i])
            
    #   Compute p-value
    time_lo = math.log10(pfit_lo)          
    time_hi = math.log10(pfit_hi)        

    number_data = [math.log10(aftershock_number_bins_to_plot[i]) for i in range(len(time_bins_to_plot))]
    time_data   = [math.log10(time_bins_to_plot[i]) for i in range(len(time_bins_to_plot))]

    time_line_data, number_line_data, slope, perror = calc_pq_value(number_data, time_data, time_lo, time_hi, 'p')
    
    pfit = - slope

    return pfit, perror
    
    ###############################################################################################
    
def reject_outlier_events(location_list):

    if len(location_list) > 10:
    
        location_list_no_outliers = location_list[:2]     #   start with the first 2 values
        
        for i in range(2, len(location_list)):
            location_std = np.std(location_list_no_outliers)
            
            if abs(location_list[i]) < 2.0*location_std:    #   Within 3 standard deviations = 99% confidence
                location_list_no_outliers.append(location_list[i])
                
    return location_list_no_outliers
    
    ###############################################################################################
    
def reject_outlier_steps(steps_list):

    steps_std = np.std(steps_list)     #   Start by computing the standard deviation
    steps_list_no_outliers = []
    
    for i in range(len(steps_list)):
        if steps_list[i] < 2.0*steps_std:        #   Within 2 standard deviations = 95% confidence
            steps_list_no_outliers.append(steps_list[i])
            
    return steps_list_no_outliers
    
    ###############################################################################################


def random_walk_step_size(aftershock_list, label_events, x_events, y_events, date_events, \
            mag_large_omori, mags, USGS):

    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space \
            = ERASFileMethods.read_parameter_file()

    index_mainshock = 0
    
    latitude_list   =   []
    longitude_list  =   []
    
    for i in range(len(aftershock_list)):
    
        #   Find number of aftershocks in a cycle
        
        aftershock_sum = sum_aftershock_intrvl(aftershock_list[i])
        
        duration = len(aftershock_list[i])
        
        if aftershock_sum > 0.1:
        
            working_list_lat    =   []
            working_list_lng    =   []  
        
            for j in range(1,len(aftershock_list[i])):
            
                if j > 1 and mags[index_mainshock] >= mag_large_omori and USGS:

                    try:
                        if label_events[index_mainshock+j] == 'a':
                            
                            delta_latitude  = (y_events[index_mainshock+j] - y_events[index_mainshock])
                            delta_longitude = (x_events[index_mainshock+j] - x_events[index_mainshock])
                            
                            working_list_lat.append(round(delta_latitude,5))
                            working_list_lng.append(round(delta_longitude,5))
                    except:
                        pass
                        
            #   Compute a running value of variance.  If the next element is > 3*variance (99% confidence)
            #       reject that next element.  otherwise append it to the list and continue
            
            working_list_lat = reject_outlier_events(working_list_lat)
            working_list_lng = reject_outlier_events(working_list_lng)
            
                        
            if len(working_list_lat) > 0:
                latitude_list.append(round(np.std(working_list_lat)/math.sqrt(len(working_list_lat)),8))

            if len(working_list_lng) > 0:
               longitude_list.append(round(np.std(working_list_lng)/math.sqrt(len(working_list_lng)),8))

        index_mainshock += len(aftershock_list[i])
        
    
    latitude_list  = reject_outlier_steps(latitude_list)
    
    longitude_list = reject_outlier_steps(longitude_list)
        
    step_lat_mean   = round(np.mean(latitude_list),8)
    step_lat_std    = round(np.std(latitude_list),8)
    
    step_lng_mean   = round(np.mean(longitude_list),8)
    step_lng_std    = round(np.std(longitude_list),8)
    
    #   -------------------------------
    print()
    print('************************************************')
    print()
    print('  Mean Latitude Step Size: ', round(step_lat_mean,5), ' +/- ', round(step_lat_std,5), ' Degrees' )
    print()
    print('  Mean Longitude Step Size: ', round(step_lng_mean,5), ' +/- ', round(step_lng_std,5), ' Degrees' )
    print()
    print('USGS? :', USGS)
    print()
    print('************************************************')
    #   -------------------------------
    
    return step_lat_mean, step_lat_std, step_lng_mean, step_lng_std
    
    ###############################################################################################
    
def calc_GR(mags, mu, BathNumber, mag_large):

    mag_threshold = mu + BathNumber
        
    mag_bins, freq_mag_bins_pdf, freq_mag_bins_sdf, log_freq_mag_bins = freq_mag(mags, mag_large)
    
    freq_mag_bins = [10**(log_freq_mag_bins[i]) for i in range(len(log_freq_mag_bins))]
    
    #   Compute b-value
    mag_lo = mu                 #   log10(10)
    mag_hi = 5.5                #   log10(100)

    mag_line_data, freq_line_data, slope, slope_error, cept, cept_error = calc_b_value(log_freq_mag_bins, mag_bins, mag_lo, mag_hi)
    
    bval_fit = - slope
    bval_error = slope_error

    return bval_fit, bval_error, cept, cept_error

    ###############################################################################################
    
def calc_migration_radius(space_bins, space_histogram, USGS):

    #   Normalize histogram to produce pdf
    space_pdf = np.array(space_histogram)/np.sum(space_histogram)
    radius_array = np.array(space_bins)
    
    radius_mean = np.sum(radius_array * space_pdf)
    
    radius_variance = (radius_array - radius_mean)**2
    radius_variance = np.sum(radius_mean * space_pdf)
    radius_std = math.sqrt(radius_variance)

    #   -------------------------------
    
    return radius_mean, radius_std
    
    ###############################################################################################

def compute_rescaled_aftershock_locations(temp_space_multiplier, USGS):
        
    mu, mag_large_omori, mag_large, max_swarm_mag,  bval, BathNumber, step_lat, step_lng, scale_factor, \
            pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, bin_length_time, bin_length_space\
            = ERASFileMethods.read_parameter_file()
            
    input_file_name = './Output_Files/ERAS_Time_Clustered.txt'
    
    if USGS:
        input_file_name = './Output_Files/ERAS_USGS.txt' 
    
    date_events, time_events, year_events, x_events, y_events, mags, z_events, label_events = \
            read_existing_catalog(input_file_name)
    
    local_radius = 100. #   Km
    number_space_bins = int(local_radius/bin_length_space)
    
    space_bins = np.arange(bin_length_space, number_space_bins, bin_length_space)   
    
    aftershock_number_bins_space = np.ones(len(space_bins))
    
    #   ---------------------------------------------------
    
    x_events_adjusted   =   np.array(x_events)
    y_events_adjusted   =   np.array(y_events)
    
    delta_lat_array = np.zeros(len(y_events))
    delta_lng_array = np.zeros(len(x_events))
    radius_array    = np.zeros(len(x_events))
    
    lat_lng_ratio = step_lat/step_lng
    
    #   ---------------------------------------------------
        
    #   Compute the delta distances for the aftershocks
    
    mainshock_lat_list = []
    mainshock_lng_list = []
    
    mainshock_flag = False

    for i in range(len(x_events)):
#     
        if mainshock_flag == False:
            mainshock_lat = y_events[i]
            mainshock_lng = x_events[i]
    
        if label_events[i] == 'b' and mags[i] > mu + BathNumber:
            mainshock_lat = y_events[i]
            mainshock_lng = x_events[i]
            mainshock_flag = True
            
        if label_events[i] == 'a' and mainshock_flag:
        
            delta_lat_array[i] = temp_space_multiplier * lat_lng_ratio *(y_events[i] - mainshock_lat)
            delta_lng_array[i] = temp_space_multiplier * (x_events[i] - mainshock_lng)
            
            y_events_adjusted[i] += delta_lat_array[i]
            x_events_adjusted[i] += delta_lng_array[i]
            
            great_circle_distance = ERASUtilities.compute_great_circle_distance\
                                (mainshock_lat, mainshock_lng, y_events_adjusted[i], x_events_adjusted[i])
            if USGS:
                great_circle_distance = ERASUtilities.compute_great_circle_distance\
                            (mainshock_lat, mainshock_lng, y_events[i], x_events[i])
            
            radius_array[i] = great_circle_distance
            
            try:
                bin_index_space = int(great_circle_distance/bin_length_space) + 1
            except:
                space_bin_index_space = 1
                    
            if bin_index_space < len(space_bins) and label_events[i] == 'a':
                aftershock_number_bins_space[bin_index_space] += 1
            
        mainshock_lat_list.append(mainshock_lat)
        mainshock_lng_list.append(mainshock_lng)
           
    #   ---------------------------------------------------
                    
    plot_counter = 0
    for i in range(len(space_bins)):
        j = len(space_bins) - i -1
        if aftershock_number_bins_space[j] > 0.0:     #   With this catalog, we need to stop at about 80 - maybe the minimum time
                                                #       between mag_large events
            plot_counter += 1
#     
    space_bins = [(space_bins[k]*bin_length_space) for k in range(len(space_bins)) ]
    
#     print('aftershock_number_bins_space from calc', aftershock_number_bins_space)
#     
    space_bins_reduced                      =   []
    aftershock_number_bins_space_reduced    =   []
    
    space_bins_reduced                      = space_bins[3:plot_counter]
    aftershock_number_bins_space_reduced    = aftershock_number_bins_space[3:plot_counter]
    
    #   Remove bins that have no events in them
    
    space_bins_to_plot                      =   []
    aftershock_number_bins_space_to_plot    =   []
    
    for i in range(len(space_bins_reduced)):
        if aftershock_number_bins_space_reduced[i] > 0.001:
            space_bins_to_plot.append(space_bins_reduced[i])
            aftershock_number_bins_space_to_plot.append(aftershock_number_bins_space_reduced[i])
            
    #     Compute q-value
    space_lo = math.log10(qfit_lo)          
    space_hi = math.log10(qfit_hi)        

    number_data = [math.log10(aftershock_number_bins_space_to_plot[i]) for i in range(len(space_bins_to_plot))]
    space_data   = [math.log10(space_bins_to_plot[i]) for i in range(len(space_bins_to_plot))]

    space_line_data, number_line_data, slope, qerror = calc_pq_value(number_data, space_data, space_lo, space_hi, 'q')
    
    qfit = - slope
    
    radius_mean, radius_std = calc_migration_radius(space_bins_to_plot, aftershock_number_bins_space_to_plot, USGS)
    
    #   ---------------------------------------------------
            
    return  qfit, qerror, x_events_adjusted, y_events_adjusted, radius_mean, radius_std, \
            space_bins_to_plot, aftershock_number_bins_space_to_plot
    
    ###############################################################################################
    
def read_existing_catalog(input_file_name):

    mags                    =   []
    date_events             =   []
    time_events             =   []
    year_events             =   []
    depth_events            =   []
    y_events                =   []
    x_events                =   []
    label_events            =   []

    data_file = open(input_file_name,"r")
    
    for line in data_file:
        items = line.strip().split()
        
        date_events.append(items[0])
        time_events.append(items[1])
        year_events.append(float(items[2]))
        x_events.append(float(items[3]))
        y_events.append(float(items[4]))
        mags.append(float(items[5]))
        depth_events.append(float(items[6]))
        label_events.append(items[7])
        
    data_file.close()  
    
    return date_events, time_events, year_events, x_events, y_events, mags, depth_events, label_events
    
    ###############################################################################################
    
