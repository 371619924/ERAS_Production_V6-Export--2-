
    #   ---------------------------------------------------------------------------------------
    
    # Copyright 2023 by John B Rundle, University of California, Davis, CA USA
    # 
    # Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
    # documentation files (the     "Software"), to deal in the Software without restriction, including without 
    # limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
    # and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
    # 
    # The above copyright notice and this permission notice shall be included in all copies or suSKLantial portions of the Software.
    # 
    # THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
    # WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
    # COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRAC TORT OR OTHERWISE, 
    # ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
    #
    # Note that some part of these codes were written by the AI program chatGP a product of openai.com
    #
    # This particular code is based on the version ERAS_ChatGPT_V2.13
    #
    #   ERAS is the "Rescaled Aftershock Method for Stochastic Earthquake Seismicity"
    #
    #   ---------------------------------------------------------------------------------------
    ###############################################################################################
    ###############################################################################################
    
    #   This code writes a parameter file by hand if you want to run the ERAS code with specified parameters,
    #   rather than depending on the optimization to set the parameters

import os
import ERASFileMethods

    ###############################################################################################
    ###############################################################################################
    
#   Note that the parameters are stored in the file parameters.txt

mu, mag_large_omori, mag_large, max_swarm_mag,  bval, \
        BathNumber, step_lat, step_lng, scale_factor, pfit_lo, pfit_hi, qfit_lo, qfit_hi, \
        space_multiplier, bin_length_time, bin_length_space = ERASFileMethods.read_parameter_file()
        
#   To substitute a chosen arbitrary value into the parameters.txt file, uncomment one of the statements below

    ###############################################################################################

# If you want to set the parameters for the ERAS model manually, uncomment the appropriate line

# mu = 3.0                                  #   Minimum completeness magnitude for the catalogs
# mag_large = 6.75                          #   Magnitude of large earthquakes for re-clustering or for stacked aftershock plots
# mag_large_omori = 5.75                    #   Magnitude for stacking results to obtain p- and q- values
# max_swarm_mag = 5.5                       #   Maximum swarm magnitude
# bval = 0.95                               #   GR b value
# 
# bin_length_time     = 2.                  #   Days, used for the p-value analysis
# bin_length_space    = 1.0                 #   KM, used for the q-value analysis
# 
# scale_factor = 0.0006                     #   Temporal rescaling factor.  There may be multiple minima for the fits
# 
# space_multiplier = -0.364996              #   Spatial rescaling factor, rescales the step sizes
# 
# step_lat    =   0.01763                   #   In degrees, 95% confidence for M>3
# step_lng    =   0.01045                   #   In degrees, 95% confidence for M>3
#
# BathNumber = 1.2                          #   Bath's law value.  
#                                         
# pfit_lo = 10                              #   Days.  Low value of the parameters to fit a line to the time Omori scaling plot
# pfit_hi = 40                              #   Days.  High value of the parameters to fit a line to the time Omori scaling plot
# 
# qfit_lo = 10.                             #   KM.  Low value of the parameters to fit a line to the space Omori scaling plot
# qfit_hi = 40.                             #   KM   High value of the parameters to fit a line to the space Omori scaling plot
# 
#   Note to me.  Sim seems to do reasonably well with 2 Day bins and pfit_lo = 10 Days, pfit_hi = 50 Days

params = [mu, mag_large_omori, mag_large, max_swarm_mag,  bval, \
        BathNumber, step_lat, step_lng, scale_factor, pfit_lo, pfit_hi, qfit_lo, qfit_hi, space_multiplier, \
        bin_length_time, bin_length_space]
        
ERASFileMethods.write_parameter_file(params)


    ###############################################################################################

