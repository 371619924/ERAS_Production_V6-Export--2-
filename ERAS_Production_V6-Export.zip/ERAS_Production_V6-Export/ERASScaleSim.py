
#   This code is used to explore the effects of temporal rescaling

import numpy as np
import matplotlib.pyplot as plt
import math

import ERASCalcV5
import ERASUtilities

import math

x = np.ones(10000)
y = np.ones(10000)
z = np.ones(10000)

bin_compression_factor = 1.0
scale_exponent = 1.0

for i in range(len(x)):     #   Multiple reclustering doesn't do anything
    j = len(x) - i
#     y[i] = float(x[i]*(0.9999**(j**scale_exponent)))
#     y[i] = math.exp(-1.001**j + 1)
    y[i] = float(x[i]*(0.9999**(j**0.95)))
#     z[i] = float(x[i]*(0.9999**j))
#     
    
n,bins = np.histogram(y,bins=100)

number_data_raw     = n[1:]
bin_data_raw        = bins[2:]

number_data     =   []
bin_data        =   []

for i in range(50):
    number_data.append(number_data_raw[i])
    bin_data.append(bin_data_raw[i])    
    

number_data = [round(math.log10(number_data[i]), 4) for i in range(len(number_data))]
bin_data   = [round(bin_compression_factor*math.log10(bin_data[i]), 4) for i in range(len(bin_data))]

bin_data_adjusted = []
for i in range(len(bin_data)):
    bin_data_adjusted.append(round(bin_data[i] - bin_data[0],4))

space_lo = bin_data_adjusted[1]
space_hi = bin_data_adjusted[20]

space_lo = bin_data[2]
space_hi = bin_data[49]

space_line_data, number_line_data, slope, error = ERASCalcV5.calc_pq_value(number_data, bin_data, space_lo, space_hi, 'p')

print('p-value (= -slope): ',-slope)
# 
fig, ax = plt.subplots()

ax.plot(bin_data_raw,number_data_raw, 'o', markersize = 3, lw=0.)

ax.plot(space_line_data, number_line_data, '--', color = 'red', markersize = 0, lw = 2.0, \
        label='pvalue = ' + str(-round(slope,3)) + ' $\pm$ ' + str(round(error,3)))

ax.set_yscale('log')
ax.set_xscale('log')

Title_text = 'Experiments in Aftershock Scaling for Scale Exponent = ' + str(scale_exponent) 
plt.title(Title_text, fontsize=10)

plt.xlabel('Time or Distance')
plt.ylabel('Number of Aftershocks')

title_text = 'Scaling Data'
leg = ax.legend(loc = 'upper right', title=title_text, fontsize=10, fancybox=True, framealpha=0.5)
leg.set_title(title_text,prop={'size':12})   #   Set the title text font size
    
plt.show()

